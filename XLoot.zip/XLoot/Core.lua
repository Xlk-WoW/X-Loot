--[[ XLoot - Core
	Database registry, saved settings and the small helpers the UI relies on.
	No external libraries.
]]

local ADDON, GL = ...
_G.XLoot = GL

GL.version = "1.5.0"
GL.databases = {}

-- Adventure Journal overrides, filled by Data\Journal.lua (generated, see tools\journal_to_lua.py)
--   GL.journal[mode][itemID] = { "item:39193:0:0:0:0:0:0:0:75", 75 }     -- { item string, item level }
GL.journal = { loot = {}, heroic = {}, mythic = {}, n25 = {}, h25 = {} }

GL.expansions = {
	{ key = "Classic",   label = "Classic" },
	{ key = "TBC",       label = "The Burning Crusade" },
	{ key = "WotLK",     label = "Wrath of the Lich King" },
	{ key = "Cataclysm", label = "Cataclysm" },
}

-- Order in which loot variants appear as tabs on a boss page.
GL.modeOrder = { "loot", "heroic", "mythic", "n25", "h25" }

-- Mythic dungeon versions. The "Mythic" tab holds a second row of version buttons:
--   M0 0/5 is the journal entry itself; the others are computed from it (see VariantEntry).
-- Code layout of the item string's unique id (verified on the server):
--   high part (bits 11+)  = Mythic level + 16            (5 bits)
--   low part  (bits 0-10) = the item's M0 low part + (ilvl - 75)
--   ilvl = GL.mythicIlvl[level] 0/8 value + upgrade step  (0/8 .. 8/8, one ilvl per step; table below)
-- M12 is the highest Mythic rank: higher keys only add upgrade steps to it (key 12 drops M12 0/8,
-- key 13 drops M12 1/8, key 14 drops M12 2/8, key 15 drops M12 3/8 ...), M12 8/8 is item level 95.
-- short = the rank written behind the item name in the WishList (M0 is the plain "mythic" key)
GL.m0Label = "M0 0/5"
-- Every version: Mythic 1 .. 12, each as 0/8 ("m5") and 8/8 ("m5u"). The WishList lists all of them;
-- the Mythic tab of the journal only offers M0 and M12 0/8 (GL.journalVariants).
GL.mythicVariants = {}
for level = 1, 12 do
	GL.mythicVariants[#GL.mythicVariants + 1] = { key = "m" .. level, label = "M" .. level .. " 0/8", short = "M" .. level, level = level, step = 0 }
	GL.mythicVariants[#GL.mythicVariants + 1] = { key = "m" .. level .. "u", label = "M" .. level .. " 8/8", short = "M" .. level .. " 8/8", level = level, step = 8 }
end
GL.variantByKey = {}
for _, v in ipairs(GL.mythicVariants) do GL.variantByKey[v.key] = v end
GL.journalVariants = { GL.variantByKey.m12 }

-- Item level of every Mythic version: [level] = { 0/8 version, 8/8 version }. Each upgrade step adds 1,
-- so 8/8 is always 0/8 + 8. The server derives the "Mythic N: x/8" step in the tooltip from the item
-- level written in the code, so these numbers MUST match the server's real values:
--   M1 .. M6 0/8 = 77 (8/8 = 85), then +1 per level: M7 = 82/90 ... M12 = 87/95.
-- Confirmed on real drops: M5 3/8 = 80, M7 0/8 = 82, M12 0/8 = 87, M12 8/8 = 95.
GL.mythicIlvl = {
	[1]   = { 77, 85 },
	[2]   = { 77, 85 },
	[3]   = { 77, 85 },
	[4]   = { 77, 85 },
	[5]   = { 77, 85 },
	[6]   = { 77, 85 },
	[7]   = { 82, 90 },
	[8]   = { 83, 91 },
	[9]   = { 84, 92 },
	[10]  = { 85, 93 },
	[11]  = { 86, 94 },
	[12]  = { 87, 95 },
}

local defaults = {
	expansion = "Classic",
	scale     = 1,
	minimap   = { hide = false, angle = 215 },
	mem       = {},
	wish      = { match = "all", proc = false, use = false, stats = {}, slot = "ALL" },
}

local function CopyDefaults(src, dst)
	for k, v in pairs(src) do
		if type(v) == "table" then
			if type(dst[k]) ~= "table" then dst[k] = {} end
			CopyDefaults(v, dst[k])
		elseif dst[k] == nil then
			dst[k] = v
		end
	end
end

---------------------------------------------------------------------------
-- Database access
---------------------------------------------------------------------------

function GL:RegisterDatabase(key, zones)
	self.databases[key] = zones
end

function GL:GetZones(exKey)
	return self.databases[exKey] or {}
end

-- Returns an ordered list of { key = "loot"|"heroic"|"n25"|"h25", label = "..." }
-- that exist on this boss. Labels change when the boss has 25-man data.
function GL:GetModes(boss)
	local modes = {}
	if not boss then return modes end
	local has25 = (boss.n25 and #boss.n25 > 0) or (boss.h25 and #boss.h25 > 0)
	local labels
	if has25 then
		labels = { loot = "10 Man", heroic = "10 Heroic", mythic = "Mythic", n25 = "25 Man", h25 = "25 Heroic" }
	else
		labels = { loot = "Normal", heroic = "Heroic", mythic = "Mythic" }
	end
	for _, k in ipairs(self.modeOrder) do
		local secs = boss[k]
		if secs and #secs > 0 and labels[k] then
			local entry = { key = k, label = labels[k] }
			if k == "mythic" and self:HasMythicEntries(secs) then
				entry.variants = { { key = "mythic", label = self.m0Label } }
				for _, v in ipairs(self.journalVariants) do
					entry.variants[#entry.variants + 1] = { key = v.key, label = v.label }
				end
			end
			modes[#modes + 1] = entry
		end
	end
	return modes
end

-- true when the Mythic sections hold items that have an M0 journal entry (i.e. dungeon loot)
function GL:HasMythicEntries(secs)
	local j = self.journal and self.journal.mythic
	if not j then return false end
	for _, sec in ipairs(secs or {}) do
		for _, id in ipairs(sec) do
			if j[id] then return true end
		end
	end
	return false
end

function GL:ModeIn(list, key)
	for _, m in ipairs(list or {}) do
		if m.key == key then return true end
	end
	return false
end

-- is `key` one of the tabs (or one of a Mythic tab's versions) in this modes list?
function GL:ModeValid(modes, key)
	for _, m in ipairs(modes) do
		if m.key == key or (m.variants and self:ModeIn(m.variants, key)) then return true end
	end
	return false
end

-- the section list behind a mode key (every Mythic version shows the boss's "mythic" list)
function GL:GetSections(boss, mode)
	if self.variantByKey[mode] then return boss.mythic end
	return boss[mode]
end

-- Flatten a list of sections into display rows:
--   { header = "Label" } or { item = 12345 }
-- Heroic sections that live inside the "loot" list (e.g. label "Heroic Mode") use the heroic
-- journal data, so every item row also carries the mode its journal override is stored under.
function GL:SectionMode(sec, mode)
	if mode == "loot" and sec.label and strfind(strlower(sec.label), "heroic", 1, true) then
		return "heroic"
	end
	return mode
end

function GL:Flatten(sections, mode)
	local rows = {}
	if not sections then return rows end
	for _, sec in ipairs(sections) do
		if sec.label and sec.label ~= "" then
			rows[#rows + 1] = { header = sec.label }
		end
		local m = self:SectionMode(sec, mode)
		for _, id in ipairs(sec) do
			rows[#rows + 1] = { item = id, mode = m }
		end
	end
	return rows
end

function GL:CountItems(boss)
	local n = 0
	if not boss then return 0 end
	for _, k in ipairs(self.modeOrder) do
		for _, sec in ipairs(boss[k] or {}) do n = n + #sec end
	end
	return n
end

---------------------------------------------------------------------------
-- Item info (names/icons come from the client cache; unknown items are
-- requested from the server through a hidden tooltip)
---------------------------------------------------------------------------

local scanTip

function GL:RequestItem(id)
	if not scanTip then
		scanTip = CreateFrame("GameTooltip", "XLootScanTip", UIParent, "GameTooltipTemplate")
	end
	scanTip:SetOwner(UIParent, "ANCHOR_NONE")
	scanTip:SetHyperlink("item:" .. id)
end

-- The server scales some items (different stats / item level per difficulty). The Adventure Journal
-- shows the scaled version because it hands the tooltip a full item string, not just "item:ID".
-- Data\Journal.lua stores that string per mode; without an entry we fall back to the plain ID.
local variantCache = {}

-- Computes the item string of a Mythic version from the item's M0 journal entry.
function GL:VariantEntry(id, v)
	local ck = v.key .. ":" .. id
	local hit = variantCache[ck]
	if hit ~= nil then return hit or nil end
	local entry = false
	local base = self.journal and self.journal.mythic and self.journal.mythic[id]
	if base and base[1] then
		local p = { strsplit(":", base[1]) }
		local m0 = tonumber(p[9])
		if m0 and m0 >= 4096 then
			local row = self.mythicIlvl[v.level]
			local ilvl = row and (row[1] + (v.step >= 8 and (row[2] - row[1]) or v.step))
				or (75 + v.level + v.step)
			p[9] = (v.level + 16) * 2048 + (m0 - 4096) + (ilvl - 75)
			entry = { table.concat(p, ":"), ilvl }
		end
	end
	variantCache[ck] = entry
	return entry or nil
end

function GL:JournalEntry(id, mode)
	local v = self.variantByKey[mode or ""]
	if v then return self:VariantEntry(id, v) end
	local j = self.journal and self.journal[mode or "loot"]
	return j and j[id]
end

function GL:ItemString(id, mode)
	local e = self:JournalEntry(id, mode)
	return (e and e[1]) or ("item:" .. id)
end

-- Item level of the journal (scaled) version, read from its tooltip so it is always what the server says.
function GL:ScaledIlvl(id, mode)
	local e = self:JournalEntry(id, mode)
	if not (e and e[1]) then return nil end
	self.ilvlCache = self.ilvlCache or {}
	if self.ilvlCache[e[1]] then return self.ilvlCache[e[1]] end
	if not scanTip then
		scanTip = CreateFrame("GameTooltip", "XLootScanTip", UIParent, "GameTooltipTemplate")
	end
	scanTip:SetOwner(UIParent, "ANCHOR_NONE")
	scanTip:ClearLines()
	scanTip:SetHyperlink(e[1])
	local pattern = gsub(ITEM_LEVEL or "Item Level %d", "%%d", "(%%d+)")
	for i = 2, scanTip:NumLines() do
		local fs = _G["XLootScanTipTextLeft" .. i]
		local txt = fs and fs:GetText()
		local lv = txt and tonumber(strmatch(txt, pattern))
		if lv then
			self.ilvlCache[e[1]] = lv
			return lv
		end
	end
	return e[2]
end

-- name, link, quality, ilvl, class, subclass, equipLoc, icon   (name == nil while uncached)
-- ilvl comes from the journal version when we have one (GetItemInfo only knows the base item).
function GL:ItemInfo(id, mode)
	local name, link, quality, ilvl, _, class, subclass, _, equipLoc, icon = GetItemInfo(id)
	local e = self:JournalEntry(id, mode)
	if e then ilvl = self:ScaledIlvl(id, mode) or ilvl end
	return name, link, quality, ilvl, class, subclass, equipLoc, icon
end

-- chat/dressing-room link that carries the journal's item string
function GL:ItemLink(id, mode)
	local name, link = GetItemInfo(id)
	if not link then return nil end
	local e = self:JournalEntry(id, mode)
	if not (e and e[1]) then return link end
	local color = strmatch(link, "^(|c%x%x%x%x%x%x%x%x)") or "|cffffffff"
	return color .. "|H" .. e[1] .. "|h[" .. name .. "]|h|r"
end

---------------------------------------------------------------------------
-- Search (only items the client already knows can be matched by name)
---------------------------------------------------------------------------

function GL:Search(text, limit)
	local results = {}
	text = text and strlower(strtrim(text)) or ""
	if strlen(text) < 2 then return results end
	limit = limit or 150
	local seen = {}
	for _, ex in ipairs(self.expansions) do
		local zones = self.databases[ex.key]
		if zones then
			for zi, zone in ipairs(zones) do
				for bi, boss in ipairs(zone.bosses or {}) do
					for _, mk in ipairs(self.modeOrder) do
						for _, sec in ipairs(boss[mk] or {}) do
							for _, id in ipairs(sec) do
								if not seen[id] then
									local name = GetItemInfo(id)
									if name and strfind(strlower(name), text, 1, true) then
										seen[id] = true
										results[#results + 1] = {
											id = id, ex = ex.key, zi = zi, bi = bi, mode = mk, emode = self:SectionMode(sec, mk),
											src = zone.name .. "  -  " .. boss.name,
										}
										if #results >= limit then return results end
									end
								end
							end
						end
					end
				end
			end
		end
	end
	return results
end

---------------------------------------------------------------------------
-- Loading / slash command
---------------------------------------------------------------------------

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:SetScript("OnEvent", function(self, event, name)
	if name ~= ADDON then return end
	self:UnregisterEvent("ADDON_LOADED")
	XLootDB = XLootDB or {}
	CopyDefaults(defaults, XLootDB)
	GL.db = XLootDB
	-- Clear leftover debug settings (scan range, skip list, debug mode) so the WishList scan covers every item.
	GL.db.wishFrom, GL.db.wishTo, GL.db.wishSkip, GL.db.wishDebug, GL.db.wishAuto = nil, nil, nil, nil, nil
	if GL.OnLoad then GL:OnLoad() end
end)

SLASH_XLOOT1 = "/xl"
SlashCmdList["XLOOT"] = function()
	if GL.Toggle then GL:Toggle() end
end
