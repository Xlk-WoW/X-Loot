--[[ XLoot - Wishlist (advanced stat filtering)
	Reads every item of the database through a hidden tooltip, remembers which stats it has and
	lets the UI ask "give me everything with Spell Power + Spirit + Haste, highest iLvl first".
	No UI in here; UI.lua builds the tab and the filter panel on top of these functions.
]]

local ADDON, GL = ...

---------------------------------------------------------------------------
-- Stat definitions
-- Each stat is matched against tooltip lines (lower case, plain text). Client globals are used
-- when they exist so non-English clients work too; English text is always kept as a fallback.
---------------------------------------------------------------------------

local function G(name, fallback)
	local v = _G[name]
	if type(v) == "string" and v ~= "" then return strlower(v) end
	return strlower(fallback)
end

GL.wishStats = {
	-- key, label, patterns
	{ key = "stamina",     label = "Stamina",           pat = { G("ITEM_MOD_STAMINA_SHORT", "Stamina") } },
	{ key = "dodge",       label = "Dodge",             pat = { "dodge rating" } },
	{ key = "parry",       label = "Parry",             pat = { "parry rating" } },
	{ key = "blockvalue",  label = "Block Value",       pat = { "block value" } },
	{ key = "intellect",   label = "Intellect",         pat = { G("ITEM_MOD_INTELLECT_SHORT", "Intellect") } },
	{ key = "spirit",      label = "Spirit",            pat = { G("ITEM_MOD_SPIRIT_SHORT", "Spirit") } },
	{ key = "mp5",         label = "MP5",               pat = { "mana per 5", "mana every 5" } },
	{ key = "spellpower",  label = "Spell Power",       pat = { G("ITEM_MOD_SPELL_POWER_SHORT", "Spell Power") } },
	{ key = "spellpen",    label = "Spell Penetration", pat = { "spell penetration" } },
	{ key = "strength",    label = "Strength",          pat = { G("ITEM_MOD_STRENGTH_SHORT", "Strength") } },
	{ key = "agility",     label = "Agility",           pat = { G("ITEM_MOD_AGILITY_SHORT", "Agility") } },
	{ key = "attackpower", label = "Attack Power",      pat = { "attack power" } },
	{ key = "expertise",   label = "Expertise",         pat = { "expertise rating" } },
	{ key = "armorpen",    label = "Armor Penetration", pat = { "armor penetration" } },
	{ key = "crit",        label = "Crit Rating",       pat = { "critical strike rating", "crit rating", G("ITEM_MOD_CRIT_RATING_SHORT", "Critical Strike Rating") } },
	{ key = "haste",       label = "Haste Rating",      pat = { G("ITEM_MOD_HASTE_RATING_SHORT", "Haste Rating"), "haste rating" } },
	{ key = "hit",         label = "Hit",               pat = { G("ITEM_MOD_HIT_RATING_SHORT", "Hit Rating"), "hit rating" } },
}

-- Layout of the filter panel: one block per group, two columns, filled row by row.
GL.wishGroups = {
	{ "stamina", "dodge", "parry", "blockvalue" },
	{ "intellect", "spirit", "mp5", "spellpower", "spellpen" },
	{ "strength", "agility", "attackpower", "expertise", "armorpen" },
	{ "crit", "haste", "hit" },
}

GL.wishResists = {
	{ key = "res_arcane", label = "Arcane", pat = { G("RESISTANCE6_NAME", "Arcane Resistance") } },
	{ key = "res_fire",   label = "Fire",   pat = { G("RESISTANCE2_NAME", "Fire Resistance") } },
	{ key = "res_nature", label = "Nature", pat = { G("RESISTANCE3_NAME", "Nature Resistance") } },
	{ key = "res_frost",  label = "Frost",  pat = { G("RESISTANCE4_NAME", "Frost Resistance") } },
	{ key = "res_shadow", label = "Shadow", pat = { G("RESISTANCE5_NAME", "Shadow Resistance") } },
}

local ALL_STATS = {}
for _, s in ipairs(GL.wishStats) do ALL_STATS[#ALL_STATS + 1] = s end

-- item slots for the WishList slot filter (equip locations as returned by GetItemInfo)
GL.wishSlots = {
	{ key = "ALL",      label = "All slots" },
	{ key = "head",     label = "Head",      loc = { INVTYPE_HEAD = true } },
	{ key = "neck",     label = "Neck",      loc = { INVTYPE_NECK = true } },
	{ key = "shoulder", label = "Shoulder",  loc = { INVTYPE_SHOULDER = true } },
	{ key = "back",     label = "Cloak",     loc = { INVTYPE_CLOAK = true } },
	{ key = "chest",    label = "Chest",     loc = { INVTYPE_CHEST = true, INVTYPE_ROBE = true } },
	{ key = "wrist",    label = "Wrist",     loc = { INVTYPE_WRIST = true } },
	{ key = "hands",    label = "Gloves",    loc = { INVTYPE_HAND = true } },
	{ key = "waist",    label = "Waist",     loc = { INVTYPE_WAIST = true } },
	{ key = "legs",     label = "Legs",      loc = { INVTYPE_LEGS = true } },
	{ key = "feet",     label = "Boots",     loc = { INVTYPE_FEET = true } },
	{ key = "finger",   label = "Ring",      loc = { INVTYPE_FINGER = true } },
	{ key = "trinket",  label = "Trinket",   loc = { INVTYPE_TRINKET = true } },
	{ key = "mh",       label = "Main-Hand", loc = { INVTYPE_WEAPONMAINHAND = true } },
	{ key = "1h",       label = "One-Hand",  loc = { INVTYPE_WEAPON = true } },
	{ key = "2h",       label = "Two-Hand",  loc = { INVTYPE_2HWEAPON = true } },
	{ key = "oh",       label = "Off-Hand",  loc = { INVTYPE_WEAPONOFFHAND = true, INVTYPE_HOLDABLE = true } },
	{ key = "shield",   label = "Shield",    loc = { INVTYPE_SHIELD = true } },
	-- wands share the equip location of guns / crossbows; they are told apart by the item subtype
	{ key = "ranged",   label = "Ranged",    loc = { INVTYPE_RANGED = true, INVTYPE_RANGEDRIGHT = true, INVTYPE_THROWN = true, INVTYPE_RELIC = true }, notWand = true },
	{ key = "wand",     label = "Wand",      loc = { INVTYPE_RANGEDRIGHT = true }, wand = true },
}
-- Only these equip locations are ever scanned. Tokens, mounts, pets, recipes, tabards, shirts, bags,
-- ammo and every other non-equippable item have no (or another) equip location and are skipped.
local GEAR = {}
for _, sl in ipairs(GL.wishSlots) do
	if sl.loc then for loc in pairs(sl.loc) do GEAR[loc] = true end end
end
GL.wishGear = GEAR

GL.wishSlotByKey = {}
for _, sl in ipairs(GL.wishSlots) do GL.wishSlotByKey[sl.key] = sl end

-- label lookup for the summary line
GL.wishLabels = { proc = "Proc Effect", use = "On Use Effect" }
for _, s in ipairs(ALL_STATS) do GL.wishLabels[s.key] = s.label end

---------------------------------------------------------------------------
-- Tooltip parsing
---------------------------------------------------------------------------

local tip
local function Tip()
	if not tip then
		tip = CreateFrame("GameTooltip", "XLootWishTip", UIParent, "GameTooltipTemplate")
	end
	return tip
end

local TRIG_USE   = strlower(_G.ITEM_SPELL_TRIGGER_ONUSE or "Use:")
local TRIG_EQUIP = strlower(_G.ITEM_SPELL_TRIGGER_ONEQUIP or "Equip:")
local TRIG_PROC  = strlower(_G.ITEM_SPELL_TRIGGER_ONPROC or "Chance on hit:")
local ILVL_PAT   = gsub(_G.ITEM_LEVEL or "Item Level %d", "%%d", "(%%d+)")
local LOADING    = strlower(_G.RETRIEVING_ITEM_INFO or "Retrieving item information")

local function Clean(txt)
	txt = gsub(txt, "|c%x%x%x%x%x%x%x%x", "")
	txt = gsub(txt, "|r", "")
	return strlower(txt)
end

-- lines that describe a temporary effect, not a flat stat
local function IsEffectLine(l)
	return strfind(l, "chance", 1, true) or strfind(l, "each time", 1, true)
		or strfind(l, "whenever", 1, true) or strfind(l, "when ", 1, true)
		or strfind(l, "for %d+ sec") or strfind(l, "on hit", 1, true)
end

---------------------------------------------------------------------------
-- Persistent scan cache (saved in XLootDB.wishCache, so a finished scan survives /reload and relog)
-- Keyed by the full item string, so every scaled / Mythic version has its own entry.
-- Bump GL.wishCacheVersion whenever the stat parsing above changes to force a fresh scan.
---------------------------------------------------------------------------
GL.wishCacheVersion = 1

local function CacheItems()
	local d = GL.db
	if not d then return nil end
	local c = d.wishCache
	if type(c) ~= "table" or c.ver ~= GL.wishCacheVersion or type(c.items) ~= "table" then
		c = { ver = GL.wishCacheVersion, items = {} }
		d.wishCache = c
	end
	return c.items
end

-- fills a freshly built variant from the saved cache; returns true when it was found
local function CacheLoad(v)
	local items = CacheItems()
	local e = items and items[v.str]
	if not e or type(e.s) ~= "table" then return false end
	v.stats, v.proc, v.use = e.s, e.p and true or false, e.u and true or false
	v.ilvl, v.equip, v.subtype = e.l or 0, e.e, e.w
	v.gear = true   -- only gear is ever scanned, so a cached entry is always gear
	return true
end

local function CacheSave(v, subtype)
	local items = CacheItems()
	if not items then return end
	items[v.str] = { s = v.stats, p = v.proc or nil, u = v.use or nil, l = v.ilvl, e = v.equip, w = subtype }
end

-- Reads the tooltip of an item string. Returns false while the item is not loaded yet.
local function ParseVariant(v)
	if GL.wishDebug then print("|cffde7230GL scan|r read " .. v.str) end
	local t = Tip()
	t:SetOwner(UIParent, "ANCHOR_NONE")
	t:ClearLines()
	t:SetHyperlink(v.str)
	local n = t:NumLines()
	if n < 1 then return false end
	local first = _G["XLootWishTipTextLeft1"]
	local ft = first and first:GetText()
	if not ft or ft == "" or strfind(strlower(ft), LOADING, 1, true) then return false end

	local stats, proc, use, ilvl = {}, false, false, nil
	for i = 2, n do
		local fs = _G["XLootWishTipTextLeft" .. i]
		local raw = fs and fs:GetText()
		if raw and raw ~= "" then
			local l = Clean(raw)
			local lv = tonumber(strmatch(raw, ILVL_PAT))
			if lv and not ilvl then ilvl = lv end

			if strfind(l, "^" .. TRIG_USE, 1) then
				use = true
			elseif strfind(l, "^" .. TRIG_PROC, 1) then
				proc = true
			elseif strfind(l, "set:", 1, true) or strfind(l, "%(%d+/%d+%)") or strfind(l, "socket bonus", 1, true) then
				-- set bonuses / set lists / socket bonuses are not part of the item's own stats
			else
				local effect = IsEffectLine(l)
				if effect and strfind(l, "^" .. TRIG_EQUIP, 1) then proc = true end
				if not effect then
					local num = tonumber(strmatch(l, "(%d+)"))
					if num then
						for _, s in ipairs(ALL_STATS) do
							for _, p in ipairs(s.pat) do
								if strfind(l, p, 1, true) then
									stats[s.key] = (stats[s.key] or 0) + num
									break
								end
							end
						end
					end
				end
			end
		end
	end

	v.stats, v.proc, v.use = stats, proc, use
	local _, _, _, _, _, _, _, _, equip = GetItemInfo(v.id)
	v.equip = equip
	if not ilvl then
		local _, _, _, il = GetItemInfo(v.id)
		ilvl = il
	end
	v.ilvl = ilvl or 0
	local _, _, _, _, _, _, subtype = GetItemInfo(v.id)
	if subtype then v.subtype = subtype end
	CacheSave(v, v.subtype)
	return true
end

---------------------------------------------------------------------------
-- Variant list: every distinct item string (scaled versions count separately)
---------------------------------------------------------------------------

-- Category of a variant for the "Show Only" buttons in the WishList header.
--   nodung / hedung = Normal / Heroic dungeon     noraid / heraid = Normal / Heroic raid (10 and 25 man)
--   m0 = Mythic base version (0/5)                 m1 .. m12 = Mythic 1 .. 12 (0/8 and 8/8)
local CAT_OF_MODE = { mythic = "m0" }
for level = 1, 12 do
	CAT_OF_MODE["m" .. level] = "m" .. level
	CAT_OF_MODE["m" .. level .. "u"] = "m" .. level
end
local HEROIC_MODE = { heroic = true, h25 = true }
local function CatOf(ztype, vm)
	local c = CAT_OF_MODE[vm]
	if c then return c end
	return (HEROIC_MODE[vm] and "he" or "no") .. ((ztype == "raid") and "raid" or "dung")
end

local function ModeLabels(boss)
	local labels = {}
	for _, m in ipairs(GL:GetModes(boss)) do labels[m.key] = m.label end
	return labels
end

function GL:WishBuild()
	if self.wishVariants then return self.wishVariants end
	local list, byStr = {}, {}
	for _, ex in ipairs(self.expansions) do
		for zi, zone in ipairs(self.databases[ex.key] or {}) do
			for bi, boss in ipairs(zone.bosses or {}) do
				local labels = ModeLabels(boss)
				for _, mk in ipairs(self.modeOrder) do
					-- Mythic dungeon loot is listed once per version: M0, then M1 .. M12 each as 0/8 and 8/8
					local vmodes = { mk }
					if mk == "mythic" and self:HasMythicEntries(boss.mythic) then
						for _, vr in ipairs(self.mythicVariants) do vmodes[#vmodes + 1] = vr.key end
					end
					for _, vm in ipairs(vmodes) do
						local vr = self.variantByKey[vm]
						local rank, rankLevel
						if vr then
							rank, rankLevel = vr.short, vr.level
						elseif mk == "mythic" and #vmodes > 1 then
							rank, rankLevel = "M0", 0
						end
						for _, sec in ipairs(boss[mk] or {}) do
							local m = self:SectionMode(sec, vm)
							for _, id in ipairs(sec) do
								if not (vr and not self:JournalEntry(id, vm)) then   -- no scaled data: nothing to list
									local str = self:ItemString(id, m)
									local src = zone.name .. "  -  " .. boss.name
									local lab = labels[mk]
									if lab and mk ~= "loot" then src = src .. "  (" .. lab .. ")" end
									local cat = CatOf(zone.type, vm)
									local v = byStr[str]
									if not v then
										v = { id = id, str = str, mode = m, label = (mk ~= "loot") and lab or nil,
											rank = rank, rankLevel = rankLevel,
											ex = ex.key, zone = zone.name, ztype = zone.type,
											nav = { ex = ex.key, zi = zi, bi = bi, mode = vm }, srcs = { src } }
										byStr[str] = v
										list[#list + 1] = v
										v.idx = #list
										v.cats = {}
										CacheLoad(v)   -- already scanned in an earlier session: no new scan needed
									elseif #v.srcs < 6 then
										local dup = false
										for _, s in ipairs(v.srcs) do if s == src then dup = true end end
										if not dup then v.srcs[#v.srcs + 1] = src end
									end
									v.cats[cat] = true
								end
							end
						end
					end
				end
			end
		end
	end
	self.wishVariants = list
	return list
end

---------------------------------------------------------------------------
-- Background scan (throttled so the client never freezes or floods the server)
---------------------------------------------------------------------------

-- Items whose journal item level is already known to be under the minimum never need a scan.
-- Items that crash the 3.3.5 client when it is asked about them (found with the old debug mode).
-- They are never scanned. Add more IDs here.
GL.wishBadIds = {
	[68981] = true,   -- Firelands / Beth'tilac: ACCESS_VIOLATION on SetHyperlink("item:68981")
}

-- Zones whose items crash the client when it is asked about them (they are not on this server).
-- Their items are never scanned, so they never show up in the WishList.
GL.wishSkipZones = {
	Cataclysm = { ["Firelands"] = true, ["Dragon Soul"] = true },
}

---------------------------------------------------------------------------
-- Phases (progression filter in the panel)
--   Phase 1 = every dungeon (except the ones listed in wishPhaseDungeons below) + the raids listed in P1 below
--   Phase 2 = every other raid (until the real Phase 2 / 3 / 4 raid lists are known) + the dungeons
--             listed in wishPhaseDungeons[2]
--   Phase 3 / 4 = nothing yet: add raid names to P3 / P4 below and they move out of Phase 2.
--   Dungeons that are not active yet: add their exact zone name to wishPhaseDungeons[n] to move them to Phase n.
---------------------------------------------------------------------------
GL.wishPhaseLabels = { "Phase1", "Phase2", "Phase3", "Phase4" }
GL.wishPhaseRaids = {
	[1] = { ["Naxxramas"] = true, ["The Obsidian Sanctum"] = true, ["Gruul's Lair"] = true, ["Molten Core"] = true },
	[2] = {},   -- empty on purpose: every raid not named in another phase lands here
	[3] = {},
	[4] = {},
}

GL.wishPhaseDungeons = {
	[2] = {
		["Trial of the Champion"] = true,
		["The Forge of Souls"] = true,
		["Pit of Saron"] = true,
		["Halls of Reflection"] = true,
		["Caverns of Time: The Culling of Stratholme"] = true,
	},
	[3] = {},
	[4] = {},
}

local function PhaseOf(v)
	if v.phase then return v.phase end
	local ph
	if v.ztype ~= "raid" then
		for n = 2, 4 do
			if GL.wishPhaseDungeons[n][v.zone] then ph = n; break end
		end
		ph = ph or 1
	else
		for n = 1, 4 do
			if GL.wishPhaseRaids[n][v.zone] then ph = n; break end
		end
		ph = ph or 2
	end
	v.phase = ph
	return ph
end

-- true when no phase box is ticked, or the item belongs to a ticked phase
function GL:WishPhaseOK(v)
	local f = self.db and self.db.wish
	local sel = f and f.phase
	if not sel or not (sel[1] or sel[2] or sel[3] or sel[4]) then return true end
	return sel[PhaseOf(v)] and true or false
end

-- true = gear, false = not gear, nil = not known yet (item not in the client cache)
local function GearState(v)
	if v.gear ~= nil then return v.gear end
	if GetItemInfo(v.id) then
		local _, _, _, _, _, _, _, _, equip = GetItemInfo(v.id)
		v.gear = (equip and GEAR[equip]) and true or false
		return v.gear
	end
	return nil
end

-- "Only Show Highest M+ Ranks": Mythic dungeon versions below this level are hidden (and not scanned).
-- Items that are not a Mythic dungeon version are never affected.
GL.wishTopRank = 12

-- "Show Only" buttons: nothing ticked = everything; otherwise only the ticked categories are kept.
function GL:WishShowOK(v)
	local f = self.db and self.db.wish
	local sh = f and f.show
	if not sh or not next(sh) then return true end
	for cat in pairs(v.cats or {}) do
		if sh[cat] then return true end
	end
	return false
end

function GL:WishRankOK(v)
	local f = self.db and self.db.wish
	if not f then return true end
	if not self:WishShowOK(v) then return false end
	return true
end

function GL:WishEligible(v, floor)
	if GL.wishBadIds[v.id] then return false end
	if not self:WishRankOK(v) then return false end
	local z = GL.wishSkipZones[v.ex]
	if z and z[v.zone] then return false end
	if not self:WishPhaseOK(v) then return false end
	if GearState(v) == false then return false end
	local d = self.db
	if d then
		if d.wishFrom and v.idx and v.idx < d.wishFrom then return false end
		if d.wishTo and v.idx and v.idx > d.wishTo then return false end
		if d.wishSkip and d.wishSkip[v.id] then return false end
	end
	if v.kil == nil then
		local e = self.JournalEntry and self:JournalEntry(v.id, v.mode)
		v.kil = (e and tonumber(e[2])) or false
	end
	if v.kil and v.kil > self:WishMaxIlvl() then return false end   -- known to be above the window: never scanned
	return not (v.kil and v.kil < floor)
end

function GL:WishStartScan()
	if self.wishScan and not self.wishScan.finished then return end
	local list = self:WishBuild()
	local pending = {}
	local floor = self:WishMinIlvl()
	for _, v in ipairs(list) do
		if not v.stats and not v.failed and self:WishEligible(v, floor) then pending[#pending + 1] = v end
	end
	self.wishScan = {
		pending = pending, pos = 1, flight = {}, ready = {}, retry = {},
		total = #list, finished = (#pending == 0), wait = 0,
	}
end

function GL:WishProgress()
	local list = self.wishVariants
	if not list then return 0, 0 end
	local floor = self:WishMinIlvl()
	local done, total = 0, 0
	for _, v in ipairs(list) do
		if self:WishEligible(v, floor) then
			total = total + 1
			if v.stats or v.failed then done = done + 1 end
		end
	end
	return done, total
end

-- Gentle on purpose: the 3.3.5 client can hard-crash when a lot of uncached item queries are in flight
-- at once, so only a few are open at the same time. Every open query is checked again each tick, and
-- a query the server never answers is dropped after QUERY_TIMEOUT seconds.
-- Normal speed while the window is open; very low speed in the background (window closed).
-- Debug breadcrumb: big red text at the top of the screen. The item is announced and the scan then waits
-- a moment so the screen really draws the text BEFORE the client is asked about that item. If the client
-- crashes, the text visible in the crash screenshot is the culprit.
local dbgFrame
local function DebugShow(msg)
	if not dbgFrame then
		dbgFrame = CreateFrame("Frame", nil, UIParent)
		dbgFrame:SetFrameStrata("TOOLTIP")
		dbgFrame:SetWidth(700); dbgFrame:SetHeight(40)
		dbgFrame:SetPoint("TOP", UIParent, "TOP", 0, -60)
		dbgFrame.fs = dbgFrame:CreateFontString(nil, "OVERLAY")
		dbgFrame.fs:SetFont("Fonts\\FRIZQT__.TTF", 26, "OUTLINE")
		dbgFrame.fs:SetTextColor(1, 0.25, 0.25)
		dbgFrame.fs:SetAllPoints()
	end
	if msg then dbgFrame.fs:SetText(msg); dbgFrame:Show() else dbgFrame:Hide() end
end
GL.WishDebugShow = DebugShow

local FAST = { parse = 12, request = 2, flight = 10, pause = 0 }
local SLOW = { parse = 6,  request = 1, flight = 4,  pause = 0.25 }
local DEBUG = { parse = 1,  request = 1, flight = 1,  pause = 0.1 }   -- debug mode (no command any more)
local QUERY_TIMEOUT = 10

function GL:WishTick(elapsed)
	local ws = self.wishScan
	if not ws or ws.finished then return end

	if ws.wait > 0 then
		ws.wait = ws.wait - elapsed
		return
	end

	local now = GetTime()
	local parsed, requested = 0, 0
	local flight, ready, retry = ws.flight, ws.ready, ws.retry

	-- debug: announce the item, return true to end this tick so the text gets drawn first
	local function Announce(v, what)
		if not GL.wishDebug then return false end
		if ws.announced == v then ws.announced = nil; return false end
		ws.announced = v
		DebugShow("#" .. tostring(v.idx) .. "   item " .. v.id .. "   " .. what)
		ws.wait = 0.2
		return true
	end
	local L = GL.wishDebug and DEBUG or ((GL.frame and GL.frame:IsShown()) and FAST or SLOW)
	local MAX_PARSE_PER_FRAME, MAX_REQUEST_PER_FRAME, MAX_IN_FLIGHT = L.parse, L.request, L.flight

	-- 1) open queries: answered, timed out or still waiting
	local i = 1
	while i <= #flight do
		local v = flight[i]
		if GetItemInfo(v.id) then
			table.remove(flight, i)
			if GearState(v) then ready[#ready + 1] = v end   -- not gear: dropped, never read
		elseif now - v.reqAt > QUERY_TIMEOUT then
			table.remove(flight, i)
			-- the server did not answer in time (slow server / busy queue): ask again in a later pass,
			-- at most 3 times in total, then give up on this item
			v.tmo = (v.tmo or 0) + 1
			if v.tmo >= 3 then v.failed = true else retry[#retry + 1] = v end
		else
			i = i + 1
		end
	end

	-- 2) read tooltips of everything that is loaded
	local function Read(v)
		if ParseVariant(v) then
			parsed = parsed + 1
		else
			v.ptries = (v.ptries or 0) + 1
			if v.ptries < 3 then retry[#retry + 1] = v else v.failed = true end
		end
	end
	while parsed < MAX_PARSE_PER_FRAME and #ready > 0 do
		if Announce(ready[#ready], "read") then return end
		Read(table.remove(ready))
	end

	-- 3) take new items from the list
	local pending = ws.pending
	while ws.pos <= #pending and parsed < MAX_PARSE_PER_FRAME and requested < MAX_REQUEST_PER_FRAME
		and #flight < MAX_IN_FLIGHT do
		local v = pending[ws.pos]
		ws.pos = ws.pos + 1
		if GetItemInfo(v.id) then
			if GearState(v) then
				if Announce(v, "read") then ws.pos = ws.pos - 1; break end
				Read(v)
			end
		else
			if Announce(v, "request") then ws.pos = ws.pos - 1; break end
			v.reqAt = now
			flight[#flight + 1] = v
			if GL.wishDebug then print("|cffde7230GL scan|r request item:" .. v.id) end
			local t = Tip()
			t:SetOwner(UIParent, "ANCHOR_NONE")
			t:SetHyperlink("item:" .. v.id)
			requested = requested + 1
		end
	end

	-- 4) end of the list: go again over what still needs a second look
	if ws.pos > #pending then
		if #retry > 0 and #flight == 0 and #ready == 0 then
			ws.pending, ws.retry, ws.pos = retry, {}, 1
			ws.wait = 0.5
		elseif #retry == 0 and #flight == 0 and #ready == 0 then
			ws.finished = true
		end
	end

	if L.pause > 0 and ws.wait <= 0 then ws.wait = L.pause end
	self.wishDirty = true
end

---------------------------------------------------------------------------
-- Filtering
---------------------------------------------------------------------------

-- Active criteria from the saved filter: list of { key, min }
function GL:WishCriteria()
	local f = self.db and self.db.wish
	local crit = {}
	if not f then return crit end
	for _, s in ipairs(ALL_STATS) do
		local m = f.stats and f.stats[s.key]
		if m and not s.floor then crit[#crit + 1] = { key = s.key, min = 0 } end
	end
	return crit
end

local function IsWand(v)
	if v.subtype == nil then
		local _, _, _, _, _, _, sub = GetItemInfo(v.id)
		if not sub then return false end
		v.subtype = sub
	end
	return strfind(strlower(v.subtype), "wand", 1, true) and true or false
end

-- does item variant v fit the slot definition sl (nil = all slots)?
function GL:WishSlotOK(sl, v)
	if not sl then return true end
	if not (v.equip and sl.loc[v.equip]) then return false end
	if sl.wand then return IsWand(v) end
	if sl.notWand then return not IsWand(v) end
	return true
end

-- selected slot definition, or nil for "all slots"
function GL:WishSlot()
	local f = self.db and self.db.wish
	local sl = f and f.slot and self.wishSlotByKey[f.slot]
	if sl and sl.loc then return sl end
	return nil
end

-- minimum item level typed in the filter panel (0 = no limit)
-- Item level window for the WishList. Change these two numbers to widen / narrow it.
GL.wishIlvlMin = 55
GL.wishIlvlMax = nil   -- no upper limit (Mythic 15-20 go far above 80); set a number to cap it again

function GL:WishMinIlvl()
	return GL.wishIlvlMin or 0
end

function GL:WishMaxIlvl()
	return GL.wishIlvlMax or 9999
end

local function Passes(v, c)
	if c.key == "proc" then return v.proc end
	if c.key == "use" then return v.use end
	local val = v.stats[c.key] or 0
	return val > 0 and val >= (c.min or 0)
end

-- Stats that can be used as the sort key ("double select" in the filter panel)
GL.wishSortable = { stamina = true, spellpower = true, strength = true, agility = true, intellect = true }

-- The stat the results are sorted by, or nil (= plain item level order).
-- Only valid while that stat is also ticked as a filter.
function GL:WishSortKey()
	local f = self.db and self.db.wish
	local k = f and f.sort
	if k and self.wishSortable[k] and f.stats and f.stats[k] then return k end
	return nil
end

-- Sorted result list (highest item level first, or highest value of the chosen sort stat)
function GL:WishResults()
	local crit = self:WishCriteria()
	local out = {}
	if #crit == 0 then return out, crit end
	local all = true   -- items must always have every ticked stat
	local minIlvl, maxIlvl = self:WishMinIlvl(), self:WishMaxIlvl()
	local slot = self:WishSlot()
	for _, v in ipairs(self:WishBuild()) do
		if v.stats and self:WishPhaseOK(v) and self:WishRankOK(v) and v.ilvl >= minIlvl and v.ilvl <= maxIlvl and self:WishSlotOK(slot, v) then
			local ok
			if all then
				ok = true
				for _, c in ipairs(crit) do
					if not Passes(v, c) then ok = false; break end
				end
			else
				ok = false
				for _, c in ipairs(crit) do
					if Passes(v, c) then ok = true; break end
				end
			end
			if ok then out[#out + 1] = v end
		end
	end
	local sk = self:WishSortKey()
	table.sort(out, function(a, b)
		if sk then
			local va, vb = a.stats[sk] or 0, b.stats[sk] or 0
			if va ~= vb then return va > vb end
		end
		if a.ilvl ~= b.ilvl then return a.ilvl > b.ilvl end
		local _, _, qa = GetItemInfo(a.id)
		local _, _, qb = GetItemInfo(b.id)
		qa, qb = qa or 0, qb or 0
		if qa ~= qb then return qa > qb end
		if a.id ~= b.id then return a.id < b.id end
		return a.str < b.str
	end)
	return out, crit
end

-- "Spell Power + Spirit + Haste Rating"
function GL:WishSummary(crit)
	local names = {}
	local lv = self:WishMinIlvl()
	for _, c in ipairs(crit) do
		local n = self.wishLabels[c.key] or c.key
		if c.min and c.min > 0 then n = n .. " " .. c.min .. "+" end
		names[#names + 1] = n
	end
	local txt = table.concat(names, " + ")
	local sl = self:WishSlot()
	if sl then txt = txt .. "  -  " .. sl.label end
	local sk = self:WishSortKey()
	local f = self.db and self.db.wish
	if f and f.phase and (f.phase[1] or f.phase[2] or f.phase[3] or f.phase[4]) then
		local ph = {}
		for n = 1, 4 do if f.phase[n] then ph[#ph + 1] = self.wishPhaseLabels[n] end end
		txt = txt .. "  -  " .. table.concat(ph, "+")
	end
	if sk then txt = txt .. "  -  highest " .. (self.wishLabels[sk] or sk) .. " first" end
	if f and f.onlyMythic then txt = txt .. "  -  Mythic gear only" end
	if f and f.topRanks then txt = txt .. "  -  M" .. GL.wishTopRank .. "+ only" end
	local hi = self:WishMaxIlvl()
	txt = txt .. "  -  iLvl " .. lv .. (hi >= 9999 and "+" or ("-" .. hi))
	return txt
end

-- "Intellect + Spell Power": only the ticked stats (the other filters stay hidden)
function GL:WishStatList(crit)
	local names = {}
	for _, c in ipairs(crit) do
		names[#names + 1] = self.wishLabels[c.key] or c.key
	end
	return table.concat(names, " + ")
end

-- drives the scan; the UI registers GL.OnWishUpdate to refresh itself
local driver = CreateFrame("Frame")
local acc = 0
local boot = 25
driver:SetScript("OnUpdate", function(_, elapsed)
	if GL.wishScan and not GL.wishScan.finished then GL:WishTick(elapsed) end
	-- the debug switch is saved, so it is already on when a scan starts after a crash / relog
	if GL.wishDebug == nil and GL.db then GL.wishDebug = GL.db.wishDebug and true or false end
	-- resume a saved filter in the background shortly after login (off by default, db.wishAuto)
	if boot then
		boot = boot - elapsed
		if boot <= 0 then
			boot = nil
			if GL.db and GL.db.wishAuto and #GL:WishCriteria() > 0 then GL:WishStartScan() end
		end
	end
	acc = acc + elapsed
	if acc >= 2.0 then
		acc = 0
		if GL.wishDirty and GL.OnWishUpdate then
			GL.wishDirty = false
			GL:OnWishUpdate()
		end
	end
end)
