#!/usr/bin/env python3
"""Merge a XLootExport SavedVariables dump into Data/Classic|TBC|WotLK|Cataclysm.lua.

usage: python build_db_from_export.py XLootExportDB.lua [data_dir]

* Existing instances / bosses / items are kept as they are; nothing is removed.
* Items the Adventure Journal lists that the databases are missing are added (new bosses and
  instances too). Added items go into an "Adventure Journal" section when the tab already has
  labelled sections, otherwise they are appended to the tab's list.
* Journal difficulty -> tab:  dungeon 1 Normal -> loot, 2 Heroic -> heroic, any other dungeon
  difficulty id (e.g. 23) -> mythic.
  raid 3 -> loot (10-man / only difficulty), 4 -> n25 (loot when the raid has no difficulty 3),
  5 -> heroic, 6 -> h25 (n25 when the raid only has 3 and 6).
* Encounters with more than MAX_ENCOUNTER_ITEMS items are Journal "everything" dumps, not real
  boss loot, and are skipped (reported on screen).
Run  python journal_to_lua.py <export>  afterwards to refresh the scaled item data.
"""
import re, sys, os, collections

MAX_ENCOUNTER_ITEMS = 100
MODES = ("loot", "heroic", "mythic", "n25", "h25")
TIERS = {"1": ("Classic", "Classic"), "2": ("TBC", "The Burning Crusade"),
         "3": ("WotLK", "Wrath of the Lich King"), "4": ("Cataclysm", "Cataclysm")}
# export instance name -> existing instance names it is split into
ALIAS = {
    "Blackrock Spire": ["Lower Blackrock Spire", "Upper Blackrock Spire"],
    "Dire Maul": ["Dire Maul (East)", "Dire Maul (North)", "Dire Maul (West)"],
    "The Battle for Mount Hyjal": ["Hyjal Summit"],
    "The Culling of Stratholme": ["Caverns of Time: The Culling of Stratholme"],
}

def same_boss(a, b):
    a, b = norm(a), norm(b)
    return a == b or (min(len(a), len(b)) >= 5 and (a in b or b in a))

def norm(n):
    n = n.lower().replace("\u2019", "'")
    n = re.sub(r"^the ", "", n)
    return re.sub(r"[^a-z0-9]", "", n)

# ---------------------------------------------------------------- tiny Lua-table reader
def tokenize(t):
    return re.findall(r'"(?:\\.|[^"\\])*"|[A-Za-z_]\w*|\d+|[{}=,]', t)

def unq(s):
    return re.sub(r'\\(.)', r'\1', s[1:-1])

def parse_val(tk, i):
    t = tk[i]
    if t == "{": return parse_tbl(tk, i)
    if t.startswith('"'): return unq(t), i + 1
    if t.isdigit(): return int(t), i + 1
    return t, i + 1

def parse_tbl(tk, i):
    i += 1; arr, kv = [], {}
    while tk[i] != "}":
        if tk[i + 1] == "=" and re.match(r"[A-Za-z_]", tk[i]):
            k = tk[i]; v, i = parse_val(tk, i + 2); kv[k] = v
        else:
            v, i = parse_val(tk, i); arr.append(v)
        if tk[i] == ",": i += 1
    return {"arr": arr, "kv": kv}, i + 1

def load_db(path):
    raw = open(path, encoding="utf8").read()
    m = re.search(r'GL:RegisterDatabase\("(\w+)",\s*', raw)
    body = re.sub(r"--\[\[.*?\]\]", "", raw[m.end():], flags=re.S)
    body = re.sub(r"--[^\n]*", "", body)
    tbl, _ = parse_tbl(tokenize(body[body.index("{"):]), 0)
    zones = []
    for z in tbl["arr"]:
        zone = {"name": z["kv"]["name"], "type": z["kv"].get("type", "dungeon"),
                "group": z["kv"].get("group"), "bosses": []}
        for b in z["kv"]["bosses"]["arr"]:
            boss = {"name": b["kv"]["name"]}
            for mode in MODES:
                if mode in b["kv"]:
                    boss[mode] = [{"label": s["kv"].get("label"), "ids": list(s["arr"])} for s in b["kv"][mode]["arr"]]
            zone["bosses"].append(boss)
        zones.append(zone)
    return m.group(1), raw[:m.start()], zones

def q(s): return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'

def dump_db(key, header, zones):
    o = [header.rstrip("\n") + "\n\n", 'GL:RegisterDatabase("%s", {\n' % key]
    for z in zones:
        o.append("\t{ name = %s, type = %s%s,\n\t\tbosses = {\n" % (q(z["name"]), q(z["type"]),
                 (", group = " + q(z["group"])) if z["group"] else ""))
        for b in z["bosses"]:
            has = [m for m in MODES if b.get(m)]
            if not has:
                o.append("\t\t\t{ name = %s, loot = {} },\n" % q(b["name"])); continue
            o.append("\t\t\t{ name = %s,\n" % q(b["name"]))
            for m in has:
                o.append("\t\t\t\t%s = {\n" % m)
                for s in b[m]:
                    parts = ([ "label = " + q(s["label"]) ] if s["label"] else []) + [str(i) for i in s["ids"]]
                    o.append("\t\t\t\t\t{ %s },\n" % ", ".join(parts))
                o.append("\t\t\t\t},\n")
            o.append("\t\t\t},\n")
        o.append("\t\t},\n\t},\n")
    o.append("})\n")
    return "".join(o)

# ---------------------------------------------------------------- export
def read_export(path):
    t = open(path, encoding="utf8", newline="").read()
    rows = [l.split("^") for l in re.findall(r'^\t\t"(.*)", -- \[\d+\]\r?$', t, re.M)]
    inst = {}
    for f in rows:
        if f[0] == "INSTANCE": inst[f[3]] = {"tier": f[1], "raid": f[2] == "true", "name": f[4]}
    data = collections.OrderedDict()      # (tier, instID) -> {"diffs": set, "enc": {(d, enc): [ids]}, "order": [encs]}
    for f in rows:
        if f[0] != "LOOT": continue
        i = inst[f[2]]
        e = data.setdefault((i["tier"], f[2]), {"info": i, "diffs": set(), "enc": collections.OrderedDict(), "order": []})
        e["diffs"].add(f[3])
        if f[6] not in e["order"]: e["order"].append(f[6])
        lst = e["enc"].setdefault((f[3], f[6]), [])
        if int(f[8]) not in lst: lst.append(int(f[8]))
    return data

def mode_of(info, diffs, d):
    if not info["raid"]: return {"1": "loot", "2": "heroic"}.get(d, "mythic")   # any further dungeon difficulty = Mythic
    if d == "3": return "loot"
    if d == "4": return "n25" if "3" in diffs else "loot"
    if d == "5": return "heroic"
    if d == "6": return "n25" if ("4" not in diffs and "5" not in diffs) else "h25"

def main():
    src = sys.argv[1]
    data_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "Data")
    dbs = {}
    for fname, _ in TIERS.values():
        dbs[fname] = load_db(os.path.join(data_dir, fname + ".lua"))
    export = read_export(src)
    moved_n = [0]
    added = collections.Counter(); new_inst, new_boss, skipped = [], [], []
    for (tier, iid), e in export.items():
        fname = TIERS[tier][0]
        key, header, zones = dbs[fname]
        name, info = e["info"]["name"], e["info"]
        cands = [z for z in zones if norm(z["name"]) in {norm(a) for a in ALIAS.get(name, [name])}]
        if not cands:
            cands = [{"name": name, "type": "raid" if info["raid"] else "dungeon", "group": None, "bosses": []}]
            zones.append(cands[0]); new_inst.append((fname, name))
        for encname in e["order"]:
            boss = None
            for z in cands:
                for b in z["bosses"]:
                    if same_boss(b["name"], encname): boss = b; break
                if boss: break
            if boss is None:
                boss = {"name": encname}; cands[0]["bosses"].append(boss); new_boss.append((fname, cands[0]["name"], encname))
            # AtlasLoot keeps heroic dungeon loot inside "loot" under a "Heroic Mode" header; when the
            # Journal gives this boss a real Heroic list, move those sections to the Heroic tab so
            # the items are not listed twice.
            if not info["raid"] and e["enc"].get(("2", encname)):
                moved = [x for x in boss.get("loot", []) if x["label"] and "heroic" in x["label"].lower()]
                if moved:
                    boss["loot"] = [x for x in boss["loot"] if x not in moved]
                    boss["heroic"] = moved + boss.get("heroic", [])
                    moved_n[0] += len(moved)
            for d in sorted(e["diffs"]):
                ids = e["enc"].get((d, encname))
                if not ids: continue
                mode = mode_of(info, e["diffs"], d)
                if not mode: continue
                if len(ids) > MAX_ENCOUNTER_ITEMS:
                    skipped.append((fname, name, encname, d, len(ids))); continue
                secs = boss.setdefault(mode, [])
                have = {i for s in secs for i in s["ids"]}
                new = [i for i in ids if i not in have]
                if not new: continue
                added[(fname, mode)] += len(new)
                if not secs: secs.append({"label": None, "ids": new})
                elif any(s["label"] for s in secs): secs.append({"label": "Adventure Journal", "ids": new})
                else: secs[-1]["ids"].extend(new)
    # drop empty placeholder bosses whose full Journal name was added as a separate boss
    # ("Rajh" -> "Rajh, Construct of Sun")
    for fname, (key, header, zones) in dbs.items():
        for z in zones:
            full = [b["name"] for b in z["bosses"] if any(b.get(m) for m in MODES)]
            z["bosses"] = [b for b in z["bosses"] if any(b.get(m) for m in MODES)
                           or not any(n.lower().startswith(b["name"].lower() + ",") for n in full)]
    for fname, (key, header, zones) in dbs.items():
        if fname == "Cataclysm":
            header = re.sub(r"--\[\[ XLoot database: Cataclysm.*?\]\]",
                            "--[[ XLoot database: Cataclysm\n\tItemIDs only (generated from the Adventure Journal export by tools/build_db_from_export.py).\n"
                            "\tSame structure as the other databases. Names, icons and tooltips come from the server.\n]]",
                            header, flags=re.S)
        open(os.path.join(data_dir, fname + ".lua"), "w", encoding="utf8", newline="\n").write(dump_db(key, header, zones))
    print("items added:"); [print("  ", k, v) for k, v in sorted(added.items())]
    print("total added:", sum(added.values()), "| heroic sections moved to Heroic tab:", moved_n[0])
    print("new instances:", new_inst)
    print("new bosses (%d):" % len(new_boss)); [print("  ", x) for x in new_boss]
    print("bosses still without any items:")
    for fname, (key, header, zones) in dbs.items():
        for z in zones:
            for b in z["bosses"]:
                if not any(b.get(m) for m in MODES): print("  ", fname, z["name"], "-", b["name"])
    print("skipped encounters:"); [print("  ", x) for x in skipped]

if __name__ == "__main__":
    main()
