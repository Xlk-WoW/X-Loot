X-Loot - Minimal loot browser (3.3.5 client)

INSTALL
  Copy the "XLoot" folder into  World of Warcraft\Interface\AddOns\
  In game:  /xl

COMMAND
  /xl   open / close X-Loot (the only command)

USING IT
  Tabs: Classic / The Burning Crusade / Wrath of the Lich King / Cataclysm
  Shift-click an item to link it in chat, Ctrl-click to preview it.
  Search matches item names the client has already seen.

MYTHIC VERSIONS
  The Mythic tab has a second row: M0 0/5 and M12 0/8.
  (M12 is the highest rank: key 12 drops M12 0/8, key 13 drops 1/8, key 14 drops 2/8, key 15 drops 3/8 ...; M12 8/8 is item level 95.)

WISHLIST + MYTHIC (1.4.17)
  Every Mythic dungeon version (M0, then M1 .. M12 each as 0/8 and 8/8) is scanned and listed in the
  WishList, with its rank written behind the name ("Chromis Chestpiece M10").
  The WishList has no upper item level limit any more (GL.wishIlvlMax in Wishlist.lua).
  "Only Show Highest M+ Ranks" (above the slot dropdown) hides M0 / M5 / M10 and keeps M12+.

1.4.18: WishList "Only Show Mythic Gear" (left of "Only Show Highest M+ Ranks") hides every non-Mythic item.
1.4.19: WishList header redone. "N Items - Must have all: <stats>" now sits right of the WishList title (stats only, other filters stay hidden). New "Show Only:" buttons on the left (Normal/Heroic Dung, Mythic, Mythic10 / Normal/Heroic Raid, Mythic5, Mythic15; several can be on, none = everything). New "Clear Item Level" button above the slot dropdown (removes the minimum item level, click again to restore); the slot dropdown is narrower.
1.4.20: WishList tab: the window grows wider (4 item columns) and returns to its normal size on the other tabs. The slot dropdown is now a list on the left (Head .. Wand, click again to clear), next to a "Show Only" list (Normal Dungeon, Normal Raid, Heroic Dungeon, Heroic Raid, Mythic, Mythic 5, Mythic 10, Mythic 15; several can be on) and the "Clear Item Level" button. Title, item count and the two Mythic toggles sit in one extended bar across the top. Off-Hand / Shield and Ranged / Wand are separate slots now.
1.4.21: Advance Filtering: "Add Resistance" and "Items must have" removed (items must always have ALL ticked stats). The small sort box in front of Intellect / Spell Power / Strength / Agility is now a labelled "Priority" button at the end of the row; the check box on the left only filters.
1.4.22: WishList: "Only Show Mythic Gear" and "Only Show Highest M+ Ranks" removed. A separator line divides the Slot list from the Show Only list, and Show Only now allows ONE version at a time (click it again to show every version).
1.4.23: WishList: "Clear Item Level" button removed (the minimum item level is back to the fixed value in Wishlist.lua).
1.4.24: WishList: item tooltips open at the right edge of the window instead of next to the hovered item.
1.4.25: Advance Filtering: Stamina now has a "Priority" button too (highest Stamina first).
1.4.26: Mythic dungeon versions: M15 0/8 and M15 8/8 are now M12 0/8 and M12 8/8 (M12 is the highest rank, 8/8 = item level 95). Applies to every Mythic dungeon item in the Mythic tab and the WishList ("Mythic 15" in Show Only is now "Mythic 12").
1.4.27: WishList lists every Mythic version: M1 .. M12, each as 0/8 and 8/8 (the Show Only list has Mythic 1 .. Mythic 12). The journal's Mythic tab now only offers M0 and M12 0/8.
1.4.28: Mythic item levels now come from an editable table (GL.mythicIlvl in Core.lua; only M12 8/8 = 95 is confirmed, the rest is still the formula). 
1.4.29: Mythic item levels are an explicit table in Core.lua (GL.mythicIlvl, one line per Mythic level, 0/8 and 8/8) with the confirmed levels marked. Values are unchanged: they already match M5 3/8 = 80, M7 0/8 = 82, M12 0/8 = 87 and M12 8/8 = 95.
1.4.30: Mythic item levels corrected (GL.mythicIlvl in Core.lua). Every level no longer shares a plateau: M1-M6 0/8 = 77 (8/8 = 85), M7 = 82/90, M8 = 83/91, M9 = 84/92, M10 = 85/93, M11 = 86/94, M12 = 87/95. M6 8/8 (85) and M10 8/8 (93) are no longer the same.
1.4.31: Mythic item levels are now +1 per Mythic level: 0/8 = 75 + level (M1 76 ... M12 87), 8/8 = 83 + level (M1 84 ... M12 95). Every Mythic level has its own item level now (M1 8/8 = 84, M6 8/8 = 89, M12 8/8 = 95).
1.4.32: WishList phases: Trial of the Champion, The Forge of Souls, Pit of Saron, Halls of Reflection and Caverns of Time: The Culling of Stratholme moved from Phase1 to Phase2 (GL.wishPhaseDungeons in Wishlist.lua; add a dungeon name there to move it to another phase).

1.4.33: Restyled with the JunkieUI look. Expressway font (Media\Expressway.ttf, falls back to the stock font if missing), JunkieUI dark warm palette with the #de7230 orange accent, flat one-pixel borders snapped to the screen's physical pixels, and the same bar reactions: hover = warm orange fill, selected = warm fill + accent border + accent text (tabs, mode buttons, Slot / Show Only lists, rows with the accent side bar), orange scroll bar thumb that brightens on hover/drag, accent check boxes with accent border on hover. The WishList scan counter is now a flat progress bar (dark track, accent fill).
1.4.34: Mythic item levels restored to the server's real values (M1-M6 0/8 = 77, 8/8 = 85; M7 = 82/90 ... M12 = 87/95). With the 1.4.31 table (M1 8/8 = 84) the server read the code as step 7, so M1 8/8 items showed "Mythic 1: 7/8" in the tooltip. They now show 8/8, item level 85.

1.5.0: Renamed to X-Loot (folder XLoot, in-game title X-Loot). /xl is now the only command (/gl and the /glprobe dev tool are gone). The WishList scan is cached in the saved variables (XLootDB.wishCache): every item is only scanned once, later sessions load the stats straight from the cache. Raise GL.wishCacheVersion in Wishlist.lua to force a full rescan.
