--[[ XLoot database: Classic
	ItemIDs only. Names, icons, quality and tooltips are read from the game client / server.

	Structure:
	  { name = "Instance", type = "dungeon" | "raid", group = "Optional parent (e.g. Auchindoun)",
	    bosses = {
	      { name = "Boss",
	        loot   = { { label = "Optional header", 12345, 12346 }, ... },   -- default / normal
	        heroic = { ... },   -- optional: Heroic tab
	        n25    = { ... },   -- optional: 25-man tab (then 'loot' is the 10-man list)
	        h25    = { ... },   -- optional: 25-man Heroic tab
	      },
	    } },
]]

local _, GL = ...

GL:RegisterDatabase("Classic", {
	{ name = "Blackfathom Deeps", type = "dungeon",
		bosses = {
			{ name = "Ghamoo-ra",
				loot = {
					{ 6908, 6907 },
				},
			},
			{ name = "Lady Sarevess",
				loot = {
					{ 888, 11121, 3078 },
				},
			},
			{ name = "Gelihast",
				loot = {
					{ 6906, 6905, 1470 },
				},
			},
			{ name = "Baron Aquanis",
				loot = {
					{ 16782, 16886, 16887 },
				},
			},
			{ name = "Twilight Lord Kelris",
				loot = {
					{ 6903, 1155, 5881 },
				},
			},
			{ name = "Old Serra'kis",
				loot = {
					{ 6901, 6902, 6904 },
				},
			},
			{ name = "Aku'mai",
				loot = {
					{ 6910, 6911, 6909 },
				},
			},
			{ name = "Quest Item",
				loot = {
					{ 5359, 16762 },
				},
			},
			{ name = "Trash Mobs",
				loot = {
					{ 1486, 3416, 1491, 3413, 2567, 3417, 1454, 1481, 3414, 3415, 2271 },
				},
			},
		},
	},
	{ name = "Blackrock Depths", type = "dungeon",
		bosses = {
			{ name = "Overmaster Pyron",
				loot = {
					{ 14486 },
				},
			},
			{ name = "Lord Roccor",
				loot = {
					{ 22234, 11632, 22397, 11631, 11630, 11813, 11811 },
				},
				heroic = {
					{ 11632, 22234, 11631 },
				},
			},
			{ name = "High Interrogator Gerstahn",
				loot = {
					{ 11626, 11624, 22240, 11625, 11140 },
				},
				heroic = {
					{ 11626, 11625, 22240, 11624 },
				},
			},
			{ name = "Ring of Law",
				loot = {
					{ 11677, 11675, 11731, 11678, 11685, 11686, 11679, 11730, 11726, 22271, 11729, 11722, 11703, 22270, 22257, 22266, 11702, 11610, 11634, 11633, 11635, 11662, 11665, 11728, 11824 },
				},
				heroic = {
					{ 11662, 22257, 11678, 11824, 11722, 22270, 22266, 11686, 11677, 11702, 11635, 22271, 11665, 11679, 11726, 11731, 11730, 11729, 11728, 11675, 11634, 11633, 11685, 11703 },
				},
			},
			{ name = "Theldren",
				loot = {
					{ label = "Dungeon Set 2 Summonable", 22330, 22305, 22317, 22318, 22047 },
				},
			},
			{ name = "Houndmaster Grebmar",
				loot = {
					{ 11623, 11626, 11627, 11628, 11629 },
				},
				heroic = {
					{ 11627, 11628, 11629, 11623 },
				},
			},
			{ name = "Pyromancer Loregrain",
				loot = {
					{ 11747, 11749, 11750, 11748, 11207 },
				},
				heroic = {
					{ 11747, 11750, 11748, 11749 },
				},
			},
			{ name = "The Vault",
				loot = {
					{ label = "The Vault", 11309 },
					{ label = "The Secret Safe", 22256, 11929, 11926, 22205, 22255, 11920, 11923, 22254 },
					{ label = "Dark Coffer", 11752, 11751, 11753 },
				},
			},
			{ name = "Warder Stilgiss",
				loot = {
					{ 11782, 22241, 11783, 11784 },
				},
				heroic = {
					{ 11784, 11782, 11783, 22241 },
				},
			},
			{ name = "Verek",
				loot = {
					{ 22242, 11755 },
				},
			},
			{ name = "Fineous Darkvire",
				loot = {
					{ 11839, 11841, 11842, 22223, 11840, 10999 },
				},
				heroic = {
					{ 11839, 22223, 11842, 11841 },
				},
			},
			{ name = "Lord Incendius",
				loot = {
					{ 11768, 11766, 11764, 11765, 11767, 19268, 21987, 11126 },
				},
				heroic = {
					{ 11764, 11767, 11766, 11765 },
				},
			},
			{ name = "Bael'Gar",
				loot = {
					{ 11807, 11802, 11805, 11803 },
				},
				heroic = {
					{ 11803, 11802, 11805, 11807 },
				},
			},
			{ name = "General Angerforge",
				loot = {
					{ 11821, 11820, 11810, 11817, 11816, 11464 },
				},
				heroic = {
					{ 11816, 11810, 11817, 11820, 11821 },
				},
			},
			{ name = "Golem Lord Argelmach",
				loot = {
					{ 11822, 11823, 11669, 11819, 21956, 11268, 11465 },
				},
				heroic = {
					{ 11823, 11669, 11822, 11819 },
				},
			},
			{ name = "The Grim Guzzler",
				loot = {
					{ label = "Hurley Blackbreath", 11735, 18043, 22275, 18044, 11312 },
					{ label = "Phalanx", 22212, 11745, 11744 },
					{ label = "Ribbly Screwspigot", 11612, 2662, 2663, 11742, 11313 },
					{ label = "Plugger Spazzring", 12793, 12791, 13483, 18653, 15759, 11602, 11325 },
				},
			},
			{ name = "Ambassador Flamelash",
				loot = {
					{ 11808, 11812, 11814, 11832, 11809, 23320 },
				},
				heroic = {
					{ 11832, 11812, 11808, 11809, 11814 },
				},
			},
			{ name = "Panzor the Invincible (Rare)",
				loot = {
					{ 22245, 11787, 11786, 11785 },
				},
			},
			{ name = "Summoner's Tomb",
				loot = {
					{ label = "Chest of The Seven", 11929, 11925, 11926, 11927, 11922, 11920, 11923, 11921 },
				},
			},
			{ name = "Magmus",
				loot = {
					{ 11746, 11935, 22395, 22400, 22208 },
				},
				heroic = {
					{ 11746, 22208, 11935 },
				},
			},
			{ name = "Emperor Dagran Thaurissan",
				loot = {
					{ 11684, 11930, 11924, 22204, 22207, 11933, 11934, 11815, 11931, 11932, 11928, 12033 },
				},
				heroic = {
					{ 11931, 11934, 11932, 11815, 11933, 11684, 11924, 22207, 11928, 11930, 22204 },
				},
			},
			{ name = "Princess Moira Bronzebeard",
				loot = {
					{ 12554, 12556, 12557, 12553 },
				},
			},
			{ name = "Blacksmith Plans (Blackrock Depths)",
				loot = {
					{ 11614, 11615 },
				},
			},
			{ name = "Trash Mobs (Blackrock Depths)",
				loot = {
					{ 12552, 12551, 12542, 12546, 12550, 12547, 12549, 12555, 12531, 12535, 12527, 12528, 12532, 15781, 15770, 16053, 16049, 16048, 18654, 18661, 11754, 11078, 18945, 11468, 11446 },
				},
			},
			{ name = "Hurley Blackbreath",
				loot = {
					{ 18043, 22275, 18044, 11735 },
				},
				heroic = {
					{ 18043, 22275, 18044, 11735 },
				},
			},
			{ name = "Phalanx",
				loot = {
					{ 11744, 11745, 22212 },
				},
				heroic = {
					{ 11744, 11745, 22212 },
				},
			},
			{ name = "Ribbly Screwspigot",
				loot = {
					{ 11612, 11742 },
				},
				heroic = {
					{ 11612, 11742 },
				},
			},
			{ name = "Plugger Spazzring",
				loot = {
					{ 12791, 12793, 18653 },
				},
				heroic = {
					{ 12791, 12793, 18653 },
				},
			},
			{ name = "The Seven",
				loot = {
					{ 11922, 11926, 11925, 11929, 11921, 11927, 11923, 11920 },
				},
				heroic = {
					{ 11922, 11926, 11925, 11929, 11921, 11927, 11923, 11920 },
				},
			},
		},
	},
	{ name = "Dire Maul (East)", type = "dungeon", group = "Dire Maul",
		bosses = {
			{ name = "Pusillin",
				loot = {
					{ 18267, 18261, 18249 },
				},
			},
			{ name = "Zevrim Thornhoof",
				loot = {
					{ 18319, 18313, 18323, 18306, 18308 },
				},
				heroic = {
					{ 18308, 18319, 18306, 18313, 18323 },
				},
			},
			{ name = "Hydrospawn",
				loot = {
					{ 18322, 18317, 18324, 18307, 18305 },
				},
				heroic = {
					{ 18305, 18307, 18317, 18322, 18324 },
				},
			},
			{ name = "Lethtendris",
				loot = {
					{ 18325, 18311, 18302, 18301, 18426 },
				},
				heroic = {
					{ 18302, 18325, 18301, 18311 },
				},
			},
			{ name = "Pimgib",
				loot = {
					{ 18354 },
				},
			},
			{ name = "Alzzin the Wildshaper",
				loot = {
					{ 18328, 18327, 18309, 18318, 18312, 18326 },
					{ label = "Felvine Shard", 18501, 18315, 18314, 18310, 18321 },
				},
				heroic = {
					{ 18321, 18312, 18310, 18309, 18318, 18326, 18314, 18315, 18328, 18327 },
				},
			},
			{ name = "Isalien",
				loot = {
					{ label = "Dungeon Set 2 Summonable", 22304, 22472, 22401, 22345, 22315, 22314, 21984, 22046 },
				},
			},
			{ name = "Trash Mobs (Dire Maul (East))",
				loot = {
					{ 18295, 18298, 18296, 18289 },
				},
			},
			{ name = "Dire Maul Books",
				loot = {
					{ 18364, 18361, 18358, 18359, 18362, 18356, 18363, 18360, 18357, 18333, 18334, 18332, 18470, 18473, 18468, 18472, 18469, 18465, 18471, 18467, 18466, 18401, 18348 },
				},
			},
		},
	},
	{ name = "Dire Maul (North)", type = "dungeon", group = "Dire Maul",
		bosses = {
			{ name = "Guard Mol'dar",
				loot = {
					{ 18496, 18497, 18494, 18493, 18498, 18268, 18450, 18451, 18458, 18459, 18464, 18462, 18463, 18460 },
				},
				heroic = {
					{ 18493, 18494, 18459, 18464, 18498, 18496, 18451, 18462, 18458, 18463, 18450, 18497, 18460 },
				},
			},
			{ name = "Stomper Kreeg",
				loot = {
					{ 18425, 18269, 18284 },
				},
				heroic = {
					{ 18425 },
				},
			},
			{ name = "Guard Fengus",
				loot = {
					{ 18450, 18451, 18458, 18459, 18464, 18462, 18463, 18460 },
					{ label = "Fengus's Chest", 18266 },
					{ label = "Adventure Journal", 18493, 18498, 18494, 18496, 18497 },
				},
				heroic = {
					{ 18493, 18494, 18459, 18464, 18498, 18496, 18451, 18462, 18458, 18463, 18450, 18497, 18460 },
				},
			},
			{ name = "Knot Thimblejack",
				loot = {
					{ 18517, 18518, 18519, 18414, 18418, 18415, 18416, 18417, 18514, 18515, 18516 },
					{ label = "Ogre Tannin Basket", 18240, 18509, 18510, 18511, 18405, 18413, 18407, 18408, 18409, 18504, 18506, 18508 },
				},
			},
			{ name = "Guard Slip'kik",
				loot = {
					{ 18496, 18497, 18494, 18493, 18498, 18450, 18451, 18458, 18459, 18464, 18462, 18463, 18460 },
				},
				heroic = {
					{ 18493, 18494, 18459, 18464, 18498, 18496, 18451, 18462, 18458, 18463, 18450, 18497, 18460 },
				},
			},
			{ name = "Captain Kromcrush",
				loot = {
					{ 18507, 18505, 18503, 18502 },
				},
				heroic = {
					{ 18507, 18503, 18502, 18505 },
				},
			},
			{ name = "King Gordok",
				loot = {
					{ 18526, 18525, 18527, 18524, 18521, 18522, 18523, 18520, 19258, 18780, 12727 },
				},
				heroic = {
					{ 18522, 18520, 18525, 18523, 18526, 18521, 18527, 18524 },
				},
			},
			{ name = "Cho'Rush the Observer",
				loot = {
					{ 18490, 18484, 18485, 18483 },
				},
				heroic = {
					{ 18484, 18490, 18483, 18485 },
				},
			},
			{ name = "DM North Tribute Chest",
				loot = {
					{ 18538, 18495, 18532, 18528, 18530, 18533, 18529, 18500, 18537, 18531, 18534, 18499, 18475, 18478, 18477, 18476, 18479, 18480, 18481, 18482, 18655 },
				},
			},
			{ name = "Dire Maul Books",
				loot = {
					{ 18364, 18361, 18358, 18359, 18362, 18356, 18363, 18360, 18357, 18333, 18334, 18332, 18470, 18473, 18468, 18472, 18469, 18465, 18471, 18467, 18466, 18401, 18348 },
				},
			},
		},
	},
	{ name = "Dire Maul (West)", type = "dungeon", group = "Dire Maul",
		bosses = {
			{ name = "Tendris Warpwood",
				loot = {
					{ 18390, 18393, 18353, 18352 },
				},
				heroic = {
					{ 18352, 18353, 18390, 18393 },
				},
			},
			{ name = "Illyanna Ravenoak",
				loot = {
					{ 18386, 18383, 18349, 18347 },
				},
				heroic = {
					{ 18383, 18349, 18386, 18347 },
				},
			},
			{ name = "Magister Kalendris",
				loot = {
					{ 18374, 18397, 18371, 18350, 18351, 22309 },
				},
				heroic = {
					{ 18350, 18397, 18374, 18351, 18371 },
				},
			},
			{ name = "Tsu'zee",
				loot = {
					{ 18387, 18346, 18345 },
				},
			},
			{ name = "Immol'thar",
				loot = {
					{ 18389, 18385, 18377, 18391, 18394, 18379, 18384, 18381, 18370, 18372 },
				},
				heroic = {
					{ 18384, 18372, 18389, 18394, 18381, 18391, 18379, 18377, 18385, 18370 },
				},
			},
			{ name = "Lord Hel'nurath",
				loot = {
					{ 18757, 18754, 18756, 18755 },
				},
			},
			{ name = "Prince Tortheldrin",
				loot = {
					{ 18382, 18373, 18375, 18378, 18380, 18395 },
					{ label = "The Prince's Chest", 18336, 18392, 18396, 18376, 18388 },
				},
				heroic = {
					{ 18375, 18373, 18392, 18380, 18395, 18382, 18396, 18378, 18388, 18376 },
				},
			},
			{ name = "Trash Mobs (Dire Maul (West))",
				loot = {
					{ 18344, 18340, 18338 },
				},
			},
			{ name = "Dire Maul Books",
				loot = {
					{ 18364, 18361, 18358, 18359, 18362, 18356, 18363, 18360, 18357, 18333, 18334, 18332, 18470, 18473, 18468, 18472, 18469, 18465, 18471, 18467, 18466, 18401, 18348 },
				},
			},
		},
	},
	{ name = "Gnomeregan", type = "dungeon",
		bosses = {
			{ name = "Namdo Bizzfizzle",
				loot = {
					{ 14639 },
				},
			},
			{ name = "Techbot",
				loot = {
					{ 9444, 9277 },
				},
			},
			{ name = "Grubbis",
				loot = {
					{ 9445 },
				},
			},
			{ name = "Viscous Fallout",
				loot = {
					{ 9454, 9453, 9452 },
				},
			},
			{ name = "Electrocutioner 6000",
				loot = {
					{ 9448, 9447, 9446, 6893 },
				},
			},
			{ name = "Crowd Pummeler 9-60",
				loot = {
					{ 9450, 9449 },
				},
			},
			{ name = "Dark Iron Ambassador",
				loot = {
					{ 9455, 9457, 9456 },
				},
			},
			{ name = "Mekgineer Thermaplugg",
				loot = {
					{ 9492, 9461, 9459, 9458, 4415, 4413, 4411, 7742, 9299 },
				},
			},
			{ name = "Trash Mobs",
				loot = {
					{ 9508, 9491, 9509, 9510, 9490, 9485, 9486, 9488, 9487, 9327, 9326, 9362, 9538 },
				},
			},
		},
	},
	{ name = "Lower Blackrock Spire", type = "dungeon",
		bosses = {
			{ name = "Spirestone Butcher (Rare)",
				loot = {
					{ 12608, 13286 },
				},
			},
			{ name = "Highlord Omokk",
				loot = {
					{ 13170, 13169, 13168, 13166, 13167, 12336, 12534, 16670 },
				},
				heroic = {
					{ 13167, 13168, 13170, 13166, 13169 },
				},
			},
			{ name = "Spirestone Battle Lord (Rare)",
				loot = {
					{ 13284, 13285 },
				},
			},
			{ name = "Spirestone Lord Magus (Rare)",
				loot = {
					{ 13282, 13283, 13261 },
				},
			},
			{ name = "Shadow Hunter Vosh'gajin",
				loot = {
					{ 12626, 13257, 13255, 12651, 12653, 12654, 13352, 12821, 16712 },
				},
				heroic = {
					{ 12651, 13257, 12626, 12653, 13255 },
				},
			},
			{ name = "War Master Voone",
				loot = {
					{ 22231, 13179, 13177, 12582, 28972, 12335, 16676 },
				},
				heroic = {
					{ 13179, 22231, 12582, 13177 },
				},
			},
			{ name = "Mor Grayhoof (Summon)",
				loot = {
					{ label = "Dungeon Set 2 Summonable", 22306, 22325, 22319, 22398, 22322, 21984, 22046 },
				},
			},
			{ name = "Bannok Grimaxe (Rare)",
				loot = {
					{ 12634, 12637, 12621, 12838, 12784 },
				},
			},
			{ name = "Mother Smolderweb",
				loot = {
					{ 13244, 13213, 13183, 16715, 68673 },
				},
				heroic = {
					{ 13244, 68673, 13213, 13183 },
				},
			},
			{ name = "Crystal Fang",
				loot = {
					{ 13185, 13184, 13218 },
				},
			},
			{ name = "Urok Doomhowl (Summon)",
				loot = {
					{ 13258, 22232, 13259, 13178, 18784, 12725, 12712, 15867 },
				},
				heroic = {
					{ 22232, 13259, 13178, 13258 },
				},
			},
			{ name = "Quartermaster Zigris",
				loot = {
					{ 13253, 13252, 12835, 12798, 21955, 12264 },
				},
				heroic = {
					{ 13252, 13253, 12264 },
				},
			},
			{ name = "Halycon",
				loot = {
					{ 22313, 13210, 13211, 13212 },
				},
				heroic = {
					{ 13212, 22313, 13210, 13211 },
				},
			},
			{ name = "Gizrul the Slavener",
				loot = {
					{ 13206, 13208, 13205, 16718 },
				},
				heroic = {
					{ 13208, 13205, 13206 },
				},
			},
			{ name = "Ghok Bashguud (Rare)",
				loot = {
					{ 13203, 13198, 13204 },
				},
			},
			{ name = "Overlord Wyrmthalak",
				loot = {
					{ 13143, 13162, 13164, 22321, 13163, 13148, 13161, 12337, 16679 },
				},
				heroic = {
					{ 22321, 13143, 13162, 13163, 13161 },
				},
			},
			{ name = "Burning Felguard (Rare, Random)",
				loot = {
					{ 13181, 13182 },
				},
			},
			{ name = "Trash Mobs (Lower Blackrock Spire)",
				loot = {
					{ 14513, 14152, 13494, 16250, 16244, 15749, 15775, 12219, 21982 },
				},
			},
		},
	},
	{ name = "Maraudon", type = "dungeon",
		bosses = {
			{ name = "Noxxion",
				loot = {
					{ 17746, 17744, 17745, 17702 },
				},
			},
			{ name = "Razorlash",
				loot = {
					{ 17750, 17748, 17749, 17751 },
				},
			},
			{ name = "Lord Vyletongue",
				loot = {
					{ 17755, 17754, 17752, 17703 },
				},
			},
			{ name = "Meshlok the Harvester",
				loot = {
					{ 17741, 17742, 17767 },
				},
			},
			{ name = "Celebras the Cursed",
				loot = {
					{ 17739, 17740, 17738 },
				},
			},
			{ name = "Landslide",
				loot = {
					{ 17736, 17734, 17737, 17943 },
				},
			},
			{ name = "Tinkerer Gizlock",
				loot = {
					{ 17719, 17718, 17717 },
				},
			},
			{ name = "Rotgrip",
				loot = {
					{ 17732, 17728, 17730 },
				},
			},
			{ name = "Princess Theradras",
				loot = {
					{ 17780, 17715, 17714, 17711, 17707, 17713, 17710, 17766 },
				},
			},
			{ name = "Quest Item",
				loot = {
					{ 17764, 17765 },
				},
			},
		},
	},
	{ name = "Ragefire Chasm", type = "dungeon",
		bosses = {
			{ name = "Taragaman the Hungerer",
				loot = {
					{ 14149, 14148, 14145, 14540 },
				},
			},
			{ name = "Zelemar the Wrathful",
				loot = {
					{ 24225 },
				},
			},
			{ name = "Jergosh the Invoker",
				loot = {
					{ 14150, 14147, 14151 },
				},
			},
			{ name = "Adarogg",
				loot = {
					{ 82772, 82879, 82880 },
				},
			},
			{ name = "Dark Shaman Koranthal",
				loot = {
					{ 82877, 82881, 82882 },
				},
			},
			{ name = "Slagmaw",
				loot = {
					{ 82878, 82884, 82885 },
				},
			},
			{ name = "Lava Guard Gordoth",
				loot = {
					{ 82883, 82886, 82888 },
				},
			},
		},
	},
	{ name = "Razorfen Downs", type = "dungeon",
		bosses = {
			{ name = "Tuten'kash",
				loot = {
					{ 10776, 10777, 10775 },
				},
			},
			{ name = "Henry Stern",
				loot = {
					{ 3831 },
				},
			},
			{ name = "Mordresh Fire Eye",
				loot = {
					{ 10771, 10769, 10770 },
				},
			},
			{ name = "Glutton",
				loot = {
					{ 10774, 10772 },
				},
			},
			{ name = "Ragglesnout",
				loot = {
					{ 10768, 10758, 10767 },
				},
			},
			{ name = "Amnennar the Coldbringer",
				loot = {
					{ 10762, 10765, 10764, 10763, 10761, 10420 },
				},
			},
			{ name = "Plaguemaw the Rotting",
				loot = {
					{ 10760, 10766 },
				},
			},
			{ name = "Trash Mobs",
				loot = {
					{ 10574, 10581, 10578, 10583, 10582, 10584, 10573, 10570, 10571, 10567, 10572 },
				},
			},
		},
	},
	{ name = "Razorfen Kraul", type = "dungeon",
		bosses = {
			{ name = "Roogug",
				loot = {
					{ 6841 },
				},
			},
			{ name = "Aggem Thorncurse",
				loot = {
					{ 6681 },
				},
			},
			{ name = "Death Speaker Jargba",
				loot = {
					{ 6685, 6682, 2816 },
				},
			},
			{ name = "Razorfen Spearhide",
				loot = {
					{ 6679 },
				},
			},
			{ name = "Overlord Ramtusk",
				loot = {
					{ 6686, 6687, 6679 },
				},
			},
			{ name = "Agathelos the Raging",
				loot = {
					{ 6690, 6691 },
				},
			},
			{ name = "Blind Hunter",
				loot = {
					{ 6697, 6695, 6696 },
				},
			},
			{ name = "Charlga Razorflank",
				loot = {
					{ 6693, 6692, 6694, 17008, 5793, 5792 },
				},
			},
			{ name = "Earthcaller Halmgar",
				loot = {
					{ 6688, 6689 },
				},
			},
			{ name = "Trash Mobs",
				loot = {
					{ 2264, 1978, 1488, 4438, 2039, 776, 1727, 1975, 1976, 2549 },
				},
			},
		},
	},
	{ name = "Scarlet Monastery", type = "dungeon",
		bosses = {
			{ name = "Armory / Herod",
				loot = {
					{ 7719, 7718, 10330, 7717 },
					{ label = "Scarlet Trainee", 23192 },
				},
			},
			{ name = "Cathedral",
				loot = {
					{ label = "High Inquisitor Fairbanks", 19507, 19508, 19509 },
					{ label = "Scarlet Commander Mograine", 7724, 10330, 7723, 7726 },
					{ label = "High Inquisitor Whitemane", 7720, 7722, 7721, 20976 },
				},
			},
			{ name = "Graveyard",
				loot = {
					{ label = "Interrogator Vishas", 7683, 7682 },
					{ label = "Bloodmage Thalnos", 7684, 7685 },
					{ label = "Ironspine", 7688, 7686, 7687 },
					{ label = "Azshir the Sleepless", 7709, 7731, 7708 },
					{ label = "Fallen Champion", 7691, 7690, 7689 },
				},
			},
			{ name = "Library",
				loot = {
					{ label = "Houndmaster Loksey", 7756, 7710, 3456 },
					{ label = "Arcanist Doan", 34227, 7712, 7711, 7714, 7713 },
					{ label = "Doan's Strongbox", 7146 },
				},
			},
			{ name = "Trash Mobs (Scarlet Monastery)",
				loot = {
					{ 7728, 7755, 7727, 7760, 7754, 5819, 7759, 10328, 10332, 2262, 1992, 10333, 10331, 10329, 5756, 8225, 8226, 7786, 7761, 7753, 7752, 7736, 7730, 7758, 7757, 7787, 7729 },
				},
			},
		},
	},
	{ name = "Scholomance", type = "dungeon",
		bosses = {
			{ name = "Blood Steward of Kirtonos",
				loot = {
					{ 13523 },
				},
			},
			{ name = "Kirtonos the Herald",
				loot = {
					{ 13956, 13957, 13969, 13967, 13955, 13960, 14024, 13983, 16734 },
				},
			},
			{ name = "Jandice Barov",
				loot = {
					{ 18689, 14543, 14545, 14548, 18690, 14541, 22394, 13725, 13523, 16701 },
				},
			},
			{ name = "Rattlegore",
				loot = {
					{ 14538, 14539, 18686, 14537, 14531, 14528, 13873, 16711, 18782, 12726 },
				},
			},
			{ name = "Death Knight Darkreaver",
				loot = {
					{ 18760, 18758, 18759, 18761, 18749 },
				},
			},
			{ name = "Marduk Blackpool",
				loot = {
					{ 18692, 14576 },
				},
			},
			{ name = "Vectus",
				loot = {
					{ 14577, 18691 },
				},
			},
			{ name = "Ras Frostwhisper",
				loot = {
					{ 13314, 14340, 18693, 14503, 14502, 18694, 14522, 14525, 18695, 13952, 14487, 18696, 16689, 13521, 13626, 13986, 13984, 13982, 14002 },
					{ label = "Frostwhisper's Embalming Fluid", 12736 },
				},
			},
			{ name = "Kormok",
				loot = {
					{ label = "Dungeon Set 2 Summonable", 22303, 22326, 22331, 22332, 22333, 21984, 22046 },
				},
			},
			{ name = "Instructor Malicia",
				loot = {
					{ 16710, 18681, 14633, 14626, 14629, 14631, 14632, 14637, 14640, 14636, 14638, 18682, 14641, 14611, 14615, 14614, 14612, 14616, 14624, 14622, 14620, 14623, 14621, 18684, 23201, 23200, 18683, 18680 },
				},
			},
			{ name = "Doctor Theolen Krastinov",
				loot = {
					{ 16684, 18681, 14633, 14626, 14629, 14631, 14632, 18682, 14637, 14638, 14640, 14636, 14641, 14612, 14616, 14615, 14614, 14611, 14621, 14620, 14622, 14624, 14623, 18684, 23201, 23200, 18683, 18680, 13523 },
				},
			},
			{ name = "Lorekeeper Polkelt",
				loot = {
					{ 16705, 18681, 14633, 14626, 14629, 14631, 14632, 18682, 14637, 14638, 14640, 14636, 14641, 14612, 14616, 14615, 14614, 14611, 14621, 14620, 14622, 14624, 14623, 18684, 23201, 23200, 18683, 18680 },
				},
			},
			{ name = "The Ravenian",
				loot = {
					{ 16716, 18681, 14633, 14626, 14629, 14631, 14632, 18682, 14637, 14638, 14640, 14636, 14641, 14612, 14616, 14615, 14614, 14611, 14621, 14620, 14622, 14624, 14623, 18684, 23201, 23200, 18683, 18680 },
				},
			},
			{ name = "Lord Alexei Barov",
				loot = {
					{ 16722, 18681, 14633, 14626, 14629, 14631, 14632, 18682, 14637, 14638, 14640, 14636, 14641, 14612, 14616, 14615, 14614, 14611, 14621, 14620, 14622, 14624, 14623, 18684, 23201, 23200, 18683, 18680 },
				},
			},
			{ name = "Lady Illucia Barov",
				loot = {
					{ 18681, 14633, 14626, 14629, 14631, 14632, 18682, 14637, 14638, 14640, 14636, 14641, 14612, 14616, 14615, 14614, 14611, 14621, 14620, 14622, 14624, 14623, 18684, 23201, 23200, 18683, 18680 },
				},
			},
			{ name = "Darkmaster Gandling",
				loot = {
					{ 13937, 14514, 14153, 13944, 13398, 13950, 13951, 22433, 13964, 13953, 13938, 16698, 16686, 16693, 16707, 16720, 16677, 16667, 16731, 16727, 19276, 13501 },
				},
			},
			{ name = "Trash Mobs (Scholomance)",
				loot = {
					{ 18697, 18698, 18699, 18700, 14536, 18702, 18701, 16254, 16255, 15773, 15776, 12753, 13920, 16705, 16684, 16685, 16710, 16716, 16722 },
				},
			},
		},
	},
	{ name = "Shadowfang Keep", type = "dungeon",
		bosses = {
			{ name = "Deathsworn Captain",
				loot = {
					{ 6642, 6641 },
				},
			},
			{ name = "Rethilgore",
				loot = {
					{ 5254 },
				},
			},
			{ name = "Felsteed",
				loot = {
					{ 6341, 932 },
				},
			},
			{ name = "Razorclaw the Butcher",
				loot = {
					{ 6226, 6633, 1292 },
				},
			},
			{ name = "Baron Silverlaine",
				loot = {
					{ 6321, 6323 },
				},
			},
			{ name = "Commander Springvale",
				loot = {
					{ 3191, 6320 },
				},
			},
			{ name = "Odo the Blindwatcher",
				loot = {
					{ 6319, 6318 },
				},
			},
			{ name = "Fenrus the Devourer",
				loot = {
					{ 6340, 3230 },
				},
			},
			{ name = "Arugal's Voidwalker",
				loot = {
					{ 5943 },
				},
			},
			{ name = "Wolf Master Nandos",
				loot = {
					{ 6314, 3748 },
				},
			},
			{ name = "Archmage Arugal",
				loot = {
					{ 6324, 6392, 6220, 24224, 6895, 6283 },
				},
			},
			{ name = "Trash Mobs",
				loot = {
					{ 2292, 1974, 1489, 1935, 1482, 2205, 2807, 1318, 1483, 3194, 1484 },
				},
			},
		},
	},
	{ name = "Stratholme", type = "dungeon",
		bosses = {
			{ name = "Skul",
				loot = {
					{ 13395, 13394, 13396 },
				},
			},
			{ name = "Mailbox Keys",
				loot = {
					{ 13304, 13303, 13307, 13305, 13302, 13306 },
				},
			},
			{ name = "Fras Siabi",
				loot = {
					{ 13172, 13171 },
				},
			},
			{ name = "Atiesh <Hand of Sargeras>",
				loot = {
					{ 22736 },
				},
			},
			{ name = "Hearthsinger Forresten",
				loot = {
					{ 13378, 13383, 13384, 13379, 16682 },
				},
				heroic = {
					{ 13379, 13384, 13378, 13383 },
				},
			},
			{ name = "The Unforgiven",
				loot = {
					{ 13409, 13404, 13405, 13408, 16717 },
				},
				heroic = {
					{ 13404, 13408, 13409, 13405 },
				},
			},
			{ name = "Timmy the Cruel",
				loot = {
					{ 13403, 13402, 13400, 13401, 16724 },
				},
				heroic = {
					{ 13403, 13401, 13402, 13400 },
				},
			},
			{ name = "Malor's Strongbox",
				loot = {
					{ label = "Malor's Strongbox", 12845 },
				},
			},
			{ name = "Crimson Hammersmith (Summon)",
				loot = {
					{ 18781, 12726, 13351, 12824 },
				},
			},
			{ name = "Plans: Serenity",
				loot = {
					{ 12827 },
				},
			},
			{ name = "Cannon Master Willey",
				loot = {
					{ 22405, 22407, 18721, 13381, 22403, 13382, 22404, 22406, 13380, 13377, 16708, 12839, 12783 },
				},
			},
			{ name = "Archivist Galford",
				loot = {
					{ 13386, 18716, 13387, 13385, 22897, 12811 },
					{ label = "Unfinished Painting", 14679, 16692 },
				},
			},
			{ name = "Balnazzar",
				loot = {
					{ 13353, 14512, 14154, 18720, 13369, 13358, 13359, 18718, 12103, 13360, 13348, 18717, 16725, 13520, 13250 },
				},
				heroic = {
					{ 13353, 13359, 13348, 13369, 13360, 18718, 18717, 18720, 12103, 13358 },
				},
			},
			{ name = "Sothos and Jarien",
				loot = {
					{ label = "Dungeon Set 2 Summonable", 22301, 22328, 22327, 22334, 22329, 21984, 22046 },
				},
			},
			{ name = "Stonespine",
				loot = {
					{ 13397, 13954, 13399 },
				},
			},
			{ name = "Baroness Anastari",
				loot = {
					{ 18730, 18728, 13534, 18729, 13535, 13537, 13538, 13539, 13514, 16704 },
				},
				heroic = {
					{ 18728, 13534, 13539, 13537, 13535, 18729, 18730, 13538 },
				},
			},
			{ name = "Black Guard Swordsmith (Summon)",
				loot = {
					{ 18783, 12725, 13350, 12825 },
				},
			},
			{ name = "Plans: Corruption",
				loot = {
					{ 12830 },
				},
			},
			{ name = "Nerub'enkan",
				loot = {
					{ 18740, 18739, 13529, 18738, 13530, 13531, 13532, 13533, 13508, 16675 },
				},
				heroic = {
					{ 13533, 18738, 18739, 13531, 13532, 13530, 13529, 18740 },
				},
			},
			{ name = "Maleki the Pallid",
				loot = {
					{ 18734, 18735, 13524, 18737, 13525, 13526, 13528, 13527, 13509, 16691, 12833, 12796 },
				},
				heroic = {
					{ 18737, 13525, 13526, 13527, 18735, 18734, 13524, 13528 },
				},
			},
			{ name = "Magistrate Barthilas",
				loot = {
					{ 13376, 18727, 18726, 18722, 23198, 18725, 12382 },
				},
				heroic = {
					{ 18727, 18722, 18726, 18725, 13376 },
				},
			},
			{ name = "Ramstein the Gorger",
				loot = {
					{ 13374, 18723, 13373, 13515, 13372, 13375, 16737 },
				},
				heroic = {
					{ 18723, 13373, 13375, 13515, 13372, 13374 },
				},
			},
			{ name = "Baron Rivendare",
				loot = {
					{ 13505, 13335, 13340, 22412, 13346, 22409, 13344, 22410, 22411, 13345, 13368, 13361, 13349, 22408, 16687, 16699, 16694, 16709, 16719, 16668, 16678, 16732, 16728, 13251, 13246, 13249, 13243 },
				},
			},
			{ name = "Trash Mobs (Stratholme)",
				loot = {
					{ 18743, 17061, 18745, 18744, 18736, 18742, 18741, 16249, 16248, 18658, 16052, 15777, 15768, 14495, 16697, 16702, 16685, 16714, 16681, 16671, 16736, 16723, 12811, 12735 },
				},
			},
			{ name = "Willey Hopebreaker",
				loot = {
					{ 18721, 13382, 22403, 22407, 22405, 13381, 22406, 22404, 13380 },
				},
				heroic = {
					{ 18721, 13382, 22403, 22407, 22405, 13381, 22406, 22404, 13380 },
				},
			},
			{ name = "Instructor Galford",
				loot = {
					{ 13386, 18716, 13387, 13385 },
				},
				heroic = {
					{ 13386, 18716, 13387, 13385 },
				},
			},
			{ name = "Lord Aurius Rivendare",
				loot = {
					{ 13368, 13340, 13335, 13344, 22410, 22411, 22408, 13346, 13505, 13349, 13345, 13361, 22412, 22409 },
				},
				heroic = {
					{ 13368, 13340, 13335, 13344, 22410, 22411, 22408, 13346, 13505, 13349, 13345, 13361, 22412, 22409 },
				},
			},
		},
	},
	{ name = "The Deadmines", type = "dungeon",
		bosses = {
			{ name = "Marisa du'Paige",
				loot = {
					{ 3019, 4660 },
				},
			},
			{ name = "Brainwashed Noble",
				loot = {
					{ 5967, 3902 },
				},
			},
			{ name = "Foreman Thistlenettle",
				loot = {
					{ 1875 },
				},
			},
			{ name = "Rhahk'Zor",
				loot = {
					{ 872, 5187 },
				},
			},
			{ name = "Miner Johnson",
				loot = {
					{ 5444, 5443 },
				},
			},
			{ name = "Sneed's Shredder",
				loot = {
					{ 2169, 1937, 7365 },
				},
			},
			{ name = "Sneed",
				loot = {
					{ 5195, 5194, 5397 },
				},
			},
			{ name = "Gilnid",
				loot = {
					{ 5199, 1156 },
				},
			},
			{ name = "Captain Greenskin",
				loot = {
					{ 10403, 5200, 5201 },
				},
			},
			{ name = "Mr. Smite",
				loot = {
					{ 5192, 5196, 7230 },
				},
			},
			{ name = "Cookie",
				loot = {
					{ 5197, 5198, 8490 },
				},
			},
			{ name = "Edwin VanCleef",
				loot = {
					{ 5193, 5202, 10399, 5191, 2874, 3637 },
				},
			},
		},
	},
	{ name = "The Stockade", type = "dungeon",
		bosses = {
			{ name = "Targorr the Dread",
				loot = {
					{ 3630 },
				},
			},
			{ name = "Kam Deepfury",
				loot = {
					{ 2280, 3640 },
				},
			},
			{ name = "Bazil Thredd",
				loot = {
					{ 2926 },
				},
			},
			{ name = "Dextren Ward",
				loot = {
					{ 3628 },
				},
			},
			{ name = "Bruegal Ironknuckle",
				loot = {
					{ 3228, 2942, 2941 },
				},
			},
			{ name = "Trash Mobs",
				loot = {
					{ 2909 },
				},
			},
			{ name = "Hogger",
				loot = {
					{ 1959, 2168, 1934 },
				},
			},
			{ name = "Lord Overheat",
				loot = {
					{ 1929, 5967, 4676 },
				},
			},
			{ name = "Randolph Moloch",
				loot = {
					{ 63344, 63345, 63346 },
				},
			},
		},
	},
	{ name = "The Temple of Atal'Hakkar", type = "dungeon",
		bosses = {
			{ name = "Spawn of Hakkar",
				loot = {
					{ 10802, 10801 },
				},
			},
			{ name = "Troll Minibosses",
				loot = {
					{ 10787, 10783, 10785, 10784, 10786, 10788, 20606, 20607, 20608 },
				},
			},
			{ name = "Atal'alarion",
				loot = {
					{ 10800, 10798, 10799 },
				},
			},
			{ name = "Dreamscythe",
				loot = {
					{ 12465, 12466, 12464, 10795, 10796, 10797, 12463, 12243 },
				},
			},
			{ name = "Weaver",
				loot = {
					{ 12465, 12466, 12464, 10795, 10796, 10797, 12463, 12243 },
				},
			},
			{ name = "Avatar of Hakkar",
				loot = {
					{ 12462, 10843, 10842, 10846, 10845, 10838, 10844, 10663 },
				},
			},
			{ name = "Jammal'an the Prophet",
				loot = {
					{ 10806, 10808, 10807, 6212 },
				},
			},
			{ name = "Ogom the Wretched",
				loot = {
					{ 10805, 10804, 10803 },
				},
			},
			{ name = "Morphaz",
				loot = {
					{ 12465, 12466, 12464, 10795, 10796, 10797, 12463, 12243, 20022, 20085, 20025, 20019 },
				},
			},
			{ name = "Hazzas",
				loot = {
					{ 12465, 12466, 12464, 10795, 10796, 10797, 12463, 12243 },
				},
			},
			{ name = "Shade of Eranikus",
				loot = {
					{ 10847, 10833, 10829, 10828, 10837, 10835, 10836, 10454, 10455 },
				},
			},
			{ name = "Trash Mobs (The Temple of Atal'Hakkar)",
				loot = {
					{ 10630, 10629, 10632, 10631, 10633, 10634, 15733, 16216, 11318, 6181, 10623, 10625, 10628, 10626, 10627, 10624 },
				},
			},
			{ name = "Wardens of the Dream",
				loot = {
					{ 10796, 10797, 12243, 12466, 12464, 10795, 12463, 12465 },
				},
			},
		},
	},
	{ name = "Uldaman", type = "dungeon",
		bosses = {
			{ name = "Digmaster Shovelphlange",
				loot = {
					{ 9375, 9378, 9382 },
				},
			},
			{ name = "Baelog",
				loot = {
					{ label = "Baelog", 9401, 9400, 9399 },
					{ label = "Eric 'The Swift'", 9394, 9398, 2459 },
					{ label = "Olaf", 9404, 9403, 1177 },
					{ label = "Baelog's Chest", 7740 },
					{ label = "Conspicuous Urn", 7671 },
				},
			},
			{ name = "Revelosh",
				loot = {
					{ 9390, 9389, 9388, 9387, 7741 },
				},
			},
			{ name = "Ironaya",
				loot = {
					{ 9407, 9409, 9408 },
				},
			},
			{ name = "Ancient Stone Keeper",
				loot = {
					{ 9411, 9410 },
				},
			},
			{ name = "Galgann Firehammer",
				loot = {
					{ 11311, 11310, 9419, 9412 },
				},
			},
			{ name = "Grimlok",
				loot = {
					{ 9415, 9414, 9416, 7670 },
				},
			},
			{ name = "Archaedas",
				loot = {
					{ 11118, 9418, 9413, 7672 },
				},
			},
			{ name = "Trash Mobs (Uldaman)",
				loot = {
					{ 9397, 9431, 9429, 9420, 9406, 9428, 9430, 9396, 9432, 9393, 7666, 7673, 9384, 9392, 9424, 9465, 9383, 9425, 9386, 9427, 9423, 9391, 9381, 9426, 9422 },
				},
			},
			{ name = "The Lost Dwarves",
				loot = {
					{ 9394, 9400, 9401, 9403, 9404, 9398 },
				},
			},
		},
	},
	{ name = "Upper Blackrock Spire", type = "dungeon",
		bosses = {
			{ name = "Pyroguard Emberseer",
				loot = {
					{ 12905, 12927, 12929, 12926, 17322, 21988, 16672 },
				},
				heroic = {
					{ 12929, 12926, 12927, 12905 },
				},
			},
			{ name = "Solakar Flamewreath",
				loot = {
					{ 12609, 12589, 12603, 12606, 18657, 18638, 16695 },
				},
				heroic = {
					{ 12606, 12589, 12603, 12609 },
				},
			},
			{ name = "Father Flame",
				loot = {
					{ 13371 },
				},
			},
			{ name = "Jed Runewatcher",
				loot = {
					{ 12604, 12930, 12605 },
				},
			},
			{ name = "Goraluk Anvilcrack",
				loot = {
					{ 18047, 13502, 13498, 18048, 12837, 12794, 12834, 12790, 18779, 12727 },
					{ label = "Unforged Rune Covered Breastplate", 12806, 12696 },
				},
			},
			{ name = "Warchief Rend Blackhand",
				loot = {
					{ 12590, 22247, 18102, 12587, 12588, 18104, 12936, 12935, 18103, 16733, 12940, 12939, 12583, 12630, 12952, 12953, 12960, 22225 },
				},
				heroic = {
					{ 18103, 12936, 12583, 12940, 12939, 12953, 18102, 22225, 12587, 22247, 12590, 18104, 12952, 12960, 12935 },
				},
			},
			{ name = "Gyth",
				loot = {
					{ 12871, 12945, 12903, 12895, 22225, 12960, 12953, 12952, 13522, 16669 },
				},
			},
			{ name = "The Beast",
				loot = {
					{ 12731, 12752, 12757, 12756, 12967, 12968, 12965, 22311, 12966, 12963, 12964, 12709, 12969, 16729, 24101, 19227 },
				},
				heroic = {
					{ 12966, 12963, 12967, 12709, 12968, 12969, 12965, 12964 },
				},
			},
			{ name = "Lord Valthalak (Summon)",
				loot = {
					{ label = "Dungeon Set 2 Summonable", 22337, 22302, 22342, 22343, 22340, 22339, 22335, 22336 },
				},
			},
			{ name = "General Drakkisath",
				loot = {
					{ 12592, 22269, 22267, 13142, 13141, 13098, 22268, 22253, 12602, 15730, 15047, 13519, 16688, 16700, 16690, 16706, 16721, 16674, 16666, 16730, 16726, 16663 },
				},
				heroic = {
					{ 12592, 13142, 12602, 22268, 13098, 22269, 22267, 22253, 13141 },
				},
			},
			{ name = "Trash Mobs (Upper Blackrock Spire)",
				loot = {
					{ 13260, 24102, 16247, 12607, 12219 },
				},
			},
		},
	},
	{ name = "Wailing Caverns", type = "dungeon",
		bosses = {
			{ name = "Kalldan Felmoon",
				loot = {
					{ 6475, 6474 },
				},
			},
			{ name = "Mad Magglish",
				loot = {
					{ 5334 },
				},
			},
			{ name = "Trigore the Lasher",
				loot = {
					{ 5425, 5426 },
				},
			},
			{ name = "Boahn",
				loot = {
					{ 5423, 5422 },
				},
			},
			{ name = "Lord Cobrahn",
				loot = {
					{ 6465, 10410, 6460 },
				},
			},
			{ name = "Lady Anacondra",
				loot = {
					{ 5404, 10412, 6446 },
				},
			},
			{ name = "Kresh",
				loot = {
					{ 13245, 6447 },
				},
			},
			{ name = "Lord Pythas",
				loot = {
					{ 6473, 6472 },
				},
			},
			{ name = "Skum",
				loot = {
					{ 6449, 6448 },
				},
			},
			{ name = "Lord Serpentis",
				loot = {
					{ 5970, 10411, 6459, 6469 },
				},
			},
			{ name = "Verdan the Everliving",
				loot = {
					{ 6629, 6631, 6630 },
				},
			},
			{ name = "Mutanus the Devourer",
				loot = {
					{ 6461, 6627, 6463, 10441 },
				},
			},
			{ name = "Deviate Faerie Dragon",
				loot = {
					{ 6632, 5243 },
				},
			},
		},
	},
	{ name = "Zul'Farrak", type = "dungeon",
		bosses = {
			{ name = "Antu'sul",
				loot = {
					{ 9640, 9641, 9639, 9379, 9372 },
				},
			},
			{ name = "Theka the Martyr",
				loot = {
					{ 10660 },
				},
			},
			{ name = "Witch Doctor Zum'rah",
				loot = {
					{ 18083, 18082 },
				},
			},
			{ name = "Nekrum Gutchewer",
				loot = {
					{ 9471 },
				},
			},
			{ name = "Shadowpriest Sezz'ziz",
				loot = {
					{ 9470, 9473, 9474, 9475 },
				},
			},
			{ name = "Dustwraith",
				loot = {
					{ 12471 },
				},
			},
			{ name = "Sergeant Bly",
				loot = {
					{ 8548 },
				},
			},
			{ name = "Sandfury Executioner",
				loot = {
					{ 8444 },
				},
			},
			{ name = "Hydromancer Velratha",
				loot = {
					{ 9234, 10661 },
				},
			},
			{ name = "Gahz'rilla",
				loot = {
					{ 9469, 9467, 8707 },
				},
			},
			{ name = "Chief Ukorz Sandscalp",
				loot = {
					{ 9479, 9476, 9478, 9477, 11086, 9372 },
				},
			},
			{ name = "Zerillis",
				loot = {
					{ 12470 },
				},
			},
			{ name = "Trash Mobs (Zul'Farrak)",
				loot = {
					{ 9512, 9484, 862, 6440, 9243, 9523, 9238, 5616, 9511, 9481, 9480, 9482, 9483, 2040 },
				},
			},
			{ name = "Nekrum & Sezz'ziz",
				loot = {
					{ 9473, 9470, 9475, 9474 },
				},
			},
		},
	},
	{ name = "Blackwing Lair", type = "raid",
		bosses = {
			{ name = "Razorgore the Untamed",
				loot = {
					{ 16918, 16926, 16934, 16911, 16904, 16935, 16943, 16959, 16951, 19337, 19336, 19370, 19369, 19334, 19335 },
				},
			},
			{ name = "Vaelastrasz the Corrupt",
				loot = {
					{ 16818, 16925, 16933, 16936, 16903, 16910, 16944, 16960, 16952, 19339, 19340, 19372, 19371, 19346, 19348 },
				},
			},
			{ name = "Broodlord Lashlayer",
				loot = {
					{ 16912, 16919, 16927, 16898, 16906, 16941, 16949, 16965, 16957, 20383, 19342, 19341, 19374, 19373, 19351, 19350 },
				},
			},
			{ name = "Firemaw",
				loot = {
					{ 16913, 16920, 16928, 16907, 16940, 16899, 16948, 16964, 16956, 19365, 19355, 19353, 19343, 19344, 19398, 19400, 19399, 19396, 19401, 19394, 19402, 19397, 19395 },
				},
			},
			{ name = "Ebonroc",
				loot = {
					{ 16913, 16920, 16928, 16907, 16940, 16899, 16948, 16964, 16956, 19345, 19407, 19405, 19396, 19394, 19403, 19397, 19406, 19395, 19353, 19355, 19368 },
				},
			},
			{ name = "Flamegor",
				loot = {
					{ 16913, 16920, 16928, 16907, 16940, 16899, 16948, 16964, 16956, 19430, 19396, 19433, 19394, 19397, 19432, 19395, 19431, 19353, 19357, 19355, 19367 },
				},
			},
			{ name = "Chromaggus",
				loot = {
					{ 16917, 16924, 16932, 16937, 16902, 16832, 16945, 16953, 16961, 19386, 19388, 19385, 19391, 19389, 19390, 19393, 19392, 19387, 19347, 19352, 19349, 19361 },
				},
			},
			{ name = "Nefarian",
				loot = {
					{ 16914, 16916, 16929, 16931, 16921, 16923, 16908, 16905, 16900, 16897, 16939, 16942, 16947, 16950, 16963, 16966, 16955, 16958, 19378, 19375, 19381, 19380, 19377, 19376, 19382, 19379, 19364, 19363, 19360, 19356 },
				},
			},
			{ name = "Trash Mobs (Blackwing Lair)",
				loot = {
					{ 19436, 19437, 19438, 19439, 19434, 19362, 19354, 19358, 19435, 18562, 21109 },
				},
			},
		},
	},
	{ name = "Molten Core", type = "raid",
		bosses = {
			{ name = "Lucifron",
				loot = {
					{ 18872, 19145, 19146, 18875, 18870, 18861, 17109, 18879, 19147, 18878, 17077, 16800, 16805, 16829, 16837, 16863, 16859, 17329 },
				},
				heroic = {
					{ 18872, 19145, 19146, 18875, 18870, 18861, 17109, 18879, 19147, 18878, 17077, 16800, 16805, 16829, 16837, 16863, 16859 },
				},
			},
			{ name = "Magmadar",
				loot = {
					{ 19136, 18823, 18829, 19144, 19143, 18861, 18824, 17065, 18821, 18820, 19142, 18203, 18822, 17073, 17069, 16796, 16814, 16810, 16822, 16847, 16835, 16843, 16855, 16867, 93034, 18202 },
				},
				heroic = {
					{ 19136, 18823, 18829, 19144, 19143, 18861, 18824, 17065, 18821, 18820, 19142, 18203, 18822, 17073, 17069, 16796, 16814, 16810, 16822, 16847, 16835, 16843, 16855, 16867, 93034, 18202 },
				},
			},
			{ name = "Gehennas",
				loot = {
					{ 19145, 18872, 19146, 18875, 18870, 18861, 18879, 19147, 18878, 17077, 16812, 16826, 16849, 16839, 16862, 16860, 17331 },
				},
				heroic = {
					{ 19145, 18872, 19146, 18875, 18870, 18861, 18879, 19147, 18878, 17077, 16812, 16826, 16849, 16839, 16862, 16860 },
				},
			},
			{ name = "Garr",
				loot = {
					{ 19136, 18823, 18829, 19144, 19143, 18861, 18824, 18821, 18820, 19142, 17071, 18832, 18822, 17105, 17066, 16795, 16813, 16808, 16846, 16834, 16821, 16842, 16866, 16854, 18564, 19019 },
				},
				heroic = {
					{ 19136, 18823, 18829, 19144, 19143, 18861, 18824, 18821, 18820, 19142, 17071, 18832, 18822, 17105, 17066, 16795, 16813, 16808, 16846, 16834, 16821, 16842, 16866, 16854, 18564 },
				},
			},
			{ name = "Shazzrah",
				loot = {
					{ 19145, 18872, 19146, 18875, 18870, 18861, 18879, 19147, 18878, 17077, 16801, 16803, 16811, 16831, 16852, 16824, 17332 },
				},
				heroic = {
					{ 19145, 18872, 19146, 18875, 18870, 18861, 18879, 19147, 18878, 17077, 16801, 16803, 16811, 16831, 16852, 16824 },
				},
			},
			{ name = "Baron Geddon",
				loot = {
					{ 19136, 18823, 18829, 19144, 19143, 18861, 18824, 17110, 18821, 18820, 19142, 18822, 16797, 16807, 16836, 16856, 16844, 18563, 19019 },
				},
				heroic = {
					{ 19136, 18823, 18829, 19144, 19143, 18861, 18824, 17110, 18821, 18820, 19142, 18822, 16797, 16807, 16836, 16856, 16844, 18563 },
				},
			},
			{ name = "Golemagg the Incinerator",
				loot = {
					{ 19136, 18823, 18829, 19144, 19143, 18861, 18824, 18821, 18820, 19142, 17103, 18822, 18842, 17072, 16798, 16815, 16809, 16820, 16833, 16845, 16841, 16865, 16853, 17203, 17182, 93035 },
				},
				heroic = {
					{ 19136, 18823, 18829, 19144, 19143, 18861, 18824, 18821, 18820, 19142, 17103, 18822, 18842, 17072, 16798, 16815, 16809, 16820, 16833, 16845, 16841, 16865, 16853, 17203, 93035 },
				},
			},
			{ name = "Sulfuron Harbinger",
				loot = {
					{ 19145, 18872, 19146, 18875, 18870, 18861, 18879, 19147, 18878, 17074, 17077, 16816, 16823, 16848, 16868, 17330, 93033 },
				},
				heroic = {
					{ 19145, 18872, 19146, 18875, 18870, 18861, 18879, 19147, 18878, 17074, 17077, 16816, 16823, 16848, 16868, 93033 },
				},
			},
			{ name = "Majordomo Executus",
				loot = {
					{ 18811, 18808, 18809, 19139, 18810, 18812, 18806, 19140, 18805, 18803, 18703, 18715, 18713, 18714, 18646, 18608, 18609 },
				},
				heroic = {
					{ 18811, 18808, 18809, 19139, 18810, 18812, 18806, 19140, 18805, 18803 },
				},
			},
			{ name = "Ragnaros",
				loot = {
					{ 16915, 16922, 16930, 16909, 16901, 16938, 16946, 16962, 16954, 17204, 17182, 19017, 19019, 17102, 17107, 18817, 19137, 18814, 19138, 17063, 17082, 18815, 18816, 17076, 17104, 17106, 21110, 138833 },
				},
				heroic = {
					{ 16915, 16922, 16930, 16909, 16901, 16938, 16946, 16962, 16954, 17204, 17102, 17107, 18817, 19137, 18814, 19138, 17063, 17082, 18815, 18816, 17076, 17104, 17106, 138833 },
				},
			},
			{ name = "Trash Mobs (Molten Core)",
				loot = {
					{ 16802, 16817, 16806, 16827, 16828, 16851, 16838, 16864, 16858, 17010, 17011, 11382, 17012, 16799, 16819, 16804, 16825, 16830, 16850, 16840, 16861, 16857 },
				},
			},
			{ name = "Random Boss Drops",
				loot = {
					{ 18264, 18262, 18292, 18282, 18291, 18168, 18290, 18283, 18259, 18252, 18251, 18265, 18263, 21371, 21342, 18257, 18253, 18260 },
				},
			},
		},
	},
	{ name = "Ruins of Ahn'Qiraj", type = "raid",
		bosses = {
			{ name = "Kurinnaxx",
				loot = {
					{ 21499, 21498, 21500, 21501, 21502, 21503, 22217, 20889, 20885, 20884, 20888 },
				},
			},
			{ name = "General Rajaxx",
				loot = {
					{ 21493, 21492, 21496, 21494, 21497, 21495 },
					{ label = "Rajaxx's Captains", 21810, 21809, 21806, 20889, 20885, 20884, 20888 },
					{ label = "Lieutenant General Andorov", 22221, 22219 },
				},
			},
			{ name = "Moam",
				loot = {
					{ 21472, 21467, 21479, 21471, 21470, 21468, 21455, 21474, 21469, 21476, 21475, 21477, 21473, 20886, 20890, 20884, 20888, 22220, 22194 },
				},
			},
			{ name = "Buru the Gorger",
				loot = {
					{ 21487, 21486, 21485, 21489, 21491, 21490, 21488, 20886, 20890, 20889, 20885, 20884, 20888 },
				},
			},
			{ name = "Ayamiss the Hunter",
				loot = {
					{ 21479, 21466, 21478, 21484, 21480, 21482, 21481, 21483, 20886, 20890, 20889, 20885, 20884, 20888 },
				},
			},
			{ name = "Ossirian the Unscarred",
				loot = {
					{ 21456, 21464, 21462, 21461, 21458, 21454, 21463, 21460, 21453, 21457, 21715, 21459, 21452, 21220, 21504, 21507, 21505, 21506, 20886, 20890, 20884, 20888 },
				},
			},
			{ name = "Trash Mobs (AQ20)",
				loot = {
					{ 20873, 20869, 20866, 20870, 20868, 20871, 20867, 20872, 22202, 22203, 20864, 20861, 20863, 20862, 20859, 20865, 20860, 20858, 21761 },
				},
			},
			{ name = "AQ Class Books",
				loot = {
					{ 21294, 21296, 21295, 21306, 21304, 21307, 21279, 21214, 21280, 21288, 21289, 21290, 21284, 21287, 21285, 21300, 21303, 21302, 21291, 21292, 21293, 21281, 21283, 21282, 21298, 21299, 21297 },
				},
			},
			{ name = "AQ Enchants",
				loot = {
					{ 20728, 20731, 20734, 20729, 20736, 20730, 20727 },
				},
			},
			{ name = "AQ20 Class Sets",
				loot = {
					{ label = "Symbols of Unending Life", 21407, 21409, 21408 },
					{ label = "Trappings of the Unseen Path", 21401, 21403, 21402 },
					{ label = "Trappings of Vaulted Secrets", 21413, 21415, 21414 },
					{ label = "Battlegear of Eternal Justice", 21395, 21397, 21396 },
					{ label = "Finery of Infinite Wisdom", 21410, 21412, 21411 },
					{ label = "Emblems of Veiled Shadows", 21404, 21406, 21405 },
				},
			},
		},
	},
	{ name = "Temple of Ahn'Qiraj", type = "raid",
		bosses = {
			{ name = "The Prophet Skeram",
				loot = {
					{ 21701, 21708, 21698, 21699, 21705, 21814, 21704, 21706, 21702, 21700, 21707, 21703, 21128, 21237, 21273, 21275, 21268, 21232, 21242, 21272, 21244, 21269, 22222, 22196 },
				},
			},
			{ name = "The Bug Family",
				loot = {
					{ 21697, 21694, 21696, 21693, 21692, 21695, 21237, 21232, 21680, 21603, 21681, 21685, 21689, 21691, 21688, 21690, 21686, 21682, 21684, 21683, 21687 },
				},
			},
			{ name = "Battleguard Sartura",
				loot = {
					{ 21671, 21676, 21648, 21669, 21672, 21675, 21668, 21674, 21667, 21678, 21670, 21666, 21673, 21237, 21273, 21275, 21268, 21232, 21242, 21272, 21244, 21269 },
				},
			},
			{ name = "Fankriss the Unyielding",
				loot = {
					{ 21627, 21663, 21665, 21645, 21651, 21639, 21652, 21647, 21664, 22402, 22396, 21650, 21635, 21237, 21273, 21275, 21268, 21232, 21242, 21272, 21244, 21269 },
				},
			},
			{ name = "Viscidus",
				loot = {
					{ 21624, 21626, 21623, 21677, 21625, 22399, 21622, 20932, 20928, 21237, 21273, 21275, 21268, 21232, 21242, 21272, 21244, 21269 },
				},
			},
			{ name = "Princess Huhuran",
				loot = {
					{ 21619, 21621, 21617, 21618, 21620, 21616, 20932, 20928, 21237, 21273, 21275, 21268, 21232, 21242, 21272, 21244, 21269 },
				},
			},
			{ name = "The Twin Emperors",
				loot = {
					{ 20930, 21600, 21602, 21599, 21598, 21597, 21601, 20735, 21232, 21242, 21272, 21244, 21269, 20926, 21604, 21605, 21609, 21607, 21606, 21679, 21608, 20726, 21237, 21273, 21275, 21268 },
				},
			},
			{ name = "Ouro",
				loot = {
					{ 21615, 21611, 23558, 23570, 23557, 21610, 20927, 20931, 21237, 21273, 21275, 21268, 21232, 21242, 21272, 21244, 21269 },
				},
			},
			{ name = "C'Thun",
				loot = {
					{ 21583, 22731, 21585, 22730, 21582, 21586, 21581, 22732, 21596, 21579, 21126, 21134, 21839, 20933, 20929, 21221, 21710, 21712, 21709, 22734, 22632, 22589, 22631, 22630 },
				},
			},
			{ name = "Trash Mobs (AQ40)",
				loot = {
					{ 21838, 21888, 21889, 21836, 21891, 21856, 21837, 22202, 22203, 21218, 21324, 21323, 21321 },
				},
			},
			{ name = "AQ Enchants",
				loot = {
					{ 20728, 20731, 20734, 20729, 20736, 20730, 20727 },
				},
			},
			{ name = "AQ Opening Quest Line",
				loot = {
					{ 21138, 21530, 21529, 21139, 21532, 21531, 21137, 21517, 21527, 21526, 21025, 21175, 21176, 21522, 21523, 21520, 21521 },
				},
			},
		},
	},
	{ name = "Zul'Gurub", type = "raid",
		bosses = {
			{ name = "High Priestess Jeklik",
				loot = {
					{ 19717, 19716, 19718, 19721, 19720, 19719, 19724, 19723, 19722, 19943, 19881, 19918, 19928, 20262, 20265, 19923, 19920, 19915 },
				},
			},
			{ name = "High Priest Venoxis",
				loot = {
					{ 19716, 19718, 19717, 19720, 19721, 19719, 19722, 19723, 19724, 19943, 19881, 22216, 19904, 19903, 19907, 19906, 19905, 19900 },
				},
			},
			{ name = "High Priestess Mar'li",
				loot = {
					{ 19720, 19719, 19721, 19718, 19716, 19717, 19722, 19723, 19724, 19943, 19881, 20032, 19927, 19919, 19871, 19925, 19930 },
				},
			},
			{ name = "Bloodlord Mandokir",
				loot = {
					{ 19723, 19724, 19722, 19720, 19719, 19721, 19716, 19718, 19717, 22637, 19943, 19867, 19866, 19874, 20038, 19872, 19870, 19895, 19869, 19877, 19878, 19873, 19893, 19863 },
				},
			},
			{ name = "Gri'lek",
				loot = {
					{ 19961, 19962, 19939 },
				},
			},
			{ name = "Hazza'rah",
				loot = {
					{ 19968, 19967, 19942 },
				},
			},
			{ name = "Renataki",
				loot = {
					{ 19964, 19963, 19940 },
				},
			},
			{ name = "Wushoolay",
				loot = {
					{ 19965, 19993, 19941 },
				},
			},
			{ name = "Gahz'ranka",
				loot = {
					{ 19945, 19944, 19947, 19946, 22739 },
				},
			},
			{ name = "High Priest Thekal",
				loot = {
					{ 19720, 19721, 19719, 19716, 19718, 19717, 19943, 19881, 19897, 19896, 19902, 19898, 19899, 20260, 20266, 19901 },
				},
			},
			{ name = "High Priestess Arlokk",
				loot = {
					{ 19721, 19720, 19719, 19716, 19717, 19718, 19722, 19723, 19724, 19943, 19881, 19910, 19909, 19913, 19912, 19922, 19914 },
				},
			},
			{ name = "Jin'do the Hexxer",
				loot = {
					{ 19723, 19722, 19724, 19721, 19719, 19720, 19716, 19717, 19718, 22637, 19943, 19885, 19891, 19890, 19884, 19888, 19886, 19929, 19889, 19892, 19875, 19887, 19894 },
				},
			},
			{ name = "Hakkar",
				loot = {
					{ 19857, 20257, 20264, 19855, 19876, 19856, 19859, 19864, 19865, 19854, 19852, 19862, 19853, 19861, 19802, 19950, 19949, 19948, 19943 },
				},
			},
			{ name = "Shared ZG Priest Drops",
				loot = {
					{ 22721, 22722, 22711, 22712, 22720, 22716, 22718, 22715, 22714, 22713 },
				},
			},
			{ name = "Trash Mobs (Zul'Gurub)",
				loot = {
					{ 20259, 20261, 20263, 19908, 19921, 20258, 19727, 48126, 19726, 19774, 19767, 19768, 19821, 19816, 19818, 19815, 19820, 19814, 19817, 19819, 19813 },
				},
			},
			{ name = "ZG Enchants",
				loot = {
					{ 19790, 19785, 19787, 19783, 19789, 19784, 19786, 19788, 19782, 20077, 20076, 20078, 22635 },
				},
			},
		},
	},
})
