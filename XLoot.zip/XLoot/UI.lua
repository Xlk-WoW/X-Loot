--[[ XLoot - UI
	Flat, minimal browser: expansion tabs / instances / bosses / loot.
	Built only from core frames, no Blizzard templates and no libraries.
]]

local ADDON, GL = ...

local FLAT = "Interface\\Buttons\\WHITE8X8"

-- JunkieUI font (Expressway). Validated once so a missing file falls back to the stock font.
local JUNKIE_FONT = "Interface\\AddOns\\XLoot\\Media\\Expressway.ttf"
local FONT = (function()
	local t = UIParent:CreateFontString(nil, "OVERLAY")
	local ok = t:SetFont(JUNKIE_FONT, 12)
	t:Hide()
	return ok and JUNKIE_FONT or (STANDARD_TEXT_FONT or "Fonts\\ARIALN.TTF")
end)()
GL.font = FONT
local DOT  = "  \194\183  "      -- UTF-8 middle dot

-- JunkieUI palette: warm near-black panels, feather orange accent, warm orange hover
local C = {
	bg     = { 0.055, 0.055, 0.055, 1 },       -- #0e0e0e window / inset fields
	panel  = { 0.090, 0.090, 0.090, 1 },       -- #171717 inner panels
	field  = { 0.055, 0.055, 0.055, 1 },
	border = { 0.180, 0.170, 0.140, 1 },
	accent = { 0.871, 0.447, 0.188 },          -- #de7230
	hl     = { 0.180, 0.110, 0.060, 1 },       -- warm orange hover / selected fill
	text   = { 0.860, 0.840, 0.780 },
	muted  = { 0.550, 0.530, 0.480 },
	dim    = { 0.380, 0.360, 0.320 },
	folder = { 0.871, 0.447, 0.188 },          -- section headings use the accent, like JunkieUI
	rule   = { 0.350, 0.300, 0.150, 1 },       -- heading underline
}

-- layout
local FRAME_W, FRAME_H = 920, 740
local HEADER_H         = 56                          -- title + subtitle + search
local TABS_H           = 30                          -- expansion tabs under the header
local BODY_TOP         = 96
local FOOTER_H         = 40
local BODY_H           = FRAME_H - BODY_TOP - FOOTER_H - 6
local ZONE_W, BOSS_W   = 272, 232
local LOOT_W           = FRAME_W - 20 - ZONE_W - BOSS_W - 12
local ZONE_ROW, BOSS_ROW, LOOT_ROW = 22, 28, 28
local LOOT_HEAD        = 122
local BOSS_HEAD        = 36   -- "Normal | Heroic" selector bar above the boss list

-- runtime state
local S = { ex = "Classic", zi = 1, bi = 1, mode = "loot", search = nil, results = {} }

---------------------------------------------------------------------------
-- small helpers
---------------------------------------------------------------------------

-- One screen pixel expressed in the window's own units (recomputed when the window is shown).
local PIXEL = 1
local skinned = setmetatable({}, { __mode = "k" })

local function ComputePixel()
	local scale = (GL.frame and GL.frame:GetEffectiveScale()) or UIParent:GetEffectiveScale() or 1
	local res = GetCVar and GetCVar("gxResolution")
	local h = res and tonumber(strmatch(res, "%d+x(%d+)"))
	if not h or h <= 0 then h = 768 end
	local px = 1 / (scale * h / 768)
	return px
end

local function ApplySkin(f)
	local px = PIXEL
	f:SetBackdrop({ bgFile = FLAT, edgeFile = FLAT, edgeSize = px,
		insets = { left = px, right = px, top = px, bottom = px } })
	local d = skinned[f]
	f:SetBackdropColor(d.bg[1], d.bg[2], d.bg[3], d.bg[4] or 1)
	f:SetBackdropBorderColor(d.border[1], d.border[2], d.border[3], d.border[4] or 1)
end

local function Skin(f, bg, border)
	skinned[f] = { bg = bg, border = border }
	ApplySkin(f)
end

-- Colours changed after Skin() (hover, selected) must survive a pixel refresh.
local function SetSkinColors(f, bg, border)
	local d = skinned[f]
	if d then
		if bg then d.bg = bg end
		if border then d.border = border end
	end
end

local function RefreshPixel()
	local px = ComputePixel()
	if abs(px - PIXEL) < 0.0001 then return end
	PIXEL = px
	for f in pairs(skinned) do
		local bgr, bgg, bgb, bga = f:GetBackdropColor()
		local br, bg2, bb, ba = f:GetBackdropBorderColor()
		ApplySkin(f)
		if bgr then f:SetBackdropColor(bgr, bgg, bgb, bga) end
		if br then f:SetBackdropBorderColor(br, bg2, bb, ba) end
	end
end

local function Text(parent, size, color, justify)
	local fs = parent:CreateFontString(nil, "OVERLAY")
	fs:SetFont(FONT, size)
	fs:SetTextColor(color[1], color[2], color[3])
	fs:SetJustifyH(justify or "LEFT")
	return fs
end

local function Size(o, w, h)
	o:SetWidth(w)
	o:SetHeight(h)
end

local function Toggle(o, on)
	if on then o:Show() else o:Hide() end
end

local function SetColor(fs, color)
	fs:SetTextColor(color[1], color[2], color[3])
end

---------------------------------------------------------------------------
-- virtual scroll list (fixed number of rows, thin scrollbar, mouse wheel)
---------------------------------------------------------------------------

local List = {}
List.__index = List

function List:Create(parent, width, rowH, nRows, makeRow, setRow)
	local L = setmetatable({ rows = {}, data = {}, offset = 0, rowH = rowH, n = nRows, setRow = setRow, parent = parent, yoff = 0 }, List)

	local f = CreateFrame("Frame", nil, parent)
	Size(f, width, rowH * nRows)
	f:EnableMouseWheel(true)
	f:SetScript("OnMouseWheel", function(_, delta) L:SetOffset(L.offset - delta * 3) end)
	L.frame = f

	for i = 1, nRows do
		local r = makeRow(f)
		r:SetHeight(rowH)
		r:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -(i - 1) * rowH)
		r:SetPoint("TOPRIGHT", f, "TOPRIGHT", -10, -(i - 1) * rowH)
		L.rows[i] = r
	end

	local track = f:CreateTexture(nil, "BACKGROUND")
	track:SetTexture(C.bg[1], C.bg[2], C.bg[3], 1)
	track:SetWidth(6)
	track:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
	track:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
	L.track = track

	local thumb = CreateFrame("Button", nil, f)
	thumb:SetWidth(6)
	local tt = thumb:CreateTexture(nil, "OVERLAY")
	tt:SetAllPoints()
	tt:SetTexture(C.accent[1], C.accent[2], C.accent[3], 0.45)
	thumb:SetScript("OnEnter", function() tt:SetTexture(C.accent[1], C.accent[2], C.accent[3], 1) end)
	thumb:SetScript("OnLeave", function() if not L.dragging then tt:SetTexture(C.accent[1], C.accent[2], C.accent[3], 0.45) end end)
	thumb:SetScript("OnMouseDown", function(self)
		local _, y = GetCursorPosition()
		L.dragging = true
		L.dragY = y / self:GetEffectiveScale()
		L.dragOffset = L.offset
		self:SetScript("OnUpdate", function(s)
			local _, cy = GetCursorPosition()
			cy = cy / s:GetEffectiveScale()
			local room = L.frame:GetHeight() - s:GetHeight()
			local maxOff = #L.data - L.n
			if room > 0 and maxOff > 0 then
				L:SetOffset(floor(L.dragOffset + ((L.dragY - cy) / room) * maxOff + 0.5))
			end
		end)
	end)
	thumb:SetScript("OnMouseUp", function(self)
		L.dragging = false
		self:SetScript("OnUpdate", nil)
		tt:SetTexture(C.accent[1], C.accent[2], C.accent[3], self:IsMouseOver() and 1 or 0.45)
	end)
	L.thumb = thumb

	return L
end

function List:Refresh()
	local total = #self.data
	local maxOff = max(0, total - self.n)
	if self.offset > maxOff then self.offset = maxOff end
	if self.offset < 0 then self.offset = 0 end

	for i = 1, self.n do
		local row, d = self.rows[i], self.data[i + self.offset]
		if d then
			row:Show()
			self.setRow(row, d, i + self.offset)
		else
			row:Hide()
		end
	end
	for i = self.n + 1, #self.rows do self.rows[i]:Hide() end

	if maxOff > 0 then
		local trackH = self.frame:GetHeight()
		local th = max(24, trackH * self.n / total)
		local y = (trackH - th) * (self.offset / maxOff)
		self.thumb:SetHeight(th)
		self.thumb:ClearAllPoints()
		self.thumb:SetPoint("TOPRIGHT", self.frame, "TOPRIGHT", 0, -y)
		self.thumb:Show()
		self.track:Show()
	else
		self.thumb:Hide()
		self.track:Hide()
	end
end

function List:SetOffset(o)
	local maxOff = max(0, #self.data - self.n)
	o = max(0, min(maxOff, o))
	if o ~= self.offset then
		self.offset = o
		if self.onScroll then self.onScroll() end
		self:Refresh()
	end
end

-- show only `n` rows and move the list down by `yoff` pixels (room for a header bar)
function List:SetLayout(n, yoff)
	n = min(n, #self.rows)
	if self.n == n and self.yoff == yoff then return end
	self.n, self.yoff = n, yoff
	self.frame:SetHeight(self.rowH * n)
	self.frame:ClearAllPoints()
	self.frame:SetPoint("TOPLEFT", self.parent, "TOPLEFT", 4, -4 - yoff)
end

function List:SetData(data, keepOffset)
	self.data = data
	if not keepOffset then self.offset = 0 end
	self:Refresh()
end

function List:ScrollTo(index)
	if index <= self.offset then
		self.offset = index - 1
	elseif index > self.offset + self.n then
		self.offset = index - self.n
	end
	self:Refresh()
end

---------------------------------------------------------------------------
-- row factories
---------------------------------------------------------------------------

local function BaseRow(parent)
	local r = CreateFrame("Button", nil, parent)

	r.hl = r:CreateTexture(nil, "BACKGROUND")
	r.hl:SetAllPoints()
	r.hl:SetTexture(C.hl[1], C.hl[2], C.hl[3], 1)
	r.hl:Hide()

	r.sel = r:CreateTexture(nil, "BACKGROUND")
	r.sel:SetAllPoints()
	r.sel:SetTexture(C.hl[1], C.hl[2], C.hl[3], 1)
	r.sel:Hide()

	r.bar = r:CreateTexture(nil, "ARTWORK")
	r.bar:SetWidth(2)
	r.bar:SetPoint("TOPLEFT")
	r.bar:SetPoint("BOTTOMLEFT")
	r.bar:SetTexture(C.accent[1], C.accent[2], C.accent[3], 1)
	r.bar:Hide()

	r:SetScript("OnEnter", function(s) if not s.static then s.hl:Show() end end)
	r:SetScript("OnLeave", function(s) s.hl:Hide() end)
	return r
end

local function MakeZoneRow(parent)
	local r = BaseRow(parent)
	r.text = Text(r, 12, C.text)
	r.text:SetWidth(ZONE_W - 60)       -- stay inside the pane
	r.text:SetHeight(ZONE_ROW)
	-- thin guide line so instances read as children of their DUNGEONS / RAIDS heading
	r.guide = r:CreateTexture(nil, "ARTWORK")
	r.guide:SetWidth(1)
	r.guide:SetPoint("TOPLEFT", r, "TOPLEFT", 14, 0)
	r.guide:SetPoint("BOTTOMLEFT", r, "BOTTOMLEFT", 14, 0)
	r.guide:SetTexture(C.rule[1], C.rule[2], C.rule[3], 0.6)
	r.guide:Hide()
	r:SetScript("OnClick", function(s) if s.zi then GL:SelectZone(s.zi) end end)
	return r
end

local function SetZoneRow(r, d)
	r.text:ClearAllPoints()
	r.zi = nil
	r.static = true
	r.sel:Hide(); r.bar:Hide(); r.guide:Hide()
	if d.kind == "spacer" then
		r.text:SetText("")
	elseif d.kind == "header" then
		r.text:SetFont(FONT, 12)
		SetColor(r.text, C.folder)
		r.text:SetPoint("BOTTOMLEFT", r, "BOTTOMLEFT", 8, 3)
		r.text:SetText(d.text)
	elseif d.kind == "group" then
		r.text:SetFont(FONT, 11)
		SetColor(r.text, C.muted)
		r.text:SetPoint("LEFT", r, "LEFT", 24, 0)
		r.text:SetText(d.text)
		r.guide:Show()
	else
		r.static = false
		r.zi = d.zi
		r.text:SetFont(FONT, 12)
		r.text:SetPoint("LEFT", r, "LEFT", d.indent and 38 or 24, 0)
		r.text:SetText(d.text)
		r.guide:Show()
		if d.zi == S.zi and not S.search then
			SetColor(r.text, C.accent)
			r.sel:Show(); r.bar:Show()
		else
			SetColor(r.text, d.empty and C.dim or C.text)
		end
	end
end

local function MakeBossRow(parent)
	local r = BaseRow(parent)
	r.text = Text(r, 12, C.text)
	r.text:SetPoint("LEFT", r, "LEFT", 10, 0)
	r.text:SetWidth(BOSS_W - 34)
	r.text:SetHeight(BOSS_ROW)
	r.text:SetJustifyV("MIDDLE")
	r:SetScript("OnClick", function(s) if s.bi then GL:SelectBoss(s.bi) end end)
	return r
end

local function SetBossRow(r, d, idx)
	r.bi = idx
	r.static = false
	r.text:SetText(d.name)
	if idx == S.bi and not S.search then
		SetColor(r.text, C.accent)
		r.sel:Show(); r.bar:Show()
	else
		SetColor(r.text, GL:CountItems(d) == 0 and C.dim or C.text)
		r.sel:Hide(); r.bar:Hide()
	end
end

local LOOT_TEXT_W = LOOT_W - 8 - 10 - 8 - 26 - 8 - 8

local function MakeLootRow(parent)
	local r = BaseRow(parent)

	r.iconBorder = r:CreateTexture(nil, "BORDER")
	Size(r.iconBorder, 26, 26)
	r.iconBorder:SetPoint("LEFT", r, "LEFT", 8, 0)

	r.icon = r:CreateTexture(nil, "ARTWORK")
	Size(r.icon, 24, 24)
	r.icon:SetPoint("CENTER", r.iconBorder, "CENTER")
	r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

	r.name = Text(r, 12, C.text)
	r.name:SetWidth(LOOT_TEXT_W)
	r.name:SetHeight(13)

	r.sub = Text(r, 10, C.muted)
	r.sub:SetWidth(LOOT_TEXT_W)
	r.sub:SetHeight(11)

	r.line = r:CreateTexture(nil, "ARTWORK")
	r.line:SetHeight(1)
	r.line:SetPoint("BOTTOMLEFT", r, "BOTTOMLEFT", 8, 2)
	r.line:SetPoint("BOTTOMRIGHT", r, "BOTTOMRIGHT", 0, 2)
	r.line:SetTexture(C.rule[1], C.rule[2], C.rule[3], 1)

	r:SetScript("OnEnter", function(s)
		if s.itemid then
			s.hl:Show()
			if S.wish and GL.frame then
				-- WishList: the tooltip always opens at the right edge of the window (next to the filter panel when it is open)
				GameTooltip:SetOwner(s, "ANCHOR_NONE")
				GameTooltip:ClearAllPoints()
				local fp = GL.filterPanel
				GameTooltip:SetPoint("TOPLEFT", (fp and fp:IsShown()) and fp or GL.frame, "TOPRIGHT", 4, 0)
			else
				GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
			end
			GameTooltip:SetHyperlink(GL:ItemString(s.itemid, s.mode))
			GameTooltip:Show()
		end
	end)
	r:SetScript("OnLeave", function(s)
		s.hl:Hide()
		GameTooltip:Hide()
	end)
	r:SetScript("OnClick", function(s)
		if not s.itemid then return end
		local link = GL:ItemLink(s.itemid, s.mode)
		if link and IsModifiedClick("CHATLINK") then
			ChatEdit_InsertLink(link)
		elseif link and IsModifiedClick("DRESSUP") then
			DressUpItemLink(link)
		elseif s.nav then
			GL:Goto(s.nav)
		end
	end)
	return r
end

local function SetLootRow(r, d)
	r.name:ClearAllPoints()
	r.sub:ClearAllPoints()

	if d.header then
		r.itemid, r.nav, r.static = nil, nil, true
		r.hl:Hide()
		r.icon:Hide(); r.iconBorder:Hide()
		r.sub:SetText("")
		r.line:Show()
		r.name:SetFont(FONT, 11)
		SetColor(r.name, C.accent)
		r.name:SetPoint("BOTTOMLEFT", r, "BOTTOMLEFT", 8, 5)
		r.name:SetText(strupper(d.header))
		return
	end

	local id = d.item
	r.itemid, r.nav, r.static, r.mode = id, d.nav, false, d.mode
	r.line:Hide()
	r.icon:Show(); r.iconBorder:Show()
	r.name:SetFont(FONT, 12)
	r.name:SetPoint("TOPLEFT", r.iconBorder, "TOPRIGHT", 8, 0)
	r.sub:SetPoint("BOTTOMLEFT", r.iconBorder, "BOTTOMRIGHT", 8, 0)

	local name, _, quality, ilvl, class, subclass, equipLoc, icon = GL:ItemInfo(id, d.mode)
	if name then
		local q = ITEM_QUALITY_COLORS[quality or 1] or ITEM_QUALITY_COLORS[1]
		r.name:SetText(name)
		r.name:SetTextColor(q.r, q.g, q.b)
		r.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
		r.iconBorder:SetTexture(q.r, q.g, q.b, 1)
		if d.src then
			r.sub:SetText(d.src)
		else
			local parts = {}
			local slot = (equipLoc and equipLoc ~= "") and (_G[equipLoc] or equipLoc) or nil
			if slot then parts[#parts + 1] = slot end
			if subclass and subclass ~= "" and subclass ~= slot then parts[#parts + 1] = subclass end
			if ilvl and ilvl > 1 then parts[#parts + 1] = "iLvl " .. ilvl end
			r.sub:SetText(table.concat(parts, DOT))
		end
	else
		GL.unresolved = true
		GL:RequestItem(id)
		r.name:SetText("Item " .. id)
		SetColor(r.name, C.muted)
		r.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
		r.iconBorder:SetTexture(C.border[1], C.border[2], C.border[3], 1)
		r.sub:SetText(d.src or "Loading...")
	end
end

---------------------------------------------------------------------------
-- WishList grid: 4 item cells per list row
---------------------------------------------------------------------------

-- The WishList view is wider than the normal window: left list (slots + "Show Only") and 4 item columns.
-- The frame grows to WISH_FRAME_W while the WishList tab is open and goes back to FRAME_W on the other tabs.
local WISH_COLS    = 4
local WISH_BAR_H   = 30                                   -- extended bar with title / count / toggles
local WISH_HEAD    = WISH_BAR_H + 10
local WISH_SIDE_W  = 226                                  -- left list panel
local WISH_COL_W   = 268
local WISH_CELL    = WISH_COL_W - 4
local WISH_LIST_W  = WISH_COLS * WISH_COL_W + 10          -- + scroll bar
local WISH_PANE_W  = 4 + WISH_SIDE_W + 4 + WISH_LIST_W + 4
local WISH_FRAME_W = WISH_PANE_W + 20

-- x offset that keeps the window centred when its width changes by `delta` (left / right anchored frames)
local function ShiftX(point, x, delta)
	if strfind(point or "", "LEFT", 1, true) then return x - delta / 2 end
	if strfind(point or "", "RIGHT", 1, true) then return x + delta / 2 end
	return x
end

local function MakeWishRow(parent)
	local row = CreateFrame("Frame", nil, parent)
	row.cells = {}
	for i = 1, WISH_COLS do
		local cell = MakeLootRow(row)
		cell:SetHeight(LOOT_ROW)
		cell:SetWidth(WISH_CELL)
		cell:SetPoint("TOPLEFT", row, "TOPLEFT", (i - 1) * WISH_COL_W, 0)
		local tw = WISH_CELL - 8 - 26 - 8 - 8
		cell.name:SetWidth(tw)
		cell.sub:SetWidth(tw)
		-- extend the normal item tooltip with the places the item drops
		cell:HookScript("OnEnter", function(s)
			if s.srcs then
				GameTooltip:AddLine(" ")
				GameTooltip:AddLine("Drops from:", C.folder[1], C.folder[2], C.folder[3])
				for _, src in ipairs(s.srcs) do
					GameTooltip:AddLine(src, 0.75, 0.78, 0.8)
				end
				GameTooltip:AddLine(" ")
				GameTooltip:AddLine("Click to show it in the loot browser", C.accent[1], C.accent[2], C.accent[3])
				GameTooltip:Show()
			end
		end)
		row.cells[i] = cell
	end
	return row
end

local ACC_HEX = format("|cff%02x%02x%02x", floor(C.accent[1] * 255 + 0.5), floor(C.accent[2] * 255 + 0.5), floor(C.accent[3] * 255 + 0.5))

local function SetWishRow(row, d)
	for i = 1, WISH_COLS do
		local cell, v = row.cells[i], d[i]
		if v then
			cell:Show()
			SetLootRow(cell, { item = v.id, mode = v.mode, nav = v.nav })
			cell.srcs = v.srcs
			if v.rank and GetItemInfo(v.id) then   -- "Chromis Chestpiece M10"
				local nm = cell.name:GetText()
				if nm and nm ~= "" then cell.name:SetText(nm .. " " .. ACC_HEX .. v.rank .. "|r") end
			end
			if v.label then
				local t = cell.sub:GetText()
				if t and t ~= "" and t ~= "Loading..." then
					cell.sub:SetText(t .. DOT .. v.label)
				end
			end
		else
			cell:Hide()
			cell.itemid, cell.srcs = nil, nil
		end
	end
end

---------------------------------------------------------------------------
-- data -> list rows
---------------------------------------------------------------------------

local function BuildZoneRows(exKey)
	local zones = GL:GetZones(exKey)
	local rows = {}
	local groups = { { "dungeon", "DUNGEONS" }, { "raid", "RAIDS" } }
	for _, g in ipairs(groups) do
		local first, lastGroup = true, nil
		for zi, z in ipairs(zones) do
			if z.type == g[1] then
				if first then
					if #rows > 0 then rows[#rows + 1] = { kind = "spacer" } end   -- gap between DUNGEONS and RAIDS
					rows[#rows + 1] = { kind = "header", text = g[2] }
					first = false
				end
				if z.group and z.group ~= lastGroup then
					rows[#rows + 1] = { kind = "group", text = z.group }
				end
				lastGroup = z.group
				local items = 0
				for _, b in ipairs(z.bosses or {}) do items = items + GL:CountItems(b) end
				rows[#rows + 1] = { kind = "zone", zi = zi, text = z.name, indent = z.group ~= nil, empty = (items == 0) }
			end
		end
	end
	return rows
end

local function CurrentZone()
	return GL:GetZones(S.ex)[S.zi]
end

local function CurrentBoss()
	local z = CurrentZone()
	return z and z.bosses and z.bosses[S.bi], z
end

---------------------------------------------------------------------------
-- refresh functions
---------------------------------------------------------------------------

function GL:TabActive(key)
	if S.wish then return key == "Wish" end
	return key == S.ex
end

function GL:RefreshTabs()
	for _, t in ipairs(self.tabs) do
		local on = self:TabActive(t.key)
		Toggle(t.line, on)
		if on then SetColor(t.text, C.accent) else SetColor(t.text, C.muted) end
	end
end

function GL:RefreshZones()
	local rows = BuildZoneRows(S.ex)
	if #rows == 0 then rows = { { kind = "header", text = "NO DATA" } } end
	self.zoneRows = rows
	self.zoneList:SetData(rows, true)
end

function GL:ScrollZoneIntoView()
	for i, d in ipairs(self.zoneRows or {}) do
		if d.zi == S.zi then
			-- show the group header too when the first wing is selected
			local idx = i
			local prev = self.zoneRows[i - 1]
			if prev and prev.kind == "group" then idx = i - 1 end
			self.zoneList:ScrollTo(idx)
			return
		end
	end
end

-- the "10 Normal | 10 Heroic" bar only exists on the raids listed in GL.tenManRaids
function GL:RefreshBosses()
	local z = CurrentZone()
	local hdr = (z and GL.tenManRaids[z.name]) and true or false
	self.bossHdr = hdr
	for _, b in ipairs(self.diffTabs or {}) do Toggle(b, hdr) end
	self.bossList:SetLayout(hdr and self.bossRowsHead or self.bossRowsFull, hdr and BOSS_HEAD or 0)
	self.bossList:SetData(z and z.bosses or {}, true)
end

function GL:RefreshLoot()
	GL.unresolved = false
	local rows, modes = {}, {}
	local title, subtitle

	if S.search then
		rows = {}
		for _, r in ipairs(S.results) do
			rows[#rows + 1] = {
				item = r.id, src = r.src, mode = r.emode or r.mode,
				nav = { ex = r.ex, zi = r.zi, bi = r.bi, mode = r.mode },
			}
		end
		title = "Search"
		subtitle = format("%d result%s for \"%s\"", #rows, #rows == 1 and "" or "s", S.search)
		self.emptyText:SetText(strlen(S.search) < 2 and "" or
			"No match.\nOnly items your client has already seen can be searched by name.")
	else
		local boss, zone = CurrentBoss()
		if boss then
			modes = GL:GetModes(boss)
			local valid = false
			valid = GL:ModeValid(modes, S.mode)
			if not valid and modes[1] then S.mode = modes[1].key end
			rows = GL:Flatten(GL:GetSections(boss, S.mode), S.mode)
			title = boss.name
			subtitle = zone.name
			if #rows > 0 then
				local n = 0
				for _, d in ipairs(rows) do if d.item then n = n + 1 end end
				subtitle = subtitle .. DOT .. n .. (n == 1 and " item" or " items")
			end
		elseif zone and zone.comingSoon then
			title, subtitle = zone.name, "Coming soon"
		else
			title, subtitle = "", ""
		end
		if zone and zone.comingSoon then
			self.emptyText:SetText("Raid Coming Soon")
		else
			self.emptyText:SetText("No items registered yet.\nAdd ItemIDs in Data\\" .. S.ex .. ".lua")
		end
	end

	self.lootTitle:SetText(title or "")
	self.lootSub:SetText(subtitle or "")
	Toggle(self.emptyText, #rows == 0)

	-- mode tabs
	local activeVariants
	for _, m in ipairs(modes) do
		if m.variants and GL:ModeIn(m.variants, S.mode) then activeVariants = m.variants end
	end
	local allModes = modes
	if self.bossHdr then   -- Normal / Heroic live in the boss bar on these raids
		local rest = {}
		for _, m in ipairs(modes) do
			if m.key ~= "loot" and m.key ~= "heroic" then rest[#rest + 1] = m end
		end
		modes = rest
	end
	for i, btn in ipairs(self.modeTabs) do
		local m = modes[i]
		if m and (#modes > 1 or self.bossHdr) and not S.search then
			local inVariant = m.variants and GL:ModeIn(m.variants, S.mode)
			btn.key = (m.variants and S.lastVariant and GL:ModeIn(m.variants, S.lastVariant)) and S.lastVariant or m.key
			btn.text:SetText(m.label)
			btn:SetWidth(btn.text:GetStringWidth() + 28)
			btn:Show()
			btn.on = (m.key == S.mode) or (inVariant and true or false)
			GL.ModeTabStyle(btn, btn.on, false)
		else
			btn:Hide()
		end
	end
	-- boss pane selector: Normal | Heroic (labels follow the raid: "10 Man | 10 Heroic" when it has 25-man)
	do
		local label = {}
		for _, m in ipairs(allModes) do label[m.key] = m.label end
		for _, btn in ipairs(self.diffTabs) do
			local k = btn.mode
			btn.text:SetText(k == "loot" and "10 Normal" or "10 Heroic")
			btn.enabled = (label[k] ~= nil) and not S.search
			btn.on = btn.enabled and (S.mode == k)
			GL.ModeTabStyle(btn, btn.on, false)
			if not btn.enabled then SetColor(btn.text, C.dim) end
		end
	end
	-- second row: the Mythic versions (M0 0/5, M12 0/8)
	for i, btn in ipairs(self.subTabs) do
		local v = activeVariants and not S.search and activeVariants[i]
		if v then
			btn.key = v.key
			btn.text:SetText(v.label)
			btn:SetWidth(btn.text:GetStringWidth() + 14)
			btn:Show()
			btn.on = (v.key == S.mode)
			GL.ModeTabStyle(btn, btn.on, false)
		else
			btn:Hide()
		end
	end

	self.lootList:SetData(rows, GL.keepLootOffset)
	GL.keepLootOffset = false
	if S.wish and self.wishList then self.wishList:Refresh() end   -- late item info for the WishList cells
end

function GL:RefreshAll()
	self:ApplyView()
	self:RefreshTabs()
	self:RefreshZones()
	self:RefreshBosses()
	self:RefreshLoot()
end

---------------------------------------------------------------------------
-- selection
---------------------------------------------------------------------------

---------------------------------------------------------------------------
-- WishList view + Advance Filtering
---------------------------------------------------------------------------

function GL:ApplyView()
	if not self.panes then return end
	local w = S.wish and true or false
	Toggle(self.panes.zone, not w)
	Toggle(self.panes.boss, not w)
	Toggle(self.panes.loot, not w)
	Toggle(self.panes.wish, w)
	self:SizeFrame(w)
end

-- WishList tab: window grows to fit 4 item columns; every other tab: original size again
function GL:SizeFrame(wide)
	local f = self.frame
	if not f then return end
	local target = wide and WISH_FRAME_W or FRAME_W
	local cur = f:GetWidth()
	if abs(cur - target) < 0.5 then return end
	local point, rel, relPoint, x, y = f:GetPoint()
	f:SetWidth(target)
	if point then
		f:ClearAllPoints()
		f:SetPoint(point, rel, relPoint, ShiftX(point, x, target - cur), y)
	end
end

function GL:UpdateFilterButton()
	if not self.filterBtn then return end
	local n = #self:WishCriteria()
	self.filterBtn.text:SetText(n > 0 and ("Advance Filtering (" .. n .. ")") or "Advance Filtering")
	if n > 0 then
		self.filterBtn.text:SetTextColor(C.accent[1], C.accent[2], C.accent[3])
	else
		SetColor(self.filterBtn.text, C.text)
	end
end

-- "Show Only" list (left side of the WishList), in display order
GL.wishShowDefs = {
	{ key = "nodung", label = "Normal Dungeon", tip = "Only Normal dungeon gear." },
	{ key = "noraid", label = "Normal Raid",    tip = "Only Normal raid gear (10 and 25 man)." },
	{ key = "hedung", label = "Heroic Dungeon", tip = "Only Heroic dungeon gear." },
	{ key = "heraid", label = "Heroic Raid",    tip = "Only Heroic raid gear (10 and 25 man)." },
	{ key = "m0",     label = "Mythic",         tip = "Only Mythic dungeon gear at its base version (M0 0/5)." },
}

for level = 1, 12 do
	local tip = "Only Mythic " .. level .. " dungeon gear: the 0/8 and the 8/8 version."
	if level == 12 then
		tip = tip .. " The highest rank: key 12 drops 0/8, key 13 drops 1/8, key 14 drops 2/8, key 15 drops 3/8 ... (8/8 = item level 95)."
	end
	GL.wishShowDefs[#GL.wishShowDefs + 1] = { key = "m" .. level, label = "Mythic " .. level, tip = tip }
end

function GL.WishShowSig(W)
	local sh = W and W.show
	if not sh then return "-" end
	local t = {}
	for _, d in ipairs(GL.wishShowDefs) do t[#t + 1] = sh[d.key] and "1" or "0" end
	return table.concat(t)
end

function GL:RefreshWish(keepOffset)
	if not self.wishList then return end
	local results, crit = self:WishResults()
	local n = #crit

	if n > 0 and not self.wishScan then self:WishStartScan() end

	local done, total = self:WishProgress()
	local scanning = self.wishScan and not self.wishScan.finished and n > 0

	if n == 0 then
		self.wishSub:SetText("No stats selected")
		self.wishEmpty:SetText("Open |cffde7230Advance Filtering|r and pick the stats you want.\nEvery matching item of the database is listed here, highest item level first.")
	else
		local all = true
		self.wishSub:SetText(format("%d Item%s - %s: %s", #results, #results == 1 and "" or "s",
			all and "Must have all" or "Must have any", self:WishStatList(crit)))
		if #results == 0 then
			self.wishEmpty:SetText(scanning and "Scanning the database..." or "No item matches these stats.")
		else
			self.wishEmpty:SetText("")
		end
	end
	Toggle(self.wishEmpty, self.wishEmpty:GetText() ~= "")

	if scanning then
		self.wishProg:SetText(format("Scanning items  %d / %d", done, total))
		self.wishProgBar:SetMinMaxValues(0, max(1, total))
		self.wishProgBar:SetValue(done)
	else
		self.wishProg:SetText("")
	end

	-- The scan refreshes this view in the background. Rebuilding the rows while the mouse is on an item
	-- (tooltip open) or when nothing changed is what made the client crash, so those refreshes are skipped.
	local sig = n .. ":" .. #results .. ":" .. (self.db.wish.match or "") .. ":" .. self:WishMinIlvl()
		.. ":" .. tostring(self.db.wish.slot) .. ":" .. tostring(self:WishSortKey()) .. ":" .. tostring(self.db.wish.topRanks) .. ":" .. tostring(self.db.wish.onlyMythic) .. ":" .. tostring(self.db.wish.noIlvl) .. ":" .. GL.WishShowSig(self.db.wish)
		.. ":" .. tostring(self.db.wish.phase and (self.db.wish.phase[1] and 1 or 0) .. (self.db.wish.phase[2] and 1 or 0) .. (self.db.wish.phase[3] and 1 or 0) .. (self.db.wish.phase[4] and 1 or 0))
	if keepOffset then
		if sig == self.wishSig then return end
		if GameTooltip:IsShown() then self.wishDirty = true; return end
	end
	self.wishSig = sig

	local rows = {}
	for i = 1, #results, WISH_COLS do
		local r = {}
		for k = 0, WISH_COLS - 1 do r[k + 1] = results[i + k] end
		rows[#rows + 1] = r
	end
	self.wishList:SetData(rows, keepOffset)
end

function GL:OnWishUpdate()
	if S.wish and self.frame and self.frame:IsShown() then self:RefreshWish(true) end
end

function GL:SelectWish()
	if self.searchBox:GetText() ~= "" then self:ClearSearch(true) end
	S.wish = true
	self:ApplyView()
	self:RefreshTabs()
	self:RefreshWish()
end

-- called whenever a checkbox / number box in the filter panel changes
function GL:WishChanged(phaseChanged)
	self:UpdateFilterButton()
	-- the set of items worth scanning depends on the phases: start over so a widened selection is covered
	if phaseChanged and self.wishScan and not self.wishScan.finished then self.wishScan = nil end
	if #self:WishCriteria() > 0 and (not self.wishScan or self.wishScan.finished) then self:WishStartScan() end
	self.wishDue = GetTime() + 0.25
end

function GL:ToggleFilterPanel()
	if not self.filterPanel then
		local ok, err = pcall(self.BuildFilterPanel, self)
		if not ok then
			print("|cffde7230XLoot|r filter panel error: " .. tostring(err))
			if self.filterPanel then self.filterPanel:Hide() end
			return
		end
	end
	Toggle(self.filterPanel, not self.filterPanel:IsShown())
end

local function Remember()
	local mem = GL.db.mem
	mem[S.ex] = { zi = S.zi, bi = S.bi }
end

function GL:SelectExpansion(key)
	S.wish = false
	S.ex = key
	GL.db.expansion = key
	local m = GL.db.mem[key]
	S.zi, S.bi = (m and m.zi) or 1, (m and m.bi) or 1
	local zones = GL:GetZones(key)
	if not zones[S.zi] then S.zi, S.bi = 1, 1 end
	-- default to the first instance that is actually listed first in the sidebar
	if not (m and m.zi) then
		for _, d in ipairs(BuildZoneRows(key)) do
			if d.zi then S.zi = d.zi; break end
		end
	end
	local z = zones[S.zi]
	if z and not (z.bosses and z.bosses[S.bi]) then S.bi = 1 end
	GL.tries = 0
	self:RefreshAll()
	self.zoneList.offset = 0
	self:ScrollZoneIntoView()
	self.bossList.offset = 0
	self.bossList:Refresh()
	Remember()
end

function GL:SelectZone(zi)
	if self.searchBox:GetText() ~= "" then self:ClearSearch() end
	S.zi, S.bi = zi, 1
	GL.tries = 0
	Remember()
	self:RefreshZones()
	self:RefreshBosses()
	self.bossList.offset = 0
	self.bossList:Refresh()
	self:RefreshLoot()
end

function GL:SelectBoss(bi)
	if self.searchBox:GetText() ~= "" then self:ClearSearch() end
	S.bi = bi
	GL.tries = 0
	Remember()
	self:RefreshBosses()
	self:RefreshLoot()
end

function GL:SelectMode(key)
	S.mode = key
	if key == "mythic" or GL.variantByKey[key] then S.lastVariant = key end
	GL.tries = 0
	self:RefreshLoot()
end

function GL:Goto(nav)
	S.wish = false
	self:ClearSearch(true)
	S.ex, S.zi, S.bi = nav.ex, nav.zi, nav.bi
	if nav.mode then S.mode = nav.mode end
	GL.db.expansion = nav.ex
	Remember()
	GL.tries = 0
	self:RefreshAll()
	self:ScrollZoneIntoView()
	self.bossList:ScrollTo(S.bi)
end

function GL:ClearSearch(silent)
	S.search, S.results = nil, {}
	self.searchBox:SetText("")
	self.searchBox:ClearFocus()
	if not silent then self:RefreshAll() end
end

function GL:RunSearch()
	local text = strtrim(self.searchBox:GetText() or "")
	if strlen(text) >= 2 then
		S.search = text
		S.wish = false
		self:ApplyView()
		self:RefreshTabs()
		S.results = GL:Search(text)
		GL.tries = 0
		self:RefreshZones()
		self:RefreshBosses()
		self:RefreshLoot()
	elseif S.search then
		S.search, S.results = nil, {}
		self:RefreshAll()
	end
end

---------------------------------------------------------------------------
-- Advance Filtering panel (built the first time it is opened, so a problem in here can
-- never break the main window)
---------------------------------------------------------------------------

function GL:BuildFilterPanel()
	if self.filterPanel then return end
	local missing = {}
	if not self.wishStats then missing[#missing + 1] = "wishStats" end
	if not self.WishCriteria then missing[#missing + 1] = "WishCriteria" end
	if #missing > 0 then
		error("Wishlist.lua did not finish loading (missing: " .. table.concat(missing, ", ")
			.. "). If nothing is missing but wishStats, enable /console scriptErrors 1 and /reload to see the real error; "
			.. "otherwise make sure Wishlist.lua is in the AddOns\\XLoot folder and listed in XLoot.toc")
	end
	local f, arrow, fb = self.frame, self.filterArrow, self.filterBtn
	-- Filter panel (opens on the right side of the window)
	local PW = 340
	local panel = CreateFrame("Frame", "XLootFilterPanel", f)
	Size(panel, PW, FRAME_H)
	panel:SetPoint("TOPLEFT", f, "TOPRIGHT", 4, 0)
	Skin(panel, C.bg, C.border)
	panel:Hide()
	self.filterPanel = panel
	panel:SetScript("OnShow", function()
		arrow.text:SetText("<")
		fb:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 1)
		arrow:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 1)
	end)
	panel:SetScript("OnHide", function()
		arrow.text:SetText(">")
		fb:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], 1)
		arrow:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], 1)
	end)
	f:HookScript("OnHide", function() panel:Hide() end)

	local W = self.db.wish
	local checks = {}      -- key -> { cb, eb }

	local function Heading(text, y)
		local fs = Text(panel, 11, C.folder)
		fs:SetPoint("TOPLEFT", panel, "TOPLEFT", 16, -y)
		fs:SetText(text)
		return fs
	end
	local function Rule(y)
		local t = panel:CreateTexture(nil, "ARTWORK")
		t:SetHeight(1)
		t:SetPoint("TOPLEFT", panel, "TOPLEFT", 1, -y)
		t:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -1, -y)
		t:SetTexture(C.border[1], C.border[2], C.border[3], 1)
	end

	local function Check(label, x, y, w)
		local cb = CreateFrame("Button", nil, panel)
		Size(cb, w or 96, 20)
		cb:SetPoint("TOPLEFT", panel, "TOPLEFT", x, -y)
		cb.box = CreateFrame("Frame", nil, cb)
		Size(cb.box, 14, 14)
		cb.box:SetPoint("LEFT", cb, "LEFT", 0, 0)
		Skin(cb.box, C.field, C.border)
		cb.tick = cb.box:CreateTexture(nil, "OVERLAY")
		cb.tick:SetPoint("TOPLEFT", cb.box, "TOPLEFT", 3, -3)
		cb.tick:SetPoint("BOTTOMRIGHT", cb.box, "BOTTOMRIGHT", -3, 3)
		cb.tick:SetTexture(C.accent[1], C.accent[2], C.accent[3], 1)
		cb.tick:Hide()
		cb.label = Text(cb, 11, C.muted)
		cb.label:SetPoint("LEFT", cb.box, "RIGHT", 7, 0)
		cb.label:SetText(label)
		function cb:SetChecked(on)
			self.on = on and true or false
			Toggle(self.tick, self.on)
			if self.on then SetColor(self.label, C.text) else SetColor(self.label, C.muted) end
		end
		cb:SetScript("OnEnter", function(s) s.box:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 1) end)
		cb:SetScript("OnLeave", function(s) s.box:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], 1) end)
		return cb
	end

	-- check box + name for one stat
	local sortBoxes = {}   -- key -> small "sort by this stat" box
	local function SyncSort()
		for key, sb in pairs(sortBoxes) do sb:SetChecked(W.sort == key and W.stats[key] ~= nil) end
	end

	-- "Priority" pill at the end of Intellect / Spell Power / Strength / Agility rows:
	-- the check box on the left FILTERS by the stat, the pill on the right SORTS by it (highest value first)
	local function SortPill(x, y, stat)
		local b = CreateFrame("Button", nil, panel)
		Size(b, 58, 18)
		b:SetPoint("TOPLEFT", panel, "TOPLEFT", x, -(y + 1))
		Skin(b, C.field, C.border)
		b.text = Text(b, 10, C.muted, "CENTER")
		b.text:SetPoint("CENTER", 0, 0)
		b.text:SetText("Priority")
		function b:SetChecked(on)
			self.on = on and true or false
			GL.ModeTabStyle(self, self.on, false)
		end
		b:SetScript("OnClick", function()
			if W.sort == stat.key then
				W.sort = nil
			else
				W.sort = stat.key
				W.stats[stat.key] = 0          -- prioritizing a stat also filters by it
				checks[stat.key].cb:SetChecked(true)
			end
			SyncSort()
			GL:WishChanged()
		end)
		b:SetScript("OnEnter", function(s2)
			GL.ModeTabStyle(s2, s2.on, true)
			GameTooltip:SetOwner(s2, "ANCHOR_RIGHT")
			GameTooltip:SetText("Priority: " .. stat.label, 1, 1, 1)
			GameTooltip:AddLine("Lists the items with the highest " .. stat.label .. " first, instead of the highest item level. One stat at a time.", 0.75, 0.78, 0.8, 1)
			GameTooltip:AddLine("The check box on the left only filters: it keeps items that have this stat.", 0.5, 0.58, 0.59, 1)
			GameTooltip:Show()
		end)
		b:SetScript("OnLeave", function(s2) GL.ModeTabStyle(s2, s2.on, false); GameTooltip:Hide() end)
		b:SetChecked(false)
		return b
	end

	local function StatRow(stat, x, y)
		local sortable = GL.wishSortable[stat.key]
		local cb = Check(stat.label, x, y, sortable and 88 or 150)
		cb:SetScript("OnClick", function(s)
			local on = not s.on
			s:SetChecked(on)
			W.stats[stat.key] = on and 0 or nil
			if not on and W.sort == stat.key then W.sort = nil end
			SyncSort()
			GL:WishChanged()
		end)
		checks[stat.key] = { cb = cb }
		if sortable then sortBoxes[stat.key] = SortPill(x + 92, y, stat) end
	end

	-- layout
	-- phase boxes (tick none = all phases, tick several = any of them)
	W.phase = W.phase or {}
	Heading("PHASE", 16)
	local phaseBoxes = {}
	for n = 1, 4 do
		local pb = Check(GL.wishPhaseLabels[n], 16 + (n - 1) * 78, 36, 74)
		pb:SetScript("OnClick", function(s)
			local on = not s.on
			s:SetChecked(on)
			W.phase[n] = on or nil
			GL:WishChanged(true)
		end)
		phaseBoxes[n] = pb
	end
	Rule(64)
	Heading("FILTER ITEMS BY STATS", 76)
	local y = 102
	local byKey = {}
	for _, st in ipairs(GL.wishStats) do byKey[st.key] = st end
	for gi, group in ipairs(GL.wishGroups) do
		if gi > 1 then
			Rule(y)
			y = y + 14
		end
		for i, key in ipairs(group) do
			local col, row = (i - 1) % 2, floor((i - 1) / 2)
			StatRow(byKey[key], col == 0 and 16 or 180, y + row * 28)
		end
		y = y + ceil(#group / 2) * 28 + 8
	end

	Rule(y)
	y = y + 12

	local tipText = Text(panel, 10, C.dim)
	tipText:SetPoint("TOPLEFT", panel, "TOPLEFT", 16, -y)
	tipText:SetWidth(PW - 32)
	tipText:SetHeight(70)
	tipText:SetJustifyV("TOP")
	tipText:SetText("Tick the stats you want: items must have all of them. Results appear on the WishList tab, highest item level first. The Priority button next to Stamina / Intellect / Spell Power / Strength / Agility lists the items with the highest value of that stat first instead (one at a time). The first scan reads every item once, so it can take a moment.")

	-- bottom bar: Clear All + Done
	local pdiv = panel:CreateTexture(nil, "ARTWORK")
	pdiv:SetHeight(1)
	pdiv:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 1, FOOTER_H)
	pdiv:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -1, FOOTER_H)
	pdiv:SetTexture(C.border[1], C.border[2], C.border[3], 1)

	local function SyncPanel()
		for key, c in pairs(checks) do
			local m = W.stats[key]
			c.cb:SetChecked(m ~= nil)
		end
		SyncSort()
		for n = 1, 4 do phaseBoxes[n]:SetChecked(W.phase[n] and true or false) end
	end
	self.SyncFilterPanel = SyncPanel

	local clear = CreateFrame("Button", nil, panel)
	Size(clear, 70, 26)
	clear:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 16, 7)
	clear.text = Text(clear, 12, { 0.95, 0.45, 0.45 }, "LEFT")
	clear.text:SetPoint("LEFT", 0, 0)
	clear.text:SetText("Clear All")
	clear:SetScript("OnEnter", function(s) s.text:SetTextColor(1, 0.7, 0.7) end)
	clear:SetScript("OnLeave", function(s) s.text:SetTextColor(0.95, 0.45, 0.45) end)
	clear:SetScript("OnClick", function()
		W.stats = {}
		W.sort = nil
		W.phase = {}
		W.proc, W.use = false, false
		SyncPanel()
		GL:WishChanged(true)
	end)

	local done = CreateFrame("Button", nil, panel)
	Size(done, 90, 26)
	done:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -14, 7)
	Skin(done, C.hl, { C.accent[1], C.accent[2], C.accent[3], 0.8 })
	done.text = Text(done, 12, C.accent, "CENTER")
	done.text:SetPoint("CENTER", 0, 0)
	done.text:SetText("Done")
	done:SetScript("OnEnter", function(s) s:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 1) end)
	done:SetScript("OnLeave", function(s) s:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 0.8) end)
	done:SetScript("OnClick", function()
		panel:Hide()
		GL:SelectWish()
	end)

	SyncPanel()
	self:UpdateFilterButton()
end

---------------------------------------------------------------------------
-- frame construction
---------------------------------------------------------------------------

function GL:Build()
	if self.frame then return end

	local f = CreateFrame("Frame", "XLootFrame", UIParent)
	self.frame = f
	Size(f, FRAME_W, FRAME_H)
	f:SetFrameStrata("HIGH")
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	f:SetScale(self.db.scale or 1)
	Skin(f, C.bg, C.border)
	local p = self.db.point
	if p then
		f:SetPoint(p[1], UIParent, p[2], p[3], p[4])
	else
		f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
	end
	tinsert(UISpecialFrames, "XLootFrame")
	f:Hide()

	-- title bar (drag handle)
	local bar = CreateFrame("Frame", nil, f)
	bar:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
	bar:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
	bar:SetHeight(HEADER_H)
	bar:EnableMouse(true)
	bar:RegisterForDrag("LeftButton")
	bar:SetScript("OnDragStart", function() f:StartMoving() end)
	bar:SetScript("OnDragStop", function()
		f:StopMovingOrSizing()
		local point, _, rel, x, y = f:GetPoint()
		if f:GetWidth() > FRAME_W + 1 then x = ShiftX(point, x, FRAME_W - f:GetWidth()) end   -- saved as normal size
		GL.db.point = { point, rel, x, y }
	end)

	-- flat JunkieUI title bar
	local barBg = f:CreateTexture(nil, "BACKGROUND")
	barBg:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
	barBg:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -1)
	barBg:SetHeight(BODY_TOP - 9)
	barBg:SetTexture(C.panel[1], C.panel[2], C.panel[3], 1)

	-- logo badge + title + subtitle
	local logo = CreateFrame("Frame", nil, bar)
	Size(logo, 48, 48)
	logo:SetPoint("TOPLEFT", bar, "TOPLEFT", 8, -4)
	local lt = logo:CreateTexture(nil, "ARTWORK")
	lt:SetAllPoints(logo)
	lt:SetTexture("Interface\\AddOns\\XLoot\\Media\\icon.tga")

	local title = Text(bar, 20, C.text)
	title:SetPoint("TOPLEFT", bar, "TOPLEFT", 66, -8)
	title:SetText("|cffde7230X|r-Loot")

	local subtitle = Text(bar, 11, C.muted)
	subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
	subtitle:SetText("Browse dungeon and raid loot by difficulty: Normal, Heroic and Mythic.")

	local close = CreateFrame("Button", nil, bar)
	Size(close, 30, 30)
	close:SetPoint("TOPRIGHT", bar, "TOPRIGHT", -14, -13)
	Skin(close, C.field, C.border)
	close.text = Text(close, 20, C.muted, "CENTER")
	close.text:SetPoint("CENTER", 0, 1)
	close.text:SetText("\195\151")                       -- UTF-8 multiplication sign
	close:SetScript("OnEnter", function(s)
		SetColor(s.text, C.accent)
		s:SetBackdropColor(C.hl[1], C.hl[2], C.hl[3], 1)
	end)
	close:SetScript("OnLeave", function(s)
		SetColor(s.text, C.muted)
		s:SetBackdropColor(C.field[1], C.field[2], C.field[3], 1)
	end)
	close:SetScript("OnClick", function() f:Hide() end)

	-- search box
	local sb = CreateFrame("EditBox", "XLootSearch", bar)
	self.searchBox = sb
	Size(sb, 220, 28)
	sb:SetPoint("RIGHT", close, "LEFT", -10, 0)
	Skin(sb, C.field, C.border)
	sb:SetFont(FONT, 12)
	sb:SetTextColor(C.text[1], C.text[2], C.text[3])
	sb:SetTextInsets(8, 8, 0, 0)
	sb:SetAutoFocus(false)
	sb:SetMaxLetters(40)
	local ph = Text(sb, 12, C.dim)
	ph:SetPoint("LEFT", sb, "LEFT", 8, 0)
	ph:SetText("Search items...")
	sb:SetScript("OnEditFocusGained", function() sb:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 1) end)
	sb:SetScript("OnEditFocusLost", function() sb:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], 1) end)
	sb:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
	sb:SetScript("OnEnterPressed", function(s) s:ClearFocus() end)
	sb:SetScript("OnTextChanged", function(s, user)
		Toggle(ph, s:GetText() == "")
		if user or s:GetText() == "" then
			GL.searchDue = GetTime() + 0.35
		end
	end)
	sb:SetScript("OnEnter", function(s)
		GameTooltip:SetOwner(s, "ANCHOR_BOTTOM")
		GameTooltip:SetText("Search by item name", 1, 1, 1)
		GameTooltip:AddLine("Matches items your client has already loaded.", 0.7, 0.7, 0.7, 1)
		GameTooltip:Show()
	end)
	sb:SetScript("OnLeave", function() GameTooltip:Hide() end)

	-- expansion tabs
	self.tabs = {}
	local x = 14
	local tabDefs = {}
	for _, ex in ipairs(GL.expansions) do tabDefs[#tabDefs + 1] = ex end
	tabDefs[#tabDefs + 1] = { key = "Wish", label = "WishList", gap = 22 }   -- own tab, slightly apart
	for _, ex in ipairs(tabDefs) do
		if ex.gap then x = x + ex.gap end
		local b = CreateFrame("Button", nil, f)
		b:SetHeight(TABS_H)
		b.key = ex.key
		b.text = Text(b, 13, C.muted, "CENTER")
		b.text:SetPoint("CENTER", 0, 1)
		b.text:SetText(ex.label)
		b:SetWidth(b.text:GetStringWidth() + 30)
		b:SetPoint("TOPLEFT", f, "TOPLEFT", x, -(HEADER_H + 2))
		x = x + b:GetWidth() + 2
		b.line = b:CreateTexture(nil, "OVERLAY")
		b.line:SetHeight(2)
		b.line:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 0, 0)
		b.line:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
		b.line:SetTexture(C.accent[1], C.accent[2], C.accent[3], 1)
		b.line:Hide()
		b:SetScript("OnEnter", function(s) if not GL:TabActive(s.key) then SetColor(s.text, C.text) end end)
		b:SetScript("OnLeave", function(s) if not GL:TabActive(s.key) then SetColor(s.text, C.muted) end end)
		b:SetScript("OnClick", function(s)
			if s.key == "Wish" then
				GL:SelectWish()
				return
			end
			if self.searchBox:GetText() ~= "" then self:ClearSearch(true) end
			GL:SelectExpansion(s.key)
		end)
		self.tabs[#self.tabs + 1] = b
	end

	local div = f:CreateTexture(nil, "ARTWORK")
	div:SetHeight(1)
	div:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -(BODY_TOP - 8))
	div:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -(BODY_TOP - 8))
	div:SetTexture(C.border[1], C.border[2], C.border[3], 1)

	-- panes
	local function Pane(w, xoff)
		local pane = CreateFrame("Frame", nil, f)
		Size(pane, w, BODY_H)
		pane:SetPoint("TOPLEFT", f, "TOPLEFT", xoff, -BODY_TOP)
		Skin(pane, C.panel, C.border)
		return pane
	end
	local zonePane = Pane(ZONE_W, 10)
	local bossPane = Pane(BOSS_W, 10 + ZONE_W + 6)
	local lootPane = Pane(LOOT_W, 10 + ZONE_W + 6 + BOSS_W + 6)

	local zoneRows = floor((BODY_H - 8) / ZONE_ROW)
	self.zoneList = List:Create(zonePane, ZONE_W - 8, ZONE_ROW, zoneRows, MakeZoneRow, SetZoneRow)
	self.zoneList.frame:SetPoint("TOPLEFT", zonePane, "TOPLEFT", 4, -4)

	local bossRows = floor((BODY_H - 8) / BOSS_ROW)
	self.bossList = List:Create(bossPane, BOSS_W - 8, BOSS_ROW, bossRows, MakeBossRow, SetBossRow)
	self.bossList.frame:SetPoint("TOPLEFT", bossPane, "TOPLEFT", 4, -4)
	self.bossRowsFull, self.bossRowsHead = bossRows, floor((BODY_H - 8 - BOSS_HEAD) / BOSS_ROW)

	-- loot pane header
	self.lootTitle = Text(lootPane, 17, C.text)
	self.lootTitle:SetPoint("TOPLEFT", lootPane, "TOPLEFT", 12, -12)
	self.lootTitle:SetWidth(LOOT_W - 24)
	self.lootTitle:SetHeight(20)

	self.lootSub = Text(lootPane, 11, C.muted)
	self.lootSub:SetPoint("TOPLEFT", self.lootTitle, "BOTTOMLEFT", 0, -7)
	self.lootSub:SetWidth(LOOT_W - 24)
	self.lootSub:SetHeight(13)

	self.modeTabs = {}
	-- JunkieUI button reaction: hover = warm fill, selected = warm fill + accent border + accent text
	local function ModeTabStyle(b, on, hover)
		if on then
			b:SetBackdropColor(C.hl[1], C.hl[2], C.hl[3], 1)
			b:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 0.8)
			b.text:SetTextColor(C.accent[1], C.accent[2], C.accent[3])
		else
			if hover then
				b:SetBackdropColor(C.hl[1], C.hl[2], C.hl[3], 1)
			else
				b:SetBackdropColor(C.field[1], C.field[2], C.field[3], 1)
			end
			b:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], 1)
			SetColor(b.text, C.text)
		end
		SetSkinColors(b, on and C.hl or (hover and C.hl or C.field), on and { C.accent[1], C.accent[2], C.accent[3], 0.8 } or C.border)
	end
	self.ModeTabStyle = ModeTabStyle
	for i = 1, 5 do
		local b = CreateFrame("Button", nil, lootPane)
		b:SetHeight(24)
		Skin(b, C.field, C.border)
		b.text = Text(b, 12, C.muted, "CENTER")
		b.text:SetPoint("CENTER", 0, 0)
		if i == 1 then
			b:SetPoint("TOPLEFT", lootPane, "TOPLEFT", 12, -60)
		end
		b:SetScript("OnClick", function(s) if s.key then GL:SelectMode(s.key) end end)
		b:SetScript("OnEnter", function(s) ModeTabStyle(s, s.on, true) end)
		b:SetScript("OnLeave", function(s) ModeTabStyle(s, s.on, false) end)
		self.modeTabs[i] = b
	end
	-- chain the tabs so they sit next to each other (small gap) regardless of width
	for i = 2, 5 do
		self.modeTabs[i]:SetPoint("LEFT", self.modeTabs[i - 1], "RIGHT", 6, 0)
	end

	-- "Normal | Heroic" selector across the top of the boss pane (same state as the loot pane tabs)
	self.diffTabs = {}
	local half = floor((BOSS_W - 8 - 4) / 2)
	for i, key in ipairs({ "loot", "heroic" }) do
		local b = CreateFrame("Button", nil, bossPane)
		b:SetHeight(26)
		b:SetWidth(half)
		Skin(b, C.field, C.border)
		b.text = Text(b, 12, C.muted, "CENTER")
		b.text:SetPoint("CENTER", 0, 0)
		b.mode = key
		b:SetPoint("TOPLEFT", bossPane, "TOPLEFT", 4 + (i - 1) * (half + 4), -4)
		b:SetScript("OnClick", function(s) if s.enabled then GL:SelectMode(s.mode) end end)
		b:SetScript("OnEnter", function(s) if s.enabled then ModeTabStyle(s, s.on, true) end end)
		b:SetScript("OnLeave", function(s) ModeTabStyle(s, s.on, false); if not s.enabled then SetColor(s.text, C.dim) end end)
		self.diffTabs[i] = b
	end

	-- second row of small tabs, used for the Mythic versions
	self.subTabs = {}
	for i = 1, 8 do
		local b = CreateFrame("Button", nil, lootPane)
		b:SetHeight(22)
		Skin(b, C.field, C.border)
		b.text = Text(b, 11, C.muted, "CENTER")
		b.text:SetPoint("CENTER", 0, 0)
		if i == 1 then
			b:SetPoint("TOPLEFT", lootPane, "TOPLEFT", 12, -88)
		else
			b:SetPoint("LEFT", self.subTabs[i - 1], "RIGHT", 3, 0)
		end
		b:SetScript("OnClick", function(s) if s.key then GL:SelectMode(s.key) end end)
		b:SetScript("OnEnter", function(s) ModeTabStyle(s, s.on, true) end)
		b:SetScript("OnLeave", function(s) ModeTabStyle(s, s.on, false) end)
		self.subTabs[i] = b
	end

	local lootRows = floor((BODY_H - 4 - LOOT_HEAD) / LOOT_ROW)
	self.lootList = List:Create(lootPane, LOOT_W - 8, LOOT_ROW, lootRows, MakeLootRow, SetLootRow)
	self.lootList.frame:SetPoint("TOPLEFT", lootPane, "TOPLEFT", 4, -LOOT_HEAD)
	self.lootList.onScroll = function() GL.tries = 0 end

	self.emptyText = Text(lootPane, 13, C.dim, "CENTER")
	self.emptyText:SetPoint("CENTER", lootPane, "CENTER", 0, -20)
	self.emptyText:SetWidth(LOOT_W - 60)
	self.emptyText:Hide()

	-- WishList pane: covers the three browser panes. Top: extended bar (title, count, toggles).
	-- Below it: left list (slots + "Show Only") and a 4-column grid of every matching item.
	local wishPane = CreateFrame("Frame", nil, f)
	Size(wishPane, WISH_PANE_W, BODY_H)
	wishPane:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -BODY_TOP)
	Skin(wishPane, C.panel, C.border)
	wishPane:Hide()
	self.panes = { zone = zonePane, boss = bossPane, loot = lootPane, wish = wishPane }

	-- extended bar across the whole pane
	local wbar = CreateFrame("Frame", nil, wishPane)
	wbar:SetPoint("TOPLEFT", wishPane, "TOPLEFT", 4, -4)
	wbar:SetPoint("TOPRIGHT", wishPane, "TOPRIGHT", -4, -4)
	wbar:SetHeight(WISH_BAR_H)
	Skin(wbar, C.field, C.border)
	self.wishBar = wbar

	local wt = Text(wbar, 17, C.text)
	wt:SetPoint("LEFT", wbar, "LEFT", 10, 0)
	wt:SetText("WishList")
	-- "82 Items - Must have all: Intellect + Spell Power" right of the title (stats only)
	self.wishSub = Text(wbar, 11, C.muted)
	self.wishSub:SetPoint("LEFT", wt, "RIGHT", 14, -1)
	self.wishSub:SetWidth(480)
	self.wishSub:SetHeight(13)
	-- scan progress: flat JunkieUI-style bar (dark track, accent fill) with the counter on top
	local pbox = CreateFrame("Frame", nil, wbar)
	Size(pbox, 190, 16)
	pbox:SetPoint("RIGHT", wbar, "RIGHT", -8, 0)
	Skin(pbox, C.bg, C.border)
	pbox:Hide()
	local pbar = CreateFrame("StatusBar", nil, pbox)
	pbar:SetPoint("TOPLEFT", pbox, "TOPLEFT", 1, -1)
	pbar:SetPoint("BOTTOMRIGHT", pbox, "BOTTOMRIGHT", -1, 1)
	pbar:SetStatusBarTexture(FLAT)
	pbar:SetMinMaxValues(0, 1)
	pbar:SetValue(0)
	pbar:SetStatusBarColor(C.accent[1], C.accent[2], C.accent[3], 0.85)
	local ptxt = Text(pbar, 10, C.text, "CENTER")
	ptxt:SetPoint("CENTER", pbar, "CENTER", 0, 0)
	pbox:EnableMouse(true)
	pbox:SetScript("OnEnter", function() pbar:SetStatusBarColor(C.accent[1], C.accent[2], C.accent[3], 1); pbox:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 0.8) end)
	pbox:SetScript("OnLeave", function() pbar:SetStatusBarColor(C.accent[1], C.accent[2], C.accent[3], 0.85); pbox:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], 1) end)
	self.wishProgBox, self.wishProgBar = pbox, pbar
	-- keep the old SetText interface working
	self.wishProg = { SetText = function(_, t)
		if t and t ~= "" then ptxt:SetText(t); pbox:Show() else pbox:Hide() end
	end }

	-- left list: slots (one at a time) + "Show Only" versions (one at a time) + "Clear Item Level"
	do
		local W = self.db.wish
		W.show = W.show or {}
		local validShow = {}
		for _, d in ipairs(GL.wishShowDefs) do validShow[d.key] = true end
		W.onlyMythic, W.topRanks, W.noIlvl = nil, nil, nil   -- removed buttons: make sure their old saved state is off
		if W.show.m15 then W.show.m12 = true end       -- Mythic 15 of older versions is Mythic 12 now
		local keep
		for _, d in ipairs(GL.wishShowDefs) do       -- only ONE version can be on: keep the first saved one
			if W.show[d.key] and not keep then keep = d.key end
		end
		W.show = keep and { [keep] = true } or {}
		if W.slot and not GL.wishSlotByKey[W.slot] then W.slot = "ALL" end

		local side = CreateFrame("Frame", nil, wishPane)
		Size(side, WISH_SIDE_W, BODY_H - WISH_HEAD - 4)
		side:SetPoint("TOPLEFT", wishPane, "TOPLEFT", 4, -WISH_HEAD)
		Skin(side, C.field, C.border)
		self.wishSide = side

		local ROW, COL1_W, COL2_W = 24, 104, 106
		local COL1_X, COL2_X = 6, 6 + COL1_W + 4

		local function Header(txt, x)
			local h = Text(side, 11, C.accent, "LEFT")
			h:SetPoint("TOPLEFT", side, "TOPLEFT", x + 4, -8)
			h:SetText(txt)
		end
		local sep = side:CreateTexture(nil, "ARTWORK")
		sep:SetWidth(1)
		sep:SetPoint("TOPLEFT", side, "TOPLEFT", COL1_X + COL1_W + 2, -6)
		sep:SetPoint("BOTTOMLEFT", side, "BOTTOMLEFT", COL1_X + COL1_W + 2, 6)
		sep:SetTexture(C.border[1], C.border[2], C.border[3], 1)
		Header("Slot:", COL1_X)
		Header("Show Only:", COL2_X)

		-- flat list entry: tinted + accent bar when on
		local function Entry(label, x, y, w)
			local b = CreateFrame("Button", nil, side)
			Size(b, w, ROW - 2)
			b:SetPoint("TOPLEFT", side, "TOPLEFT", x, y)
			b.bg = b:CreateTexture(nil, "BACKGROUND")
			b.bg:SetAllPoints()
			b.bg:SetTexture(C.hl[1], C.hl[2], C.hl[3], 0)
			b.mark = b:CreateTexture(nil, "ARTWORK")
			b.mark:SetWidth(2)
			b.mark:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
			b.mark:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 0, 0)
			b.mark:SetTexture(C.folder[1], C.folder[2], C.folder[3], 1)
			b.mark:Hide()
			b.text = Text(b, 12, C.muted, "LEFT")
			b.text:SetPoint("LEFT", b, "LEFT", 8, 0)
			b.text:SetText(label)
			function b:SetState(on, hover)
				if on then
						self.bg:SetTexture(C.hl[1], C.hl[2], C.hl[3], 1)
						self.mark:Show()
						SetColor(self.text, C.accent)
					else
						self.mark:Hide()
						self.bg:SetTexture(C.hl[1], C.hl[2], C.hl[3], hover and 1 or 0)
						if hover then SetColor(self.text, C.text) else SetColor(self.text, C.muted) end
					end
			end
			return b
		end

		local slotBtns, showBtns = {}, {}
		local function SlotOn(key) return (W.slot or "ALL") == key end
		local function ShowOn(key) return W.show[key] and true or false end
		local function RefreshSide()
			for key, b in pairs(slotBtns) do b:SetState(SlotOn(key), false) end
			for key, b in pairs(showBtns) do b:SetState(ShowOn(key), false) end
		end

		-- slots: click one to filter, click it again to show all slots
		local row = 0
		for _, sl in ipairs(GL.wishSlots) do
			if sl.loc then
				local b = Entry(sl.label, COL1_X, -24 - row * ROW, COL1_W)
				row = row + 1
				b:SetScript("OnEnter", function(s2) s2:SetState(SlotOn(sl.key), true) end)
				b:SetScript("OnLeave", function(s2) s2:SetState(SlotOn(sl.key), false) end)
				b:SetScript("OnClick", function()
					W.slot = SlotOn(sl.key) and "ALL" or sl.key
					RefreshSide()
					GL.wishSig = nil
					if S.wish then GL:RefreshWish() end
				end)
				slotBtns[sl.key] = b
			end
		end

		-- Show Only: nothing on = show everything
		for i, d in ipairs(GL.wishShowDefs) do
			local b = Entry(d.label, COL2_X, -24 - (i - 1) * ROW, COL2_W)
			b:SetScript("OnEnter", function(s2)
				s2:SetState(ShowOn(d.key), true)
				GameTooltip:SetOwner(s2, "ANCHOR_RIGHT")
				GameTooltip:SetText(d.label, 1, 1, 1)
				GameTooltip:AddLine(d.tip, 0.75, 0.78, 0.8, 1)
				GameTooltip:AddLine("Only one version at a time. Click it again to show every version.", 0.5, 0.58, 0.59, 1)
				GameTooltip:Show()
			end)
			b:SetScript("OnLeave", function(s2) s2:SetState(ShowOn(d.key), false); GameTooltip:Hide() end)
			b:SetScript("OnClick", function()
				local was = W.show[d.key]
				wipe(W.show)                                   -- one version at a time
				if not was then W.show[d.key] = true end       -- click the active one again = show every version
				RefreshSide()
				GL.wishSig = nil
				GL:WishChanged(true)
				if S.wish then GL:RefreshWish() end
			end)
			showBtns[d.key] = b
		end

		RefreshSide()
	end

	local wishRows = floor((BODY_H - 4 - WISH_HEAD) / LOOT_ROW)
	self.wishList = List:Create(wishPane, WISH_LIST_W, LOOT_ROW, wishRows, MakeWishRow, SetWishRow)
	self.wishList.frame:SetPoint("TOPLEFT", wishPane, "TOPLEFT", 4 + WISH_SIDE_W + 4, -WISH_HEAD)

	self.wishEmpty = Text(wishPane, 13, C.dim, "CENTER")
	self.wishEmpty:SetPoint("CENTER", self.wishList.frame, "CENTER", 0, 0)
	self.wishEmpty:SetWidth(WISH_LIST_W - 100)
	self.wishEmpty:Hide()

	-- "Advance Filtering" button + ">" button on the right side of the tab row
	local arrow = CreateFrame("Button", nil, f)
	Size(arrow, 24, 22)
	arrow:SetPoint("TOPRIGHT", f, "TOPRIGHT", -14, -(HEADER_H + 6))
	Skin(arrow, C.panel, C.border)
	arrow.text = Text(arrow, 13, C.muted, "CENTER")
	arrow.text:SetPoint("CENTER", 0, 1)
	arrow.text:SetText(">")
	self.filterArrow = arrow

	local fb = CreateFrame("Button", nil, f)
	Size(fb, 140, 22)
	fb:SetPoint("RIGHT", arrow, "LEFT", -4, 0)
	Skin(fb, C.panel, C.border)
	fb.text = Text(fb, 12, C.text, "CENTER")
	fb.text:SetPoint("CENTER", 0, 0)
	fb.text:SetText("Advance Filtering")
	self.filterBtn = fb

	for _, b in ipairs({ fb, arrow }) do
		b:SetScript("OnEnter", function()
			fb:SetBackdropColor(C.hl[1], C.hl[2], C.hl[3], 1); arrow:SetBackdropColor(C.hl[1], C.hl[2], C.hl[3], 1)
		end)
		b:SetScript("OnLeave", function()
			fb:SetBackdropColor(C.panel[1], C.panel[2], C.panel[3], 1); arrow:SetBackdropColor(C.panel[1], C.panel[2], C.panel[3], 1)
		end)
		b:SetScript("OnClick", function() GL:ToggleFilterPanel() end)
	end

	-- footer: credit on the left, Close button on the right
	local fdiv = f:CreateTexture(nil, "ARTWORK")
	fdiv:SetHeight(1)
	fdiv:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 1, FOOTER_H)
	fdiv:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, FOOTER_H)
	fdiv:SetTexture(C.border[1], C.border[2], C.border[3], 1)

	-- signature image + contact text on the left of the footer
	local sig = f:CreateTexture(nil, "OVERLAY")
	Size(sig, 88, 44)
	sig:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 10, 2)
	sig:SetTexture("Interface\\AddOns\\XLoot\\Media\\signature.tga")

	local ver = Text(f, 11, C.dim)
	ver:SetPoint("LEFT", sig, "RIGHT", 8, 0)
	ver:SetJustifyH("LEFT")
	ver:SetText("For any suggestion contact:\n|cffde7230IGN: Xlk | Discord: rexk01|r")

	local fclose = CreateFrame("Button", nil, f)
	Size(fclose, 130, 26)
	fclose:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -14, 7)
	Skin(fclose, C.panel, C.border)
	fclose.text = Text(fclose, 12, C.text, "CENTER")
	fclose.text:SetPoint("CENTER", 0, 0)
	fclose.text:SetText("Close")
	fclose:SetScript("OnEnter", function(s) s:SetBackdropColor(C.hl[1], C.hl[2], C.hl[3], 1) end)
	fclose:SetScript("OnLeave", function(s) s:SetBackdropColor(C.panel[1], C.panel[2], C.panel[3], 1) end)
	fclose:SetScript("OnClick", function() f:Hide() end)

	f:SetScript("OnShow", function()
		RefreshPixel()
		GL.tries = 0
		GL:ApplyView()
		GL:RefreshLoot()
		if S.wish then GL:RefreshWish(true) end
	end)
end

---------------------------------------------------------------------------
-- background polling: late item info + debounced search
---------------------------------------------------------------------------

local poller = CreateFrame("Frame")
local acc = 0
poller:SetScript("OnUpdate", function(_, elapsed)
	if not GL.frame or not GL.frame:IsShown() then return end
	if GL.searchDue and GetTime() >= GL.searchDue then
		GL.searchDue = nil
		GL:RunSearch()
	end
	if GL.wishDue and GetTime() >= GL.wishDue then
		GL.wishDue = nil
		if S.wish then GL.wishSig = nil; GL:RefreshWish() end
	end
	acc = acc + elapsed
	if acc < 0.7 then return end
	acc = 0
	if GL.infoDirty then
		GL.infoDirty = false
		if not (GL.wishScan and not GL.wishScan.finished and GameTooltip:IsShown()) then
			GL.keepLootOffset = true
			GL:RefreshLoot()
		end
	end
	if GL.unresolved then
		GL.tries = (GL.tries or 0) + 1
		if GL.tries <= 14 then
			GL.keepLootOffset = true
			GL:RefreshLoot()
		else
			GL.unresolved = false
		end
	end
end)

pcall(function()
	poller:RegisterEvent("GET_ITEM_INFO_RECEIVED")
	-- one event arrives for every item the server answers (thousands during a scan), so only mark
	-- the view as stale here; the poller below refreshes it at most once per tick
	poller:SetScript("OnEvent", function()
		GL.infoDirty = true
	end)
end)

---------------------------------------------------------------------------
-- minimap button
---------------------------------------------------------------------------

function GL:UpdateMinimapButton()
	if not self.minimapButton then return end
	if self.db.minimap.hide then
		self.minimapButton:Hide()
	else
		self.minimapButton:Show()
	end
end

local function PlaceMinimapButton(b)
	local a = rad(GL.db.minimap.angle or 215)
	b:ClearAllPoints()
	b:SetPoint("CENTER", Minimap, "CENTER", cos(a) * 78, sin(a) * 78)
end

function GL:CreateMinimapButton()
	local b = CreateFrame("Button", "XLootMinimapButton", Minimap)
	self.minimapButton = b
	Size(b, 31, 31)
	b:SetFrameStrata("MEDIUM")
	b:SetFrameLevel(8)
	b:RegisterForClicks("LeftButtonUp")
	b:RegisterForDrag("LeftButton")

	local ic = b:CreateTexture(nil, "BACKGROUND")
	Size(ic, 20, 20)
	ic:SetPoint("TOPLEFT", b, "TOPLEFT", 6, -5)
	ic:SetTexture("Interface\\Icons\\INV_Misc_Book_09")
	ic:SetTexCoord(0.07, 0.93, 0.07, 0.93)

	local ov = b:CreateTexture(nil, "OVERLAY")
	Size(ov, 53, 53)
	ov:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
	ov:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
	b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

	b:SetScript("OnClick", function() GL:Toggle() end)
	b:SetScript("OnDragStart", function(s)
		s:SetScript("OnUpdate", function()
			local mx, my = Minimap:GetCenter()
			local cx, cy = GetCursorPosition()
			local sc = Minimap:GetEffectiveScale()
			GL.db.minimap.angle = deg(atan2(cy / sc - my, cx / sc - mx))
			PlaceMinimapButton(s)
		end)
	end)
	b:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
	b:SetScript("OnEnter", function(s)
		GameTooltip:SetOwner(s, "ANCHOR_LEFT")
		GameTooltip:SetText("|cffde7230X|r-Loot")
		GameTooltip:AddLine("Click to open / close", 0.8, 0.8, 0.8)
		GameTooltip:AddLine("Drag to move", 0.8, 0.8, 0.8)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", function() GameTooltip:Hide() end)

	PlaceMinimapButton(b)
	self:UpdateMinimapButton()
end

---------------------------------------------------------------------------
-- public entry points
---------------------------------------------------------------------------

function GL:Toggle()
	self:Build()
	if self.frame:IsShown() then
		self.frame:Hide()
	else
		if not self.built then
			self.built = true
			S.ex = self.db.expansion or "Classic"
			self:SelectExpansion(S.ex)
		end
		self.frame:Show()
	end
end

function GL:OnLoad()
	self:CreateMinimapButton()
end
